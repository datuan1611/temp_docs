#!/usr/bin/env bash
# verify-env.sh — Verification Suite 4 cấp độ cho môi trường ELDMP
# (Ubuntu Server + Docker Engine chuẩn công nghiệp — không phụ thuộc hạ tầng
#  bên dưới: bare-metal, VM với bất kỳ hypervisor nào, hay Cloud Instance)
# Vị trí trong repo: scripts/helper/verify-env.sh
#
# Chạy được ở HAI nơi (logic không phụ thuộc host hay container — chỉ kiểm
# tra binary/service có sẵn hay không):
#   A. Trực tiếp trên Ubuntu Server (qua SSH hoặc console) — kiểm Docker
#      service thật, quyền truy cập socket, RAM/CPU/Swap
#   B. Bên trong container eldmp-toolchain (build từ .devcontainer/Dockerfile)
#      — Level 1 phần Docker service tự động báo "N/A (chạy trong container)"
#
# Cách dùng:
#   chmod +x scripts/helper/verify-env.sh
#   ./scripts/helper/verify-env.sh
#
# Level 1 — Ubuntu OS & Docker Health Check
# Level 2 — Toolchain Availability
# Level 3 — STM32 & Embedded Linux Compilation Test
# Level 4 — Dynamic Sanitizer Test
#
# Exit code: 0 nếu mọi cấp độ PASS, 1 nếu có ít nhất một cấp độ FAIL.

set -uo pipefail   # KHÔNG dùng -e — cần chạy hết cả 4 cấp độ dù có lỗi giữa chừng

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PASS_COUNT=0
FAIL_COUNT=0
RESULTS=()

log()  { echo -e "\n\033[1;36m### $1 ###\033[0m"; }
ok()   { echo -e "\033[1;32m✅ $1\033[0m"; RESULTS+=("✅ $1"); PASS_COUNT=$((PASS_COUNT+1)); }
fail() { echo -e "\033[1;31m❌ $1\033[0m"; RESULTS+=("❌ $1"); FAIL_COUNT=$((FAIL_COUNT+1)); }
info() { echo -e "\033[1;34mℹ $1\033[0m"; RESULTS+=("ℹ️  $1"); }

# ==========================================================================
# LEVEL 1 — Ubuntu OS & Docker Health Check
# ==========================================================================
log "LEVEL 1 — Ubuntu OS & Docker Health Check"

IN_CONTAINER=false
[ -f /.dockerenv ] && IN_CONTAINER=true

# 1a. Docker Service — chỉ có ý nghĩa khi chạy TRÊN host Ubuntu Server thật,
#     không phải bên trong chính container eldmp-toolchain
if $IN_CONTAINER; then
    info "Level 1a: Đang chạy BÊN TRONG container — bỏ qua kiểm tra systemctl status docker (không áp dụng)"
else
    if systemctl is-active --quiet docker 2>/dev/null; then
        ok "Level 1a: Docker Service (systemctl status docker) — active"
    else
        fail "Level 1a: Docker Service KHÔNG active — chạy 'sudo systemctl status docker' để xem log"
    fi
fi

# 1b. Quyền truy cập Docker socket KHÔNG cần sudo (Docker User Permissions)
if $IN_CONTAINER; then
    info "Level 1b: Đang trong container — bỏ qua kiểm tra quyền Docker socket (không áp dụng)"
else
    if docker ps >/dev/null 2>&1; then
        ok "Level 1b: 'docker ps' chạy được KHÔNG cần sudo — user đã ở đúng group 'docker'"
    else
        fail "Level 1b: 'docker ps' THẤT BẠI không sudo — chạy 'newgrp docker' hoặc đăng nhập lại sau khi setup-ubuntu-docker.sh thêm user vào group docker"
    fi
fi

# 1c. RAM tổng
MEM_TOTAL_MB=$(free -m | awk '/^Mem:/{print $2}')
echo "RAM tổng: ${MEM_TOTAL_MB}MB"
if [ "$MEM_TOTAL_MB" -ge 3500 ]; then
    ok "Level 1c: RAM đủ tối thiểu khuyến nghị (${MEM_TOTAL_MB}MB, >= 3.5GB)"
else
    info "Level 1c: RAM đo được ${MEM_TOTAL_MB}MB — thấp hơn 3.5GB khuyến nghị, theo dõi kỹ khi build/chạy container nặng"
fi

# 1d. CPU
CPU_COUNT=$(nproc)
echo "CPU cores: ${CPU_COUNT}"
info "Level 1d: Số CPU khả dụng: ${CPU_COUNT}"

# 1e. Swap — kỳ vọng ~4GB theo setup-ubuntu-docker.sh (chỉ có ý nghĩa trên host)
if $IN_CONTAINER; then
    info "Level 1e: Đang trong container — bỏ qua kiểm tra Swap (kế thừa từ host)"
else
    SWAP_TOTAL_MB=$(free -m | awk '/^Swap:/{print $2}')
    echo "Swap tổng: ${SWAP_TOTAL_MB}MB"
    if [ "$SWAP_TOTAL_MB" -ge 3800 ]; then
        ok "Level 1e: Swap đúng ~4GB (${SWAP_TOTAL_MB}MB)"
    else
        fail "Level 1e: Swap KHÔNG đủ 4GB (đo được ${SWAP_TOTAL_MB}MB) — chạy lại scripts/helper/setup-ubuntu-docker.sh"
    fi
fi

# ==========================================================================
# LEVEL 2 — Toolchain Availability
# ==========================================================================
log "LEVEL 2 — Toolchain Availability"

check_tool_version() {
    local tool="$1"
    local version_flag="${2:---version}"
    if command -v "$tool" &>/dev/null; then
        local ver
        ver=$("$tool" "$version_flag" 2>&1 | head -1)
        ok "Level 2: '$tool' có sẵn — $ver"
    else
        fail "Level 2: '$tool' KHÔNG tìm thấy trong PATH"
    fi
}

check_tool_version "arm-none-eabi-gcc"
check_tool_version "arm-linux-gnueabihf-gcc"
check_tool_version "clang"
check_tool_version "cppcheck"
check_tool_version "clang-tidy"
check_tool_version "cmake"
check_tool_version "ninja"

# ==========================================================================
# LEVEL 3 — STM32 & Embedded Linux Compilation Test
# ==========================================================================
log "LEVEL 3 — STM32 & Embedded Linux Compilation Test"

STM32_SRC="$REPO_ROOT/tests/4_verification/test_stm32.c"
if [ -f "$STM32_SRC" ]; then
    TMPDIR_STM32=$(mktemp -d)
    if arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=soft \
        -nostdlib -nostartfiles \
        -O0 -c -o "$TMPDIR_STM32/test_stm32.o" "$STM32_SRC" 2>"$TMPDIR_STM32/stderr.log"; then
        arm-none-eabi-objcopy -O ihex "$TMPDIR_STM32/test_stm32.o" "$TMPDIR_STM32/test_stm32.hex" 2>/dev/null || true
        ok "Level 3a: test_stm32.c biên dịch thành công qua arm-none-eabi-gcc (.o/.hex tạo được)"
    else
        echo "--- Lỗi biên dịch STM32 ---"; cat "$TMPDIR_STM32/stderr.log"
        fail "Level 3a: test_stm32.c KHÔNG biên dịch được — xem log ở trên"
    fi
    rm -rf "$TMPDIR_STM32"
else
    fail "Level 3a: Không tìm thấy $STM32_SRC"
fi

# Cross-compile Linux app (armhf) — phần "Embedded Linux" của Level 3
TMPDIR_LINUX=$(mktemp -d)
cat > "$TMPDIR_LINUX/hello_armhf.c" << 'CEOF'
#include <stdio.h>
int main(void) { printf("ELDMP armhf cross-compile OK\n"); return 0; }
CEOF
if arm-linux-gnueabihf-gcc -o "$TMPDIR_LINUX/hello_armhf" "$TMPDIR_LINUX/hello_armhf.c" 2>"$TMPDIR_LINUX/stderr.log"; then
    ok "Level 3b: cross-compile Embedded Linux App (armhf, BeagleBone Black) qua arm-linux-gnueabihf-gcc thành công"
else
    cat "$TMPDIR_LINUX/stderr.log"
    fail "Level 3b: cross-compile armhf THẤT BẠI"
fi
rm -rf "$TMPDIR_LINUX"

# ==========================================================================
# LEVEL 4 — Dynamic Sanitizer Test
# ==========================================================================
log "LEVEL 4 — Dynamic Sanitizer Test (AddressSanitizer)"

ASAN_SRC="$REPO_ROOT/tests/4_verification/test_asan.c"
if [ -f "$ASAN_SRC" ]; then
    TMPDIR_ASAN=$(mktemp -d)
    if clang -fsanitize=address,undefined,leak -fno-omit-frame-pointer -g \
        -o "$TMPDIR_ASAN/test_asan" "$ASAN_SRC" 2>"$TMPDIR_ASAN/build.log"; then
        set +e
        "$TMPDIR_ASAN/test_asan" 1 > "$TMPDIR_ASAN/run.log" 2>&1
        RUN_EXIT=$?
        if [ "$RUN_EXIT" -ne 0 ] && grep -qi "leak\|AddressSanitizer\|ERROR" "$TMPDIR_ASAN/run.log"; then
            ok "Level 4: AddressSanitizer/LeakSanitizer BẮT ĐÚNG lỗi memory leak cố ý (exit code ${RUN_EXIT})"
        else
            cat "$TMPDIR_ASAN/run.log"
            fail "Level 4: Sanitizer KHÔNG bắt được lỗi memory leak cố ý"
        fi
    else
        cat "$TMPDIR_ASAN/build.log"
        fail "Level 4: test_asan.c KHÔNG biên dịch được với clang -fsanitize=..."
    fi
    rm -rf "$TMPDIR_ASAN"
else
    fail "Level 4: Không tìm thấy $ASAN_SRC"
fi

# ==========================================================================
# BÁO CÁO TỔNG KẾT
# ==========================================================================
echo ""
echo "=========================================================="
echo " KẾT QUẢ VERIFICATION SUITE — $((PASS_COUNT + FAIL_COUNT)) kiểm tra"
echo "=========================================================="
for r in "${RESULTS[@]}"; do echo " $r"; done
echo ""
echo " PASS: $PASS_COUNT   FAIL: $FAIL_COUNT"
echo "=========================================================="

[ "$FAIL_COUNT" -gt 0 ] && exit 1
exit 0
