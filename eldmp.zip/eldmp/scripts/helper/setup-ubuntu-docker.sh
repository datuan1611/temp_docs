#!/usr/bin/env bash
# setup-ubuntu-docker.sh — "One-click" tối ưu Ubuntu Server + cài Docker Engine
# CHÍNH THỨC (apt repository) theo chuẩn công nghiệp.
# Vị trí trong repo: scripts/helper/setup-ubuntu-docker.sh
#
# QUY CHUẨN HẠ TẦNG: script này chạy được trên BẤT KỲ Ubuntu Server nào —
# máy thật (bare-metal), máy ảo (VM, bất kể hypervisor: VMware Fusion/UTM/Proxmox/
# Hyper-V/...), hay Cloud Instance (AWS/GCP/Azure/...). Không có bất kỳ giả
# định nào về hạ tầng bên dưới — đây chính là mục tiêu "tính độc lập tuyệt
# đối" theo Chỉ Thị. Bối cảnh triển khai thực tế của dự án ELDMP hiện tại:
# Ubuntu Server 26.04 LTS ARM64 trên MacBook Pro M1 8GB RAM (macOS 11.7.11
# Big Sur), nhưng bản thân script này không phụ thuộc bối cảnh đó.
#
# KHÁC BIỆT CỐT LÕI so với các bản trước (Lima/OrbStack/Colima): script này
# cài Docker Engine THẬT theo đúng hướng dẫn chính thức của Docker Inc.,
# không qua bất kỳ lớp wrapper/giả lập ảo hoá nào của macOS. Đây chính xác
# là cách một server Linux thật trong doanh nghiệp cài Docker.
#
# Cách dùng (chạy TRÊN Ubuntu Server, qua SSH hoặc console trực tiếp):
#   chmod +x scripts/helper/setup-ubuntu-docker.sh
#   ./scripts/helper/setup-ubuntu-docker.sh
#
# Script idempotent — chạy lại nhiều lần không gây lỗi.
#
# CẤU HÌNH TÀI NGUYÊN THAM CHIẾU (mục I.1 Chỉ Thị — cho máy 4-8GB RAM):
# Swap 4GB, swappiness thấp, sysctl tối ưu — giúp Docker + toolchain compile
# chạy mượt ngay cả trên cấu hình RAM hạn chế.

set -euo pipefail

log()  { echo -e "\n\033[1;32m==> $1\033[0m"; }
warn() { echo -e "\033[1;33m⚠ $1\033[0m"; }
ok()   { echo -e "\033[1;32m✅ $1\033[0m"; }

log "[1/6] Cập nhật hệ thống"
sudo apt-get update -y && sudo apt-get upgrade -y

log "[2/6] Cấu hình Swap 4GB"
if [ ! -f /swapfile ]; then
    sudo fallocate -l 4G /swapfile
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile
    sudo swapon /swapfile
    if ! grep -q '/swapfile' /etc/fstab; then
        echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab > /dev/null
    fi
    ok "Đã tạo swapfile 4GB tại /swapfile"
else
    warn "/swapfile đã tồn tại — bỏ qua tạo mới"
fi

log "[3/6] Tối ưu Kernel Parameters (sysctl) cho môi trường RAM hạn chế + Docker + VS Code"
sudo tee /etc/sysctl.d/99-eldmp-tuning.conf > /dev/null << 'SYSCTLEOF'
# eldmp — tối ưu kernel parameters cho máy 4-8GB RAM chạy Docker + toolchain compile

# Swappiness thấp — ưu tiên dùng RAM thật trước, chỉ swap khi thực sự cần,
# tránh compile/container bị chậm không cần thiết do swap quá tích cực
vm.swappiness=10

# Docker/Redis-style khuyến nghị chính thức: cho phép kernel overcommit bộ
# nhớ, tránh fork() thất bại giả khi RAM gần đầy (compile nhiều process song
# song, hoặc container khởi tạo, thường fork trước khi exec)
vm.overcommit_memory=1

# VS Code Server (Remote-SSH) và nhiều dev tool theo dõi (watch) rất nhiều
# file cùng lúc — giá trị mặc định của Ubuntu (thường 8192-65536) dễ bị vượt
# với một repo nhiều file như eldmp, gây lỗi "ENOSPC: System limit for
# number of file watchers reached"
fs.inotify.max_user_watches=524288
fs.inotify.max_user_instances=512
SYSCTLEOF
sudo sysctl --system > /dev/null
ok "Đã áp dụng sysctl tối ưu (swappiness, overcommit_memory, inotify watches)"

log "[4/6] Gỡ các gói Docker cũ/xung đột (nếu Ubuntu Server cài sẵn docker.io)"
for pkg in docker.io docker-doc docker-compose docker-compose-v2 podman-docker containerd runc; do
    sudo apt-get remove -y "$pkg" 2>/dev/null || true
done

log "[5/6] Cài Docker Engine qua apt repository CHÍNH THỨC của Docker Inc. + Compose Plugin"
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# shellcheck disable=SC1091
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update -y
sudo apt-get install -y \
    docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin

log "[6/6] Cấu hình Docker User Permissions & Daemon JSON"

# Docker User Permissions — thêm user vào group docker để dùng docker không
# cần sudo (chuẩn thao tác hàng ngày, KHÔNG dùng sudo docker liên tục)
sudo usermod -aG docker "$USER"

# Daemon JSON — giới hạn log driver để tránh container chạy lâu ngày làm đầy
# đĩa (đặc biệt quan trọng trên máy disk nhỏ 40GB); log-driver json-file mặc
# định của Docker KHÔNG tự giới hạn dung lượng nếu không cấu hình rõ
sudo mkdir -p /etc/docker
if [ ! -f /etc/docker/daemon.json ]; then
    sudo tee /etc/docker/daemon.json > /dev/null << 'DAEMONJSONEOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "storage-driver": "overlay2"
}
DAEMONJSONEOF
    ok "Đã tạo /etc/docker/daemon.json (giới hạn log 10MB x 3 file/container)"
else
    warn "/etc/docker/daemon.json đã tồn tại — không ghi đè, kiểm tra thủ công nếu cần"
fi

sudo systemctl enable docker
sudo systemctl restart docker   # restart (không chỉ start) để áp dụng daemon.json mới

echo ""
echo "=========================================================="
echo " Cài đặt + tối ưu Ubuntu Server hoàn tất."
echo " Docker version: $(sudo docker --version)"
echo " Compose plugin: $(sudo docker compose version)"
echo " Swap:            $(free -h | awk '/^Swap:/{print $2}')"
echo " Daemon config:   /etc/docker/daemon.json"
echo ""
echo " ⚠ QUAN TRỌNG: thoát SSH và đăng nhập lại (hoặc chạy 'newgrp docker')"
echo "   để nhóm 'docker' có hiệu lực — sau đó chạy 'docker ps' KHÔNG cần"
echo "   sudo để xác nhận quyền truy cập Docker socket đã đúng."
echo ""
echo " Bước tiếp theo: chạy scripts/helper/verify-env.sh để kiểm chứng toàn diện"
echo "=========================================================="
