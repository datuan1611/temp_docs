/*
 * test_stm32.c — Verification Suite Level 3: STM32 Compilation Test
 * Vị trí trong repo: tests/verification/test_stm32.c
 *
 * Mục đích: file C bare-metal TỐI GIẢN để xác nhận toolchain
 * arm-none-eabi-gcc trong Colima VM biên dịch + link ra .elf/.hex thành
 * công, KHÔNG phải firmware thật của ELDMP (Sprint 3 mới viết firmware
 * thật). Nhắm STM32F446 (mặc định) — đổi -mcpu/-D nếu build cho STM32H743.
 *
 * Build (không cần board thật, chỉ cần compile pass):
 *   arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=soft \
 *       -nostdlib -nostartfiles -O0 -g \
 *       -T tests/verification/test_stm32_linker.ld \
 *       -o test_stm32.elf tests/verification/test_stm32.c \
 *       tests/verification/test_stm32_startup.s
 *   arm-none-eabi-objcopy -O ihex test_stm32.elf test_stm32.hex
 */

#include <stdint.h>

/* Địa chỉ thanh ghi GPIOA giả định (STM32F446, tham khảo Reference Manual
 * để lấy giá trị chính xác khi viết firmware thật ở Sprint 3 — ở đây chỉ
 * dùng để test compiler hiểu được thao tác truy cập thanh ghi qua con trỏ
 * volatile, không nhằm chạy đúng trên hardware thật). */
#define GPIOA_BASE      0x40020000UL
#define GPIOA_MODER     (*(volatile uint32_t *)(GPIOA_BASE + 0x00))
#define GPIOA_ODR       (*(volatile uint32_t *)(GPIOA_BASE + 0x14))
#define RCC_AHB1ENR     (*(volatile uint32_t *)(0x40023830UL))

#define LED_PIN         5U   /* PA5 — LED tích hợp trên nhiều board Nucleo */

static void gpio_led_init(void)
{
    /* Bật clock cho GPIOA */
    RCC_AHB1ENR |= (1U << 0);

    /* Đặt PA5 làm output (MODER bit đôi: 01 = output) */
    GPIOA_MODER &= ~(0x3U << (LED_PIN * 2U));
    GPIOA_MODER |=  (0x1U << (LED_PIN * 2U));
}

static void gpio_led_toggle(void)
{
    GPIOA_ODR ^= (1U << LED_PIN);
}

static void delay_busy(volatile uint32_t count)
{
    while (count--) {
        __asm__ volatile ("nop");
    }
}

int main(void)
{
    gpio_led_init();

    while (1) {
        gpio_led_toggle();
        delay_busy(500000U);
    }

    return 0; /* không bao giờ chạy tới đây — giữ để thoả mãn signature int main(void) */
}

/* Handler lỗi tối giản — tránh cảnh báo "undefined reference" khi link với
 * startup code chuẩn nếu bạn ghép thêm CMSIS/HAL thật ở Sprint 3 */
void HardFault_Handler(void)
{
    while (1) { /* treo tại đây khi có lỗi cứng — đủ cho mục đích verify compile */ }
}
