/*
 * test_asan.c — Verification Suite Level 4: Dynamic Sanitizer Test
 * Vị trí trong repo: tests/verification/test_asan.c
 *
 * Mục đích: chứa các lỗi bộ nhớ CỐ Ý (memory leak, use-after-free,
 * heap-buffer-overflow) để xác nhận Clang AddressSanitizer trong Colima
 * VM / container eldmp-toolchain thực sự bắt được lỗi — không phải code
 * mẫu cho sản phẩm ELDMP.
 *
 * Build & chạy:
 *   clang -fsanitize=address,undefined,leak -fno-omit-frame-pointer -g \
 *       -o test_asan tests/verification/test_asan.c
 *   ./test_asan <1|2|3>   # chọn loại lỗi muốn kích hoạt
 *
 * Kỳ vọng: ASan phải in báo cáo lỗi (ERROR: AddressSanitizer: ...) và
 * chương trình thoát với exit code khác 0 — nếu không, toolchain sanitizer
 * chưa hoạt động đúng trong môi trường Colima.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Lỗi 1: Memory Leak — cấp phát nhưng không bao giờ free() */
static void trigger_memory_leak(void)
{
    int *leaked = (int *)malloc(10 * sizeof(int));
    leaked[0] = 42;
    printf("Memory leak triggered: leaked[0] = %d (buffer never freed)\n", leaked[0]);
    /* Cố ý KHÔNG free(leaked) ở đây — LeakSanitizer phải phát hiện khi thoát chương trình */
}

/* Lỗi 2: Use-After-Free — truy cập vùng nhớ sau khi đã free() */
static void trigger_use_after_free(void)
{
    int *buf = (int *)malloc(5 * sizeof(int));
    buf[0] = 100;
    free(buf);
    printf("Use-after-free triggered: buf[0] = %d (đọc sau free!)\n", buf[0]);
}

/* Lỗi 3: Heap Buffer Overflow — ghi vượt quá vùng nhớ đã cấp phát */
static void trigger_heap_overflow(void)
{
    char *small_buf = (char *)malloc(8);
    memcpy(small_buf, "This string is definitely longer than 8 bytes", 47);
    printf("Heap overflow triggered: %s\n", small_buf);
    free(small_buf);
}

int main(int argc, char **argv)
{
    int choice = 1;
    if (argc > 1) {
        choice = atoi(argv[1]);
    }

    printf("=== ELDMP ASan Verification Test (choice=%d) ===\n", choice);

    switch (choice) {
        case 1:
            trigger_memory_leak();
            break;
        case 2:
            trigger_use_after_free();
            break;
        case 3:
            trigger_heap_overflow();
            break;
        default:
            fprintf(stderr, "Dùng: %s <1|2|3>  (1=leak, 2=use-after-free, 3=heap-overflow)\n", argv[0]);
            return 1;
    }

    printf("=== Nếu bạn thấy dòng này KHÔNG kèm báo cáo ASan phía trên, sanitizer CHƯA bắt lỗi đúng ===\n");
    return 0;
}
