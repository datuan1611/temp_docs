# ELDMP System Architecture — Overview

Tổng quan kiến trúc của hệ thống ELDMP từ góc nhìn cao.

---

## Sơ Đồ Kiến Trúc Hệ Thống

```
                          ┌─────────────────┐
                          │      Cloud      │
                          │   (MQTT/REST)   │
                          └────────┬────────┘
                                   │
                    OTA / Monitoring / Messaging
                                   │
                    ┌──────────────┴──────────────┐
                    │                             │
        ┌───────────────────────────────┐   ┌──────────────────┐
        │     Linux SoC (BeagleBone)    │   │  Optional: WiFi  │
        │    Application Layer          │   │  / Ethernet      │
        ├───────────────────────────────┤   └──────────────────┘
        │ • CLI / REST API              │
        │ • systemd services orchestr.  │
        ├───────────────────────────────┤
        │ Services Layer                │
        │ • Device Manager              │
        │ • Health Monitor              │
        │ • Network Manager             │
        │ • OTA Manager                 │
        │ • Watchdog (app-level)        │
        ├───────────────────────────────┤
        │ Middleware Layer              │
        │ • D-Bus IPC                   │
        │ • Logger                      │
        │ • Config Manager              │
        │ • Storage/Filesystem          │
        ├───────────────────────────────┤
        │ HAL (Hardware Abstraction)    │
        │ • GPIO, UART, SPI, I2C, CAN   │
        │   (abstraction of kernel)     │
        ├───────────────────────────────┤
        │ Drivers (Kernel-space)        │
        │ • GPIO driver                 │
        │ • Custom character device     │
        │ • I2C/SPI controller drivers  │
        ├───────────────────────────────┤
        │ Linux Kernel                  │
        │ • Scheduler, memory mgmt      │
        │ • Device Tree (DTB)           │
        │ • Device Tree Overlay         │
        └───────────────────────────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
   ┌────▼────┐ ┌────▼────┐ ┌───▼────┐
   │ GPIO    │ │ UART    │ │ I2C/   │
   │ Interrupt│ │ Serial  │ │ SPI/CAN│
   └─────────┘ └─────────┘ └────────┘
        │           │           │
        └───────────┴───────────┘
                    │
        ┌───────────────────────────────┐
        │   MCU (STM32H743ZI)           │
        ├───────────────────────────────┤
        │ Application Layer             │
        │ • Control logic               │
        │ • Real-time processing        │
        ├───────────────────────────────┤
        │ FreeRTOS RTOS                 │
        │ • Task scheduling             │
        │ • Inter-task synchronization  │
        ├───────────────────────────────┤
        │ LVGL GUI                      │
        │ • UI rendering                │
        │ • Touch/input handling        │
        ├───────────────────────────────┤
        │ HAL & Bare-metal              │
        │ • GPIO, UART, SPI, I2C, CAN   │
        │ • Timer, PWM, DMA             │
        │ • Interrupt handlers          │
        ├───────────────────────────────┤
        │ Sensors / Motors / LCD        │
        └───────────────────────────────┘
```

---

## Phần Chính Của Kiến Trúc

### 1. **Linux SoC (BeagleBone Black Rev C)**

**Vai trò:** Xử lý logic phức tạp, giao tiếp mạng, quản lý hệ thống

#### Layers (từ dưới lên):
- **Kernel Layer:** Linux kernel + Device Tree + Device Tree Overlay
- **Drivers:** Character device driver, GPIO driver, peripheral controller drivers
- **HAL:** Tầng trừu tượng cung cấp API ổn định cho middleware
- **Middleware:** Logger, Config Manager, D-Bus IPC, Storage
- **Services:** Device Manager, Health Monitor, Network Manager, OTA Manager, Watchdog
- **Application:** CLI, REST API, Service orchestration

#### Đặc Điểm:
- ✅ Không thời gian thực nghiêm ngặt — thích hợp cho xử lý logic, mạng, storage
- ✅ Hệ thống tệp đầy đủ — có thể đọc/ghi tệp, cấu hình
- ✅ Networking tích hợp — MQTT, REST, SSH
- ✅ Quản lý hệ thống — systemd, watchdog, syslog

---

### 2. **MCU (STM32H743ZI)**

**Vai trò:** Xử lý thời gian thực, điều khiển cảm biến/motor, giao diện người dùng trực tiếp

#### Layers (từ dưới lên):
- **Bare-metal:** Thanh ghi trực tiếp, interrupt handlers, memory-mapped I/O
- **HAL:** Hardware Abstraction Layer — cung cấp GPIO, UART, SPI, I2C, CAN APIs
- **FreeRTOS:** Real-time OS — quản lý các task, queue, semaphore, timer
- **LVGL GUI:** Embedded GUI library — hiển thị widget, xử lý input
- **Application:** Vòng lặp điều khiển, xử lý cảm biến, logic ứng dụng

#### Đặc Điểm:
- ✅ Thời gian thực xác định — loop điều khiển chạy ở tốc độ cố định
- ✅ Tài nguyên giới hạn — RAM ~1MB, Flash ~2MB
- ✅ GPIO/ADC/PWM tích hợp — điều khiển sensor/motor trực tiếp
- ✅ GUI trực tiếp — LCD controller dùng LVGL không cần X11/Wayland

---

### 3. **Giao Tiếp Linux↔MCU (Sprint 13)**

**Protocol:** Custom binary protocol + CRC + retry + versioning

```
Linux (SoC)                    MCU (STM32)
    │                              │
    │──────── UART/SPI/CAN ────────│
    │         (Protocol)           │
    │                              │
    ├─ Request (command)           │
    │  [Type][ID][Payload][CRC]    │
    │─────────────────────────────>│
    │                              ├─ Xử lý command
    │                              │
    │                    Response  │
    │<─────────────────────────────│
    │         (status + data)      │
    │
    ├─ Verify CRC, handle retry   
    │
    └─ Update state on Linux
```

**Tính năng:**
- ✅ CRC checksum — phát hiện lỗi hỏng dữ liệu
- ✅ Retry logic — gửi lại nếu timeout
- ✅ Version negotiation — tương thích giữa phiên bản khác nhau
- ✅ Fault injection testing — kiểm chứng kịch bản lỗi (mất kết nối, timeout)

---

## Separations of Concerns (Tách Biệt Trách Nhiệm)

### Kernel vs User-Space
```
┌────────────────────────────────────────┐
│ User-Space                             │
│ ├─ Applications (CLI, REST)            │
│ ├─ systemd services                    │
│ ├─ D-Bus daemon                        │
│ └─ Libraries (Logger, Config)          │
├─────── system call boundary ───────────┤
│ Kernel-Space                           │
│ ├─ Kernel scheduler                    │
│ ├─ Memory management (MMU)             │
│ ├─ Device drivers                      │
│ └─ Interrupt handlers                  │
├─────── hardware abstraction ───────────┤
│ Hardware                               │
│ ├─ CPU, RAM, disk                      │
│ └─ Peripherals (GPIO, UART, etc.)      │
└────────────────────────────────────────┘
```

### MCU vs Linux SoC
```
MCU (Real-Time Domain)        Linux SoC (General-Purpose)
├─ Deterministic timing       ├─ No timing guarantees
├─ Limited resources          ├─ Abundant resources
├─ Sensor/motor control       ├─ Networking, storage
├─ Real-time loop             ├─ Service architecture
└─ FreeRTOS RTOS              └─ Linux kernel + systemd
```

---

## Data Flow Examples

### Example 1: Sensor Reading
```
1. MCU bare-metal timer interrupt (every 100ms)
2. ADC reads sensor value
3. FreeRTOS task processes & stores value
4. LVGL GUI task reads value → display on LCD
5. Periodically, MCU sends value to Linux via protocol
6. Linux Health Monitor receives → logs → publishes to MQTT
```

### Example 2: Motor Control Command from Cloud
```
1. Cloud sends MQTT message: "set motor speed = 50%"
2. Linux Network Manager receives → D-Bus signal
3. Linux Device Manager calls Motor service
4. Motor service sends command to MCU via protocol
5. MCU receives → FreeRTOS task updates PWM duty cycle
6. MCU controls motor via GPIO/PWM
7. MCU sends acknowledgment back to Linux
8. Linux publishes status: "motor speed = 50%, confirmed"
```

### Example 3: System Watchdog
```
1. Application watchdog on Linux sends heartbeat every 5 seconds
2. MCU counts heartbeats
3. If 3 heartbeats missed (15 seconds) → MCU resets Linux SoC
4. Linux boots, systemd starts services
5. Services resume normal operation
6. MCU detects Linux is back → resumes normal protocol
```

---

## Key Architectural Decisions

### ADR-0001: Dual Processor (MCU + Linux SoC)
**Why?** 
- MCU handles deterministic real-time tasks (control loop, sensor reading, GUI)
- Linux handles complex tasks (networking, storage, cloud integration)
- Redundancy: if Linux crashes, MCU can still operate independently

**Trade-off:**
- ✅ Better separation of concerns
- ✅ Real-time guarantees on MCU side
- ❌ Extra complexity: need custom protocol for inter-processor communication

### ADR-0002: Custom Protocol over UART/SPI/CAN
**Why?** 
- Full control over protocol design
- Learn protocol design (CRC, retry, versioning, fault tolerance)
- Protocol optimized for this specific use case

**Trade-off:**
- ✅ Understand protocol design deeply
- ❌ More work than using existing protocol (Modbus, MAVLink)
- ✅ Portfolio value: "designed and implemented protocol" sounds better than "used Modbus"

### ADR-0003: D-Bus for Linux IPC
**Why?**
- Industry standard (used in systemd, NetworkManager, etc.)
- Automatic service activation, introspection
- Message passing architecture

### ADR-0004: Buildroot + Yocto Both
**Why?**
- Buildroot: simpler, easier for learning
- Yocto: more powerful, used in production (automotive, embedded Linux products)
- Portfolio value: "familiar with both"

---

## Module Responsibilities

| Module | Layer | Responsibilities | Sprint |
|---|---|---|---|
| **Logger** | Middleware | Log messages to file (with rotation), log levels | 1 |
| **Config** | Middleware | Read/write JSON config, hot reload | 2 |
| **MCU Firmware** | MCU Application | Bare-metal + FreeRTOS + LVGL | 3–5 |
| **GPIO Driver** | Kernel Driver | Character device `/dev/gpio`, interrupt handling | 6 |
| **Device Mgr** | Linux Service | System info, D-Bus interface | 7 |
| **Health Mon** | Linux Service | CPU/RAM/disk monitoring, D-Bus interface | 8 |
| **D-Bus IPC** | Middleware | Wrapper for D-Bus communication | 9 |
| **Systemd** | Linux Daemon | Service management, auto-restart | 10–11 |
| **Watchdog** | Application | Application-level watchdog logic | 11 |
| **Protocol** | Communication | Linux↔MCU protocol (UART/SPI/CAN) | 13 |
| **Network** | Linux Service | MQTT client, cloud connectivity | 14 |
| **OTA** | Linux Service | Download/verify/install updates, rollback | 15 |
| **Security** | Middleware | TLS contexts, signature verification | 16 |

---

## Testing Strategy

### Unit Tests
- Logger, Config, Protocol modules → test in isolation
- No hardware, no kernel required

### Integration Tests
- Services communicating via D-Bus
- Require systemd running on Linux
- Optional: mock D-Bus for CI

### System Tests
- Full Linux image boots
- All services start
- Manual test: MCU connects, protocol works
- Fault injection: deliberately disconnect, timeout, corrupt data

### Hardware-in-the-Loop (HIL)
- Real MCU + Linux board + physical connection
- Fault injection: unplug cable, jam messages, reset MCU
- Verify recovery behavior

---

## What Changes Over Sprints

### Sprint 0–2: Infrastructure
- Build system setup
- CI pipeline
- Logging & config framework

### Sprint 3–5: MCU Firmware (V0.5)
- Add bare-metal MCU code
- Add FreeRTOS tasks
- Add LVGL GUI
- **Deliverable:** Standalone firmware, demo-able

### Sprint 6–11: Linux Platform (V1.0)
- Add kernel driver
- Add Linux services
- Add systemd integration
- **Deliverable:** Full platform (kernel + services), demo-able

### Sprint 12: Custom Image (V1.5)
- Add Buildroot/Yocto build
- Create complete image
- **Deliverable:** Bootable image, deploy-able

### Sprint 13–16: Integration & Security (V2.0 → V3.5)
- Add protocol, networking, OTA, security
- **Deliverable:** Production-ready system

---

## Deployment Architecture (Future, after V3.5)

```
┌─────────────────────────────────────────┐
│ Cloud Infrastructure                    │
│ ├─ MQTT Broker                          │
│ ├─ OTA Repository (signed packages)     │
│ ├─ Monitoring Dashboard                 │
│ └─ Firmware Version Database            │
└─────────────────────────────────────────┘
              │
              │ MQTT/HTTPS
              │
      ┌───────▼──────────┐
      │ ELDMP Device     │
      │ (Deployed)       │
      │                  │
      │ ┌──────────────┐ │
      │ │ Linux SoC    │ │
      │ │ + Services   │ │
      │ └──────┬───────┘ │
      │        │ CAN/SPI │
      │ ┌──────▼──────┐  │
      │ │ MCU         │  │
      │ │ + Control   │  │
      │ └─────────────┘  │
      │                  │
      │ ┌─────────────┐  │
      │ │ LCD Display │  │
      │ │ (LVGL UI)   │  │
      │ └─────────────┘  │
      └──────────────────┘
```

---

## Performance Characteristics

### MCU (FreeRTOS)
- Control loop: **deterministic** 100 Hz (±1%)
- Task switching overhead: < 10 µs
- GUI refresh: 30 fps (LVGL on LCD)
- Protocol latency: < 100 ms end-to-end

### Linux (SoC)
- Response time: seconds (non-real-time)
- MQTT publish: < 1 second (cloud connectivity)
- Service restart: < 5 seconds (systemd)
- OTA download: depends on network speed

---

## Extensibility Points (for Future)

1. **WebUI** (Extension Track V7.0)
   - Add REST API → frontend framework (React/Vue)
   - Deploy on Linux SoC

2. **Cloud Integration** (V7.0+)
   - Current: MQTT only
   - Future: gRPC, REST API, custom cloud connector

3. **Secure Boot** (Extension Track V5.0)
   - Current: TLS on network only
   - Future: Trusted Firmware-A, OP-TEE

4. **Real-Time Linux** (V6.0)
   - Current: MCU for real-time
   - Future: PREEMPT_RT kernel for Linux real-time

5. **AI/ROS2** (V8.0)
   - Current: Basic sensor → motor control
   - Future: Edge inference, ROS2 middleware

---

## Kiến Trúc Môi Trường Phát Triển & Build

> Lưu ý: mục này mô tả **hệ thống dùng để build ELDMP**, khác với kiến trúc **sản phẩm** ELDMP (MCU + Linux SoC) mô tả ở các mục trên. Chi tiết vận hành đầy đủ nằm trong [`SETUP.md`](../SETUP.md).

### Vấn Đề Cần Giải Quyết

Máy phát triển ban đầu là MacBook Pro M1 (Apple Silicon, 8GB RAM, macOS 11.7.11 Big Sur). Dự án cần build ba loại target khác nhau:

| Target | Kiến trúc | Sprint | Nơi build |
|---|---|---|---|
| MCU bare-metal / FreeRTOS (STM32F446, STM32H743) | ARM Cortex-M (arm-none-eabi) | 3–5 | Ubuntu Server (host hoặc container) |
| Linux App cross-compile (BeagleBone Black) | armv7 (Cortex-A8, armhf) | 6, 13 | Ubuntu Server — chỉ compile/phân tích, không build OS image |
| Buildroot/Yocto **image đầy đủ** | armv7, build host cần nhiều RAM/disk | 12 | **Máy Linux chuyên dụng riêng** (không phải máy phát triển chính) |

### Lịch Sử Quyết Định Môi Trường (Portfolio Value)

Dự án đã trải qua 4 giai đoạn công cụ, mỗi lần chuyển đổi có lý do kỹ thuật cụ thể, không phải thay đổi tuỳ hứng:

1. **Lima** — VM Linux mã nguồn mở đầu tiên, hoạt động nhưng cần cài Docker riêng bên trong.
2. **OrbStack** — cấp RAM động, Docker Engine tích hợp sẵn, nhưng yêu cầu macOS mới hơn Big Sur.
3. **Colima** — thử tiếp vì mã nguồn mở và dùng QEMU (lý thuyết hoạt động trên macOS cũ), nhưng **THẤT BẠI THẬT khi cài đặt trên macOS 11.7.11 Big Sur** — Colima đã ngừng hỗ trợ phiên bản macOS này. Đây là lỗi thực tế đã gặp, không phải rủi ro suy đoán trước.
4. **Ubuntu Server Native + Docker Engine chuẩn công nghiệp** (hiện tại) — dùng **VMware Fusion Professional** (bản Pro, mã phiên bản bạn cung cấp: 20191287) để cài Ubuntu Server 26.04 LTS ARM64 trực tiếp. **Đính chính:** ghi chú trước đó trong tài liệu này từng loại VMware Fusion vì cho rằng Fusion 13 yêu cầu tối thiểu macOS 12 Monterey — trên thực tế, bản Fusion Pro cụ thể này đã chạy tốt trên macOS 11.7.11 Big Sur (mã phiên bản 20191287 do bạn cung cấp, tôi chưa xác minh được tương ứng chính xác version Fusion nào); bằng chứng thực nghiệm trực tiếp — đã cài và chạy Ubuntu Server thành công — được ưu tiên hơn thông tin suy đoán trước đó. Từ điểm cài đặt Ubuntu Server thành công trở đi, **toàn bộ môi trường không còn phụ thuộc macOS/công cụ ảo hoá nào nữa**.

### Kiến Trúc Được Chọn: Ubuntu Server Native + Docker Engine Chính Thức

```
Client Workstation (macOS/Windows/Linux — bất kỳ, không còn ràng buộc)
 └─ VS Code (Remote-SSH) ──────────────────► Ubuntu Server 26.04 LTS ARM64
      └─ Dev Containers (Reopen in Container)  (bare-metal / VM bất kỳ / Cloud)
           → Docker Engine NATIVE của server,
             không qua wrapper/socket forward     Docker Engine (apt chính thức)
                                                    Swap 4GB, sysctl tối ưu
                                                    daemon.json (log limit)
                                                    └─ eldmp-toolchain container:
                                                       arm-none-eabi-gcc,
                                                       arm-linux-gnueabihf-gcc,
                                                       Cppcheck/Clang-Tidy/
                                                       Sanitizers/Valgrind/
                                                       Unity/CMock/GoogleTest

        Máy Linux chuyên dụng riêng (ngoài máy phát triển chính)
        └─ Build Yocto/Buildroot image đầy đủ (Sprint 12)
```

**Quyết định kỹ thuật cốt lõi:** dùng **Ubuntu Server + Docker Engine cài qua apt repository chính thức của Docker Inc.** — không dùng bất kỳ công cụ wrapper/giả lập ảo hoá macOS nào (Lima, OrbStack, Colima, VMware Fusion, Docker Desktop).

**Vì sao đây là điểm dừng chân kiến trúc, không phải "công cụ thứ 5":** Docker Engine cài qua apt trên Ubuntu Server là **tiêu chuẩn ngành**, không phải sản phẩm của một công ty tư nhân có vòng đời hỗ trợ macOS riêng có thể thay đổi bất cứ lúc nào (như đã xảy ra với Colima). Toàn bộ script/tài liệu từ đây không còn nhắc gì tới phiên bản macOS cụ thể — chạy được y nguyên trên bare-metal, VM với hypervisor bất kỳ, hay Cloud Instance.

**Ranh giới rõ ràng giữa các thành phần:**

| Việc | Thực hiện ở đâu | Vì sao |
|---|---|---|
| Viết code, compile (mọi sprint trừ 12) | Trên Ubuntu Server (host hoặc qua Remote-SSH) | Toolchain Linux thật, nhất quán với CI |
| Git clone/commit/push | Trên Ubuntu Server (`~/eldmp`) | Toolchain + git cùng một chỗ |
| Static/dynamic analysis, sanitizers, testing nâng cao | Docker container (`eldmp-toolchain`), Docker Engine native | Không cần cấu hình socket/context — Docker đã chạy sẵn trên chính server |
| **Build image Yocto/Buildroot đầy đủ (Sprint 12)** | **Máy Linux chuyên dụng riêng** | RAM máy phát triển chính không đủ — quyết định kiến trúc dài hạn |
| Flash firmware qua ST-Link (Sprint 3+) | **Máy có cổng USB vật lý** | USB passthrough vào VM (nếu dùng VM) chưa xác minh ổn định với mọi hypervisor |

### CI/CD — Ba Tầng

| Tầng | Runner | Dùng cho |
|---|---|---|
| 1 — Nhẹ | `ubuntu-24.04-arm` (GitHub-hosted, miễn phí với repo public) | Sprint 0–2, 7–11: build/test C++ |
| 2 — Vừa | `self-hosted` (Ubuntu Server chính, label `ubuntu-server-native`) | Sprint 6, 13: cross-compile/phân tích Linux app, protocol |
| 3 — Nặng | `self-hosted` (máy Linux riêng, label `yocto-build-server`) | Sprint 12: build Yocto/Buildroot image đầy đủ |

### Đánh Đổi Đã Biết Trước

- **ĐÁNH GIÁ KỸ THUẬT:** việc build Yocto/Buildroot trên máy Linux riêng đòi hỏi tự quản lý một máy chủ thứ hai — chi phí vận hành thật, đổi lấy việc máy phát triển chính không phải gánh workload vượt khả năng RAM.
- Nếu máy phát triển chính là VM (không phải bare-metal), USB passthrough cho flash MCU tuỳ thuộc hypervisor và chưa được xác minh ổn định trong tài liệu này — flash từ máy vật lý luôn là phương án chắc chắn.
- Docker Engine + toolchain container dùng chung tài nguyên vật lý với mọi compile trực tiếp trên host — cần theo dõi RAM/swap khi chạy đồng thời nhiều tác vụ nặng, đặc biệt trên cấu hình tham chiếu 3.5GB RAM.

Chi tiết cài đặt từng bước, script bootstrap, Dockerfile/DevContainer, troubleshooting → [`SETUP.md`](../SETUP.md).

## For More Details

- **[ARCHITECTURE.md](architecture/ARCHITECTURE.md)** — Deep dive into each layer
- **[ADR Decisions](architecture/decisions/)** — Architectural decisions explained
- **[ELDMP_Roadmap_MCU_vi.md](learning/reference_01/ELDMP_Roadmap_MCU_vi.md)** — Roadmap with technical details
- **[../SETUP.md](../SETUP.md)** — Hướng dẫn setup Ubuntu Server Native + Docker Engine đầy đủ, từng bước

---

**Last Updated:** Sprint 0 (Milestone 0.1) — cập nhật kiến trúc môi trường phát triển sang Ubuntu Server Native + Docker Engine (từ Lima → OrbStack → Colima → Ubuntu Server Native)  
**Next Review:** Sprint 6 (Kernel & Device Tree)  
**Status:** 📐 Architecture framework ready
