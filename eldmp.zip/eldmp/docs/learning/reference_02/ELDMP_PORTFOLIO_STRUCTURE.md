# ELDMP Portfolio Repository Structure

**Purpose:** A learning portfolio demonstrating embedded systems skills progression through completed projects, NOT a framework or template.

---

## Complete Repository Structure

```
eldmp-portfolio/
├── README.md                                # Project overview & results
├── SETUP.md                                 # Installation & build instructions
├── LICENSE                                  # MIT or Apache 2.0
├── .gitignore
├── .clang-format
│
├── docs/
│   ├── README.md                           # Documentation index
│   ├── ARCHITECTURE.md                     # System design overview
│   │
│   ├── learning/                           # All learning materials organized by sprint
│   │   ├── EMBEDDED_C_FUNDAMENTALS.md      # Sprint Learning: C foundations
│   │   ├── ARM_CORTEX_M.md                 # Sprint 3: MCU architecture
│   │   ├── FREERTOS_BASICS.md              # Sprint 4: RTOS concepts
│   │   ├── LVGL_GUI.md                     # Sprint 5: Embedded GUI
│   │   ├── LINUX_KERNEL.md                 # Sprint 6: Kernel fundamentals
│   │   ├── SYSTEMD_SERVICES.md             # Sprint 11: Service management
│   │   └── README.md                       # Learning guide index
│   │
│   ├── architecture/                       # Design decisions & ADRs
│   │   ├── ARCHITECTURE.md                 # System design document
│   │   └── decisions/
│   │       ├── ADR-001-soc-mcu-separation.md
│   │       ├── ADR-002-can-protocol.md
│   │       ├── ADR-003-systemd-integration.md
│   │       └── ADR-004-ota-strategy.md
│   │
│   └── release-notes/                      # Version release documentation
│       ├── V0.5-RELEASE.md                 # MCU Firmware Complete
│       ├── V1.0-RELEASE.md                 # Linux Platform Complete
│       ├── V1.5-RELEASE.md                 # Custom Image Complete
│       ├── V2.0-RELEASE.md                 # Full Integration Complete
│       └── V3.5-RELEASE.md                 # Production Ready
│
├── src/                                    # All source code (organized by sprint)
│   ├── CMakeLists.txt                      # Root build configuration
│   │
│   ├── common/                             # Shared utilities (used by all sprints)
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── types.h                     # Common types & error codes
│   │   │   ├── macros.h                    # Compiler directives, bit macros
│   │   │   ├── circular_buffer.h           # Reusable FIFO queue
│   │   │   └── error_codes.h
│   │   └── src/
│   │       ├── circular_buffer.c
│   │       └── common.c
│   │
│   ├── learning/                           # Sprint Learning: Embedded C Practice
│   │   ├── CMakeLists.txt
│   │   ├── practice/
│   │   │   ├── 01_memory_layout.c          # Memory layout demonstration
│   │   │   ├── 02_volatile_example.c       # Volatile keyword in MMIO
│   │   │   ├── 03_pointer_arithmetic.c     # Pointers & callbacks
│   │   │   ├── 04_bitwise_operations.c     # Register bit manipulation
│   │   │   └── 05_circular_buffer.c        # Data structure implementation
│   │   └── README.md                       # Sprint Learning guide
│   │
│   ├── sprint1-logger/                     # Sprint 1: Logger Module
│   │   ├── CMakeLists.txt
│   │   ├── include/logger.h
│   │   ├── src/logger.c
│   │   └── README.md
│   │
│   ├── sprint2-config/                     # Sprint 2: Configuration Manager
│   │   ├── CMakeLists.txt
│   │   ├── include/config.h
│   │   ├── src/config.c
│   │   ├── config.json                     # Default configuration
│   │   └── README.md
│   │
│   ├── sprint3-bare-metal/                 # Sprint 3: Bare-Metal MCU
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── mcu.h
│   │   │   ├── gpio.h
│   │   │   ├── uart.h
│   │   │   └── interrupt.h
│   │   ├── src/
│   │   │   ├── startup.c                   # Startup code
│   │   │   ├── mcu.c
│   │   │   ├── gpio.c                      # GPIO driver
│   │   │   ├── uart.c                      # UART driver
│   │   │   └── interrupt.c                 # Interrupt handlers
│   │   └── README.md
│   │
│   ├── sprint4-freertos/                   # Sprint 4: FreeRTOS Integration
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── freertos_config.h           # FreeRTOS configuration
│   │   │   ├── task_sensor.h
│   │   │   └── task_control.h
│   │   ├── src/
│   │   │   ├── task_sensor.c               # Sensor reading task
│   │   │   ├── task_control.c              # Control loop task
│   │   │   └── task_main.c                 # Main FreeRTOS task
│   │   └── README.md
│   │
│   ├── sprint5-lvgl-gui/                   # Sprint 5: Embedded GUI
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── ui_config.h
│   │   │   └── screens.h
│   │   ├── src/
│   │   │   ├── ui_init.c                   # LVGL initialization
│   │   │   ├── screens.c                   # UI screens
│   │   │   ├── display_driver.c            # Display interface
│   │   │   └── input_driver.c              # Touch/input interface
│   │   ├── assets/                         # UI assets (fonts, images)
│   │   └── README.md
│   │
│   ├── sprint6-kernel-driver/              # Sprint 6: Linux Kernel Driver
│   │   ├── CMakeLists.txt
│   │   ├── gpio_driver.c                   # Character device driver
│   │   ├── gpio_driver.h
│   │   ├── Makefile.kernel                 # Kernel module build
│   │   └── README.md
│   │
│   ├── sprint7-device-manager/             # Sprint 7: Device Manager
│   │   ├── CMakeLists.txt
│   │   ├── include/device_manager.h
│   │   ├── src/device_manager.c
│   │   ├── src/main.c
│   │   └── README.md
│   │
│   ├── sprint8-health-monitor/             # Sprint 8: Health Monitor
│   │   ├── CMakeLists.txt
│   │   ├── include/health_monitor.h
│   │   ├── src/health_monitor.c
│   │   ├── src/main.c
│   │   └── README.md
│   │
│   ├── sprint9-dbus-ipc/                   # Sprint 9: D-Bus IPC
│   │   ├── CMakeLists.txt
│   │   ├── include/dbus_interface.h
│   │   ├── src/dbus_interface.c
│   │   ├── dbus/
│   │   │   └── eldmp.service.xml           # D-Bus interface definition
│   │   └── README.md
│   │
│   ├── sprint10-system-daemon/             # Sprint 10: System Daemon
│   │   ├── CMakeLists.txt
│   │   ├── include/daemon.h
│   │   ├── src/daemon.c
│   │   ├── src/main.c
│   │   └── README.md
│   │
│   ├── sprint11-systemd/                   # Sprint 11: Systemd Integration
│   │   ├── CMakeLists.txt
│   │   ├── systemd/
│   │   │   ├── eldmp.service              # Main service unit
│   │   │   ├── eldmp-device.service       # Device manager unit
│   │   │   ├── eldmp-monitor.service      # Health monitor unit
│   │   │   └── eldmp.target               # Target grouping
│   │   └── README.md
│   │
│   ├── sprint12-yocto/                     # Sprint 12: Buildroot/Yocto
│   │   ├── CMakeLists.txt
│   │   ├── meta-eldmp/
│   │   │   ├── conf/
│   │   │   │   ├── layer.conf
│   │   │   │   └── machine/boneblack.conf
│   │   │   ├── recipes-app/
│   │   │   │   └── eldmp_3.5.bb            # Main recipe
│   │   │   └── recipes-core/
│   │   ├── buildroot/
│   │   │   ├── config.in
│   │   │   └── Config.in
│   │   └── README.md
│   │
│   ├── sprint13-protocol/                  # Sprint 13: Custom Protocol & CAN
│   │   ├── CMakeLists.txt
│   │   ├── protocol/
│   │   │   ├── eldmp_protocol.h            # Protocol definition
│   │   │   ├── eldmp_protocol.c
│   │   │   ├── crc.h                       # CRC calculation
│   │   │   └── crc.c
│   │   ├── can/
│   │   │   ├── can_driver.h
│   │   │   └── can_driver.c
│   │   └── README.md
│   │
│   ├── sprint14-networking/                # Sprint 14: Networking & MQTT
│   │   ├── CMakeLists.txt
│   │   ├── mqtt/
│   │   │   ├── mqtt_client.h
│   │   │   └── mqtt_client.c
│   │   ├── network/
│   │   │   └── network_config.c
│   │   └── README.md
│   │
│   ├── sprint15-ota/                       # Sprint 15: OTA Updates
│   │   ├── CMakeLists.txt
│   │   ├── include/ota_manager.h
│   │   ├── src/
│   │   │   ├── ota_manager.c
│   │   │   ├── update_handler.c
│   │   │   └── rollback.c
│   │   └── README.md
│   │
│   ├── sprint16-security/                  # Sprint 16: Security & TLS
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── tls_manager.h
│   │   │   └── crypto.h
│   │   ├── src/
│   │   │   ├── tls_manager.c
│   │   │   ├── crypto.c
│   │   │   └── key_manager.c
│   │   ├── keys/                          # Certificates and keys
│   │   │   ├── README.md                  # Key generation guide
│   │   │   └── .gitignore                 # Never commit private keys
│   │   └── README.md
│   │
│   └── app/                                # Main application (integrates all)
│       ├── CMakeLists.txt
│       ├── main.cpp                        # Entry point
│       ├── cli.cpp                         # Command-line interface
│       └── README.md
│
├── tests/                                  # Test suite (mirrors src/ organization)
│   ├── CMakeLists.txt
│   │
│   ├── learning/                           # Tests for Sprint Learning
│   │   ├── CMakeLists.txt
│   │   ├── test_circular_buffer.c
│   │   ├── test_bit_macros.c
│   │   └── test_defensive_patterns.c
│   │
│   ├── unit/                               # Unit tests per module
│   │   ├── CMakeLists.txt
│   │   ├── test_logger.cpp
│   │   ├── test_config.cpp
│   │   ├── test_gpio.cpp
│   │   ├── test_circular_buffer.cpp
│   │   ├── test_protocol.cpp
│   │   ├── test_mqtt.cpp
│   │   └── ... (one per sprint module)
│   │
│   ├── integration/                       # Integration tests
│   │   ├── CMakeLists.txt
│   │   ├── test_logger_config.cpp          # Logger + Config together
│   │   ├── test_device_dbus.cpp            # Device Manager + D-Bus
│   │   ├── test_monitor_dbus.cpp           # Health Monitor + D-Bus
│   │   └── test_mcu_protocol.cpp           # MCU↔Linux over protocol
│   │
│   └── fixtures/                           # Test data
│       ├── sample_config.json
│       ├── test_certificates.pem
│       └── mock_device_data.bin
│
├── scripts/                                # Build & deployment scripts
│   ├── build.sh                            # Complete build script
│   ├── build-mcu.sh                        # MCU firmware compile
│   ├── flash-mcu.sh                        # Upload to STM32
│   ├── build-kernel.sh                     # Kernel module build
│   ├── build-image.sh                      # Yocto/Buildroot image
│   ├── format-code.sh                      # Code formatting (clang-format)
│   ├── static-check.sh                     # Static analysis (cppcheck)
│   ├── run-tests.sh                        # All tests
│   └── release.sh                          # Release tagging
│
├── notes/                                  # Sprint learning journals
│   ├── README.md                           # How to write sprint notes
│   ├── SPRINT_TEMPLATE.md                  # Template for each sprint
│   ├── sprint-learning.md                  # Sprint Learning notes
│   ├── sprint-1.md                         # Sprint 1 notes
│   ├── sprint-2.md                         # Sprint 2 notes
│   └── ... (one per sprint)
│
├── .github/                                # GitHub configuration
│   └── workflows/
│       ├── build.yml                       # Build CI pipeline
│       ├── tests.yml                       # Test CI pipeline
│       └── release.yml                     # Release automation
│
├── build/                                  # CMake build output (git-ignored)
│   └── (generated during build)
│
└── releases/                               # Release artifacts (git-ignored)
    └── (built images, binaries)
```

---

## Key Design Decisions

### 1. **Sprint-Based Organization, Not Modules**

```
src/
├── learning/              # Sprint Learning (C fundamentals)
├── sprint1-logger/        # Sprint 1 (Logger)
├── sprint2-config/        # Sprint 2 (Config)
├── sprint3-bare-metal/    # Sprint 3 (MCU)
└── ... (clearly named after sprints)
```

**Why:** 
- Clear learning progression
- Easy to navigate roadmap
- Each sprint is self-contained
- Easy to reference in portfolio discussion

### 2. **Shared `common/` Directory**

```
common/
├── include/types.h        # Used by all sprints
├── include/macros.h       # Bit manipulation (Sprint Learning)
├── include/circular_buffer.h  # Data structure (Sprint Learning)
└── src/circular_buffer.c   # Reusable implementation
```

**Why:**
- Code reuse across sprints
- Clear dependency management
- Single source of truth for shared patterns

### 3. **`docs/learning/` Organized by Sprint**

```
docs/learning/
├── EMBEDDED_C_FUNDAMENTALS.md    # Sprint Learning
├── ARM_CORTEX_M.md               # Sprint 3
├── FREERTOS_BASICS.md            # Sprint 4
├── LVGL_GUI.md                   # Sprint 5
└── LINUX_KERNEL.md               # Sprint 6
```

**Why:**
- Easy to find materials relevant to current sprint
- Shows structured learning progression
- Professional documentation organization

### 4. **CMake Modular Build**

Each sprint directory has its own `CMakeLists.txt`:

```cmake
# Root CMakeLists.txt
add_subdirectory(src/common)
add_subdirectory(src/learning)
add_subdirectory(src/sprint1-logger)
# ... etc
```

**Why:**
- Scale from Phase 1 → Phase 5 without restructuring
- Easy to enable/disable sprints during development
- Professional build system

### 5. **Comprehensive Testing**

```
tests/
├── learning/           # Tests for Sprint Learning exercises
├── unit/               # Unit tests for each module
└── integration/        # Cross-module tests
```

**Why:**
- Demonstrates testing discipline
- Each component verified
- Integration between components validated

---

## What This Structure Communicates

### To Recruiters
✅ "I followed a structured learning plan"  
✅ "My code is organized professionally"  
✅ "I understand test-driven development"  
✅ "I can build scalable systems"  
✅ "My learning is documented and reproducible"  

### To Interviewers
✅ "I can explain my learning journey clearly"  
✅ "Each piece of code can be discussed in depth"  
✅ "Technical decisions are documented (ADRs)"  
✅ "I understand embedded systems progression"  
✅ "My knowledge compounds across sprints"  

---

## Git Workflow With This Structure

### Sprint Learning
```bash
git add src/learning/
git add src/common/include/circular_buffer.h
git add src/common/src/circular_buffer.c
git commit -m "Sprint Learning: Embedded C fundamentals & circular buffer"
git tag v0.1
```

### Sprint 1-2
```bash
git add src/sprint1-logger/
git add tests/unit/test_logger.cpp
git commit -m "Sprint 1: Logger module with file rotation"
git tag v0.1.1
```

### Releases
```bash
# After completing sprints 3-5
git tag v0.5

# After completing sprints 6-10
git tag v1.0

# And so on...
```

---

## Directory Naming Conventions

| Type | Format | Example |
|------|--------|---------|
| Sprint directory | `sprint<N>-<name>` | `sprint1-logger`, `sprint6-kernel-driver` |
| Learning directory | `learning` | `src/learning/`, `docs/learning/` |
| Include files | `.h` | `logger.h`, `circular_buffer.h` |
| Source files | `.c` or `.cpp` | `logger.c`, `main.cpp` |
| Tests | `test_<name>.cpp` | `test_logger.cpp` |
| Scripts | `*.sh` | `build.sh`, `format-code.sh` |

---

## Building the Project

```bash
# Setup
cd eldmp-portfolio
mkdir build && cd build

# Configure CMake
cmake ..

# Build all
cmake --build .

# Run specific sprint's exercise
./phase1_01_memory_layout

# Run tests
ctest --output-on-failure

# Build release
cmake --build . --config Release
```

---

## Scalability

### Adding a New Sprint

1. Create directory: `src/sprint<N>-<name>/`
2. Add `CMakeLists.txt`
3. Create `include/` and `src/` subdirectories
4. Update root `src/CMakeLists.txt`: `add_subdirectory(sprint<N>-<name>)`
5. Add tests: `tests/unit/test_sprint<N>.cpp`
6. Add notes: `notes/sprint-<N>.md`
7. Rebuild: `cmake --build build/`

### Adding Learning Materials

1. Create: `docs/learning/<topic>.md`
2. Reference in sprint's technical note
3. Update `docs/learning/README.md` index

---

## GitHub Actions Integration

Automated on every push:
- ✅ Build all source code
- ✅ Run all tests
- ✅ Check code warnings
- ✅ Generate coverage report (optional)

---

## Professional Polish

- [ ] README.md with project overview
- [ ] LICENSE file (MIT recommended)
- [ ] .gitignore properly configured
- [ ] .clang-format for consistent style
- [ ] BUILD_STATUS badge on README
- [ ] Release notes for each version
- [ ] ADRs for major decisions
- [ ] Comprehensive CMakeLists.txt

---

## This is NOT

❌ A framework to build projects on  
❌ A starter template  
❌ An example application  
❌ Scaffold for learning  

## This IS

✅ A portfolio demonstrating learning progression  
✅ Evidence of structured, self-directed learning  
✅ Well-organized source code for each sprint  
✅ Professional repository organization  
✅ Interview-ready project structure  

---

**Status:** Structure complete and ready for implementation  
**First Sprint:** Sprint Learning (Embedded C Fundamentals)  
**Next Milestone:** v0.1 tag after Sprint Learning completion
