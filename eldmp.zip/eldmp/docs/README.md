# ELDMP Documentation Index

Hướng dẫn tài liệu và cách điều hướng dự án ELDMP.

---

## Nhanh Chóng Bắt Đầu

- **[../SETUP.md](../SETUP.md)** — Cách cài đặt môi trường (yêu cầu hệ thống, công cụ, build)
- **[../README.md](../README.md)** — Tổng quan dự án (mục tiêu, lộ trình, kỹ năng)

---

## Tài Liệu Kiến Trúc Hệ Thống

### Tổng Quan Hệ Thống
- **[ARCHITECTURE.md](ARCHITECTURE.md)** — Sơ đồ kiến trúc toàn hệ thống, các lớp chính, luồng dữ liệu

### Chi Tiết Kiến Trúc Từng Lớp
- **[architecture/ARCHITECTURE.md](architecture/ARCHITECTURE.md)** — Chi tiết từng lớp (Kernel, HAL, Driver, Middleware, Services, Application)
- **[architecture/decisions/](architecture/decisions/)** — Architecture Decision Records (ADR)
  - **ADR-0001:** Tách riêng SoC Linux + MCU thời gian thực
  - **ADR-0002:** Dùng cả Buildroot lẫn Yocto (Sprint 12)
  - **ADR-0003:** Dùng D-Bus cho IPC (Sprint 9)
  - **ADR-0004:** Thiết kế protocol tuỳ chỉnh Linux↔MCU (Sprint 13)

---

## Release Notes & Versioning

Tài liệu phát hành cho mỗi milestone chính:

- **[release-notes/V0.5-RELEASE.md](release-notes/V0.5-RELEASE.md)** — Sprint 5 — MCU firmware (FreeRTOS + LVGL)
- **[release-notes/V1.0-RELEASE.md](release-notes/V1.0-RELEASE.md)** — Sprint 11 — Linux platform (kernel + services)
- **[release-notes/V1.5-RELEASE.md](release-notes/V1.5-RELEASE.md)** — Sprint 12 — Custom image (Buildroot/Yocto)
- **[release-notes/V2.0-RELEASE.md](release-notes/V2.0-RELEASE.md)** — Sprint 13 — Full integration (protocol + networking)
- **[release-notes/V2.5-RELEASE.md](release-notes/V2.5-RELEASE.md)** — Sprint 14 — Networking & MQTT
- **[release-notes/V3.0-RELEASE.md](release-notes/V3.0-RELEASE.md)** — Sprint 15 — OTA updates
- **[release-notes/V3.5-RELEASE.md](release-notes/V3.5-RELEASE.md)** — Sprint 16 — Security & TLS (Core Track complete)

---

## Learning Materials & Sprint Notes

### Sprint Learning (Trước Sprint 1)
- **[learning/EMBEDDED_C_MASTERY_GUIDE.md](learning/EMBEDDED_C_MASTERY_GUIDE.md)** — C foundations (memory layout, volatile, pointers, bitwise ops) — đã hoàn thành ở Milestone 0.2

### Phase 1: MCU (Sprint 3–5)
- **[learning/ARM_CORTEX_M.md](learning/ARM_CORTEX_M.md)** — ARM Cortex-M architecture (Sprint 3 prep)
- **[learning/FREERTOS_BASICS.md](learning/FREERTOS_BASICS.md)** — FreeRTOS concepts (Sprint 4 prep)
- **[learning/LVGL_GUI.md](learning/LVGL_GUI.md)** — LVGL GUI design (Sprint 5 prep)

### Phase 2: Linux (Sprint 6–11)
- **[learning/LINUX_KERNEL.md](learning/LINUX_KERNEL.md)** — Linux kernel fundamentals (Sprint 6 prep)
- **[learning/SYSTEMD_SERVICES.md](learning/SYSTEMD_SERVICES.md)** — systemd concepts (Sprint 10 prep)

> **Ghi chú (nguyên tắc không phức tạp hoá — mục 16 Mentor Protocol):** tài liệu learning cho Sprint 9 (D-Bus), 12 (Buildroot/Yocto), 13 (protocol), 14 (MQTT), 15 (OTA), 16 (TLS) **chưa được tạo trước** — sẽ bổ sung đúng lúc từng sprint đó thực sự cần, thay vì tạo sẵn placeholder cho những chủ đề còn cách xa hiện tại. Đây là quyết định có chủ đích, không phải thiếu sót.

---

## Sprint Learning Journals

Chi tiết ghi chú học tập cho mỗi sprint (300–600 từ):

### Core Track Sprints
- **[../notes/sprint-0.md](../notes/sprint-0.md)** — Milestone 0.1: Environment setup
- **[../notes/sprint-1.md](../notes/sprint-1.md)** — Sprint 1: Logger module
- **[../notes/sprint-2.md](../notes/sprint-2.md)** — Sprint 2: Config manager
- **[../notes/sprint-3.md](../notes/sprint-3.md)** — Sprint 3: Bare-metal MCU
- **[../notes/sprint-4.md](../notes/sprint-4.md)** — Sprint 4: FreeRTOS
- **[../notes/sprint-5.md](../notes/sprint-5.md)** — Sprint 5: LVGL GUI
- **[../notes/sprint-6.md](../notes/sprint-6.md)** — Sprint 6: Kernel & Device Tree
- **[../notes/sprint-7.md](../notes/sprint-7.md)** — Sprint 7: Device Manager
- **[../notes/sprint-8.md](../notes/sprint-8.md)** — Sprint 8: Health Monitor
- **[../notes/sprint-9.md](../notes/sprint-9.md)** — Sprint 9: D-Bus IPC
- **[../notes/sprint-10.md](../notes/sprint-10.md)** — Sprint 10: systemd
- **[../notes/sprint-11.md](../notes/sprint-11.md)** — Sprint 11: Watchdog
- **[../notes/sprint-12.md](../notes/sprint-12.md)** — Sprint 12: Build system
- **[../notes/sprint-13.md](../notes/sprint-13.md)** — Sprint 13: Custom protocol
- **[../notes/sprint-14.md](../notes/sprint-14.md)** — Sprint 14: Networking
- **[../notes/sprint-15.md](../notes/sprint-15.md)** — Sprint 15: OTA
- **[../notes/sprint-16.md](../notes/sprint-16.md)** — Sprint 16: Security

---

## API Documentation

Chưa tạo trước theo nguyên tắc không phức tạp hoá (mục 16 Mentor Protocol) — tài liệu API sẽ được thêm ngay trong thư mục từng module (`src/sprintN-*/README.md`) khi module đó hoàn thành, thay vì dựng sẵn một cây `docs/api/` cho các module chưa viết dòng code nào.

---

## Repository Structure & Portfolio

- **[ELDMP_PORTFOLIO_STRUCTURE.md](learning/reference_02/ELDMP_PORTFOLIO_STRUCTURE.md)** — Cấu trúc toàn bộ repo + lý do thiết kế
- **[ELDMP_Roadmap_MCU_vi.md](learning/reference_01/ELDMP_Roadmap_MCU_vi.md)** — Roadmap chi tiết (lộ trình phát triển, timeline, hardware)

---

## External Resources & References

### Books & Learning Materials
- *The C Programming Language* (K&R) — Sprint Learning
- *Mastering STM32* (Carmine Noviello) — Sprint 3–5
- *Mastering the FreeRTOS Real Time Kernel* (Richard Barry) — Sprint 4
- *Linux Kernel Development* (Robert Love) — Sprint 6
- *Linux Device Drivers* (3rd ed., LDD3) — Sprint 6
- *OSTEP* (Operating Systems: Three Easy Pieces) — Sprint 6–11
- *The Linux Programming Interface* (TLPI, Michael Kerrisk) — Sprint 1–16

### Official Documentation
- **ARM Cortex-M:** https://developer.arm.com/ip-products/processors/cortex-m
- **STM32 Reference Manual:** https://www.st.com/ (device-specific)
- **FreeRTOS:** https://www.freertos.org/
- **LVGL:** https://lvgl.io/
- **Linux Kernel:** https://www.kernel.org/ + `Documentation/` trong source
- **Buildroot:** https://buildroot.org/
- **Yocto Project:** https://www.yoctoproject.org/

---

## Cách Sử Dụng Tài Liệu

### Cho Người Mới Bắt Đầu (Sprint 0)
1. Đọc [../README.md](../README.md) — Hiểu dự án tổng quan
2. Làm theo [../SETUP.md](../SETUP.md) — Cài đặt môi trường
3. Xem [ARCHITECTURE.md](ARCHITECTURE.md) — Hiểu kiến trúc hệ thống
4. Kiểm tra [../notes/sprint-0.md](../notes/sprint-0.md) — Ghi chú của sprint hiện tại

### Khi Bắt Đầu Một Sprint Mới
1. Đọc roadmap chi tiết cho sprint đó trong [ELDMP_Roadmap_MCU_vi.md](learning/reference_01/ELDMP_Roadmap_MCU_vi.md)
2. Ôn các tài liệu learning liên quan (ví dụ: Sprint 3 → đọc [learning/ARM_CORTEX_M.md](learning/ARM_CORTEX_M.md))
3. Xem ghi chú sprint trước để hiểu context
4. Sau khi hoàn thành sprint → Viết ghi chú lại trong `../notes/sprint-N.md`

### Khi Phỏng Vấn / Trình Bày Portfolio
1. Dùng [release-notes/](release-notes/) để nói về các milestone chính (V0.5, V1.0, v.v.)
2. Tham chiếu [architecture/decisions/](architecture/decisions/) để giải thích các quyết định kỹ thuật
3. Kể câu chuyện từ [../notes/](../notes/) để chứng minh học được gì
4. Dùng [ELDMP_PORTFOLIO_STRUCTURE.md](learning/reference_02/ELDMP_PORTFOLIO_STRUCTURE.md) để giải thích tại sao code được tổ chức như vậy

---

## Navigation Quick Links

| Nhu Cầu | Đi Tới |
|---|---|
| "Cách setup?" | [../SETUP.md](../SETUP.md) |
| "Dự án này làm gì?" | [../README.md](../README.md) |
| "Kiến trúc hệ thống ra sao?" | [ARCHITECTURE.md](ARCHITECTURE.md) |
| "Chi tiết từng lớp?" | [architecture/ARCHITECTURE.md](architecture/ARCHITECTURE.md) |
| "Quyết định kỹ thuật là gì?" | [architecture/decisions/](architecture/decisions/) |
| "Sprint tiếp theo học gì?" | [ELDMP_Roadmap_MCU_vi.md](learning/reference_01/ELDMP_Roadmap_MCU_vi.md) + [learning/](learning/) |
| "Ghi chú sprint hiện tại?" | [../notes/](../notes/) |
| "API của module X?" | README trong thư mục module đó (`src/sprintN-*/README.md`) |
| "Version history?" | [release-notes/](release-notes/) |
| "Code structure?" | [ELDMP_PORTFOLIO_STRUCTURE.md](learning/reference_02/ELDMP_PORTFOLIO_STRUCTURE.md) |

---

## Cập Nhật Tài Liệu

Tài liệu được **cập nhật cùng với code**, không phải sau:

- Mỗi sprint, ghi chú được viết vào `../notes/sprint-N.md` trước khi hoàn thành
- Mỗi release, `release-notes/` được cập nhật
- Mỗi quyết định kiến trúc quan trọng, một ADR được viết
- Mỗi module API thay đổi, tài liệu API được cập nhật

---

## Đóng Góp & Feedback

Nếu bạn tìm thấy:
- ❌ Tài liệu bị lỗi / không chính xác
- ❓ Phần nào chưa rõ
- 💡 Gợi ý cải thiện

→ Mở [GitHub Issues](https://github.com/yourusername/eldmp/issues) hoặc [Discussions](https://github.com/yourusername/eldmp/discussions)

---

**Last Updated:** Sprint 0 (Milestone 0.1 — Environment Setup)  
**Next Review:** Sprint 1 — Logger Module  
**Status:** 📚 Documentation framework ready
