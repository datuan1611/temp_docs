# ELDMP Setup Guide — Phase 1 (Updated Structure)

## Prerequisites

### System Requirements
- **OS:** Windows 10+ (Git Bash), Ubuntu 20.04+, or macOS
- **Git:** Latest version
- **CMake:** 3.16+ (required for build)
- **C Compiler:** GCC
- **Text Editor:** VS Code recommended

### Installation

#### Windows
```bash
# 1. Install Git Bash
# Download: https://git-scm.com/download/win

# 2. Install CMake
# Download: https://cmake.org/download/
# Or via Chocolatey: choco install cmake

# 3. Install GCC (MinGW)
# Include with Git Bash or: choco install mingw

# Verify
git --version
cmake --version
gcc --version
```

#### Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install -y git cmake build-essential gcc g++
```

#### macOS
```bash
# Install Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install tools
brew install git cmake gcc
```

---

## Repository Setup

### Step 1: Create Repository Directory

```bash
# Windows (Git Bash/PowerShell/CMD)
mkdir C:\Users\YourName\Projects\eldmp
cd C:\Users\YourName\Projects\eldmp

# Linux/macOS
mkdir -p ~/Projects/eldmp
cd ~/Projects/eldmp
```

### Step 2: Create Directory Structure

```bash
# Create complete structure for Phase 1
mkdir -p docs/learning
mkdir -p docs/architecture/decisions

mkdir -p src/common/include
mkdir -p src/common/src
mkdir -p src/phase1-foundation/practice
mkdir -p src/app

mkdir -p tests/unit
mkdir -p tests/integration
mkdir -p tests/fixtures

mkdir -p scripts
mkdir -p notes
mkdir -p build

# Verify structure
tree -L 3  # Linux/macOS
# or
dir /s    # Windows
```

### Step 3: Initialize Git Repository

```bash
git init

# Configure git
git config user.name "Your Name"
git config user.email "your.email@example.com"

# Verify
git config --list
```

### Step 4: Create .gitignore

Create `.gitignore` file with:

```
# Build directories
build/
cmake-build-*/
dist/
*.cmake

# Compiled objects
*.o
*.a
*.so
*.out
*.exe

# IDE/Editor
.vscode/
.idea/
*.swp
*~
*.project
*.cproject

# System
.DS_Store
Thumbs.db

# Temporary
*.log
*.tmp
```

Add to git:
```bash
git add .gitignore
git commit -m "Add gitignore"
```

### Step 5: Copy Project Files

Copy these files to your repository:

```
eldmp/
├── README.md                    # From PHASE1-README.md
├── SETUP.md                     # This file
├── CMakeLists.txt              # From CMakeLists-ROOT.txt
│
├── docs/learning/
│   └── EMBEDDED_C_FUNDAMENTALS.md   # From PHASE1-EMBEDDED_C_FUNDAMENTALS.md
│
└── src/
    ├── CMakeLists.txt          # From CMakeLists-SRC.txt
    ├── common/include/
    │   ├── types.h
    │   ├── error_codes.h
    │   └── macros.h
    ├── common/src/
    │   └── common.c
    ├── phase1-foundation/practice/
    │   ├── 01_memory_layout.c
    │   ├── 02_volatile_example.c
    │   ├── 03_pointer_arithmetic.c
    │   ├── 04_bitwise_operations.c
    │   └── 05_circular_buffer.c
    └── app/
        └── main.c
```

### Step 6: Create CMakeLists.txt Files

**Root: `CMakeLists.txt`** (copy from CMakeLists-ROOT.txt)
**src/CMakeLists.txt** (copy from CMakeLists-SRC.txt)
**tests/CMakeLists.txt** (copy from CMakeLists-TESTS.txt)

```bash
# After copying files
git add CMakeLists.txt src/CMakeLists.txt tests/CMakeLists.txt
git commit -m "Add CMake build system"
```

### Step 7: Initial Commit

```bash
# Add all files
git add -A

# Commit
git commit -m "Initial repository structure - Phase 1: Embedded C Foundation

- CMake build system configured
- Project structure with phases and sprints
- Phase 1 learning materials
- Practice exercise templates
- Common utilities library"

# Create version tag
git tag v0.0.1

# Verify
git log --oneline
git tag -l
```

---

## Building Phase 1 with CMake

### First Time Build

```bash
cd ~/eldmp

# Create build directory
mkdir build
cd build

# Configure CMake
cmake ..
# Output should show ELDMP configuration

# Build all targets
cmake --build .
# Or on Linux/macOS:
make
```

### Run Practice Exercises

```bash
# After successful build, executables are in build/ directory

# Windows
cd build
phase1_01_memory_layout.exe
phase1_02_volatile_example.exe
phase1_03_pointer_arithmetic.exe
phase1_04_bitwise_operations.exe
phase1_05_circular_buffer.exe

# Linux/macOS
cd build
./phase1_01_memory_layout
./phase1_02_volatile_example
./phase1_03_pointer_arithmetic
./phase1_04_bitwise_operations
./phase1_05_circular_buffer
```

### Rebuild After Code Changes

```bash
cd ~/eldmp/build

# Quick rebuild (recommended)
cmake --build .

# Or full rebuild
rm -rf *
cmake ..
cmake --build .
```

---

## Directory Structure Explained

```
eldmp/                              # Root
├── CMakeLists.txt                  # Root build configuration
├── README.md                        # Project overview (GitHub)
├── SETUP.md                         # This file
│
├── docs/                            # Documentation
│   └── learning/
│       └── EMBEDDED_C_FUNDAMENTALS.md  # Learning material
│
├── src/                             # All source code
│   ├── CMakeLists.txt              # Source build config
│   ├── common/                      # Shared utilities
│   │   ├── include/types.h
│   │   └── src/common.c
│   ├── phase1-foundation/           # Phase 1: Learning
│   │   └── practice/                # Compilable exercises
│   │       ├── 01_memory_layout.c
│   │       ├── 02_volatile_example.c
│   │       ├── 03_pointer_arithmetic.c
│   │       ├── 04_bitwise_operations.c
│   │       └── 05_circular_buffer.c
│   └── app/                         # Main application
│       └── main.c
│
├── tests/                           # Unit tests (future)
│   ├── CMakeLists.txt              # Test build config
│   ├── unit/
│   └── fixtures/
│
├── scripts/                         # Build & deployment
│   └── build.sh
│
├── notes/                           # Learning journals
│   └── phase1-progress.md
│
└── build/                           # CMake build output (git-ignored)
    ├── CMakeCache.txt
    ├── Makefile
    ├── phase1_01_memory_layout
    └── ...
```

---

## Workflow: Edit → Build → Test → Commit

### Make Changes

```bash
# Edit source code
nano src/phase1-foundation/practice/01_memory_layout.c

# Or in VS Code
code src/phase1-foundation/practice/01_memory_layout.c
```

### Rebuild

```bash
cd ~/eldmp/build
cmake --build .
```

### Run & Test

```bash
./phase1_01_memory_layout
# Test output, verify correct behavior
```

### Commit Progress

```bash
cd ~/eldmp

# Check what changed
git status

# Add changes
git add src/phase1-foundation/practice/01_memory_layout.c

# Commit
git commit -m "phase1: Update memory layout exercise with additional examples"

# Progress tracking
git log --oneline | head -5
```

---

## Git Commands for This Workflow

```bash
# Check status
git status

# See changes
git diff src/phase1-foundation/practice/01_memory_layout.c

# Add and commit
git add src/
git commit -m "phase1: Exercise updates"

# View history
git log --oneline -5

# Create milestone
git tag v0.1

# See all tags
git tag -l
```

---

## Adding Phases/Sprints Later

### After Phase 1, add Phase 2

```bash
# Phase 2 directories
mkdir -p src/phase2-infrastructure
mkdir -p src/phase2-infrastructure/cmake
mkdir -p src/phase2-infrastructure/testing

# Update src/CMakeLists.txt:
# add_subdirectory(phase2-infrastructure)

# Rebuild
cd build
cmake ..
cmake --build .
```

### After Phase 2, start Sprint 1

```bash
# Sprint 1 directories
mkdir -p src/sprint1-logger/include
mkdir -p src/sprint1-logger/src
mkdir -p tests/unit

# Add CMakeLists.txt for sprint1-logger
# Update src/CMakeLists.txt to include sprint1-logger

# Rebuild
cd build
cmake ..
cmake --build .
```

---

## CMake Tips

### Clean Build

```bash
cd ~/eldmp
rm -rf build
mkdir build
cd build
cmake ..
cmake --build .
```

### Verbose Build (see commands)

```bash
cmake --build . --verbose
# Or:
cd build && make VERBOSE=1
```

### Set Build Type

```bash
cmake -DCMAKE_BUILD_TYPE=Debug ..   # Debug build
cmake -DCMAKE_BUILD_TYPE=Release .. # Release build
```

### Install Targets

```bash
cmake --build .
cmake --install . --prefix ~/eldmp-install
```

---

## Troubleshooting

### CMake not found
```bash
# Windows: Install from cmake.org
# Linux: sudo apt-get install cmake
# macOS: brew install cmake
```

### GCC not found
```bash
# Windows: Ensure MinGW installed with Git Bash
# Linux: sudo apt-get install build-essential
# macOS: brew install gcc
```

### CMake configure fails
```bash
# Check error messages
# Usually missing compiler or Git

cmake -v  # Show CMake version
cmake --help-command find_program  # Debugging

# On Windows, try from Git Bash (not CMD)
```

### Undefined reference errors after compilation
```bash
# Make sure all targets are linked in CMakeLists.txt
# Check: target_link_libraries(executable PRIVATE dependencies)
```

---

## Next Steps

1. ✅ Follow this setup guide (20 minutes)
2. ✅ Verify build works: `cmake .. && cmake --build .`
3. ✅ Run practice exercises
4. ✅ Read: `docs/learning/EMBEDDED_C_FUNDAMENTALS.md`
5. ✅ Modify exercises and rebuild
6. ✅ Commit progress to git
7. ✅ Complete Phase 1 learning (1-2 weeks)
8. → Proceed to Phase 2: Infrastructure

---

**Status:** Phase 1 setup complete with CMake  
**Next:** Start learning EMBEDDED_C_FUNDAMENTALS.md
