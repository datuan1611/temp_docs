# ELDMP Repository Structure — Redesigned for CMake & Scalability

## Problem with Previous Structure

- ❌ `practice-c/` outside of `src/`
- ❌ Learning materials scattered
- ❌ Not organized for CMake builds
- ❌ Difficult to scale beyond Phase 1

## New Structure — Organized & CMake-Ready

```
eldmp/
├── README.md                          # Project overview
├── SETUP.md                           # Installation guide
├── CMakeLists.txt                     # Root CMake configuration
├── .gitignore
├── .clang-format                      # Code style (optional)
│
├── docs/                              # Documentation & Learning Materials
│   ├── learning/                      # Learning guides (all phases)
│   │   ├── EMBEDDED_C_FUNDAMENTALS.md # Phase 1: C Foundation
│   │   ├── ARM_CORTEX_M.md            # Phase 2: MCU Architecture
│   │   ├── FREERTOS_BASICS.md         # Phase 3: RTOS
│   │   ├── LVGL_GUI.md                # Phase 4: Embedded GUI
│   │   ├── LINUX_KERNEL.md            # Phase 5: Linux Kernel
│   │   └── SYSTEMD_SERVICES.md        # Phase 6: systemd
│   │
│   └── architecture/                  # System design docs
│       ├── ARCHITECTURE.md
│       └── decisions/
│           └── ADR-0001-*.md
│
├── src/                               # All source code (organized by component)
│   ├── CMakeLists.txt                 # Source root CMake
│   │
│   ├── common/                        # Shared utilities (all sprints)
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── types.h
│   │   │   ├── error_codes.h
│   │   │   └── macros.h
│   │   └── src/
│   │       └── common.c
│   │
│   ├── phase1-foundation/             # Phase 1: Embedded C Learning & Practice
│   │   ├── CMakeLists.txt
│   │   └── practice/                  # Practice exercises (compilable with CMake)
│   │       ├── 01_memory_layout.c
│   │       ├── 02_volatile_example.c
│   │       ├── 03_pointer_arithmetic.c
│   │       ├── 04_bitwise_operations.c
│   │       └── 05_circular_buffer.c
│   │
│   ├── phase2-infrastructure/         # Phase 2: Build system, tests (future)
│   │   ├── CMakeLists.txt
│   │   └── ...
│   │
│   ├── sprint0-setup/                 # Sprint 0: Environment setup
│   │   ├── CMakeLists.txt
│   │   └── ...
│   │
│   ├── sprint1-logger/                # Sprint 1: Logger module
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── logger.h
│   │   └── src/
│   │       └── logger.c
│   │
│   ├── sprint2-config/                # Sprint 2: Config manager
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── config.h
│   │   └── src/
│   │       └── config.c
│   │
│   ├── sprint3-freertos/              # Sprint 3+: RTOS & Linux (future)
│   │   ├── CMakeLists.txt
│   │   └── ...
│   │
│   └── app/                           # Main application (integrated)
│       ├── CMakeLists.txt
│       └── main.c
│
├── tests/                             # Unit tests (separate from src)
│   ├── CMakeLists.txt
│   ├── catch2_setup.cmake             # Catch2 framework (if used)
│   │
│   ├── unit/                          # Unit tests per component
│   │   ├── CMakeLists.txt
│   │   ├── test_logger.c              # Tests for logger
│   │   ├── test_config.c              # Tests for config
│   │   └── ...
│   │
│   └── fixtures/                      # Test data
│       └── sample_config.json
│
├── scripts/                           # Build & deployment scripts
│   ├── build.sh                       # Build script
│   ├── format.sh                      # Code formatting
│   └── ...
│
├── notes/                             # Sprint learning journals
│   ├── phase1-progress.md             # Phase 1 progress tracking
│   ├── sprint0-notes.md
│   ├── sprint1-notes.md
│   └── SPRINT_TEMPLATE.md             # Template for each sprint
│
└── build/                             # CMake build output (created by cmake)
    ├── CMakeCache.txt
    ├── Makefile
    ├── phase1_exercises               # Compiled practice executables
    ├── app
    └── tests/
        └── unit_tests
```

---

## Key Design Decisions

### 1. **Phases > Sprints (Phase 1 First)**

```
src/
├── phase1-foundation/       # Complete learning foundation
│   └── practice/           # All practice exercises (compiled together)
├── phase2-infrastructure/  # Build system, CMake, tests
├── sprint0-setup/         # Begin actual sprints after phase 2
├── sprint1-logger/
├── sprint2-config/
└── ...
```

**Why:** Phase 1 is about learning, not development. Clean separation.

### 2. **All Learning Materials in `docs/learning/`**

```
docs/learning/
├── EMBEDDED_C_FUNDAMENTALS.md
├── ARM_CORTEX_M.md
├── FREERTOS_BASICS.md
├── LVGL_GUI.md
└── LINUX_KERNEL.md
```

**Why:** Easy to find all learning resources. Not scattered.

### 3. **Practice Code in `src/phase1-foundation/practice/`**

```
src/phase1-foundation/practice/
├── 01_memory_layout.c
├── 02_volatile_example.c
├── 03_pointer_arithmetic.c
├── 04_bitwise_operations.c
└── 05_circular_buffer.c
```

**Why:** Practice exercises are source code. Build with CMake. Not separate.

### 4. **Each Component Has Own CMakeLists.txt**

```
src/
├── CMakeLists.txt              # Root for src/
├── common/CMakeLists.txt       # Common utilities
├── phase1-foundation/CMakeLists.txt
├── sprint1-logger/CMakeLists.txt
└── ...
```

**Why:** Modular, easy to add/remove components without breaking build.

### 5. **Tests Separate from Source**

```
src/sprint1-logger/            # Source code
├── include/logger.h
└── src/logger.c

tests/unit/                     # Tests for logger
├── test_logger.c
└── CMakeLists.txt
```

**Why:** Source clean, tests organized logically.

---

## CMakeLists.txt Files

### Root: `CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.16)
project(eldmp VERSION 0.0.1 LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)

# Compiler flags
add_compile_options(-Wall -Wextra -Wpedantic)

# Include subdirectories
add_subdirectory(src)
add_subdirectory(tests)

# Optional: documentation build
find_package(Doxygen)
if(DOXYGEN_FOUND)
    add_custom_target(docs
        COMMAND ${DOXYGEN_EXECUTABLE}
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
    )
endif()

enable_testing()
```

### Src: `src/CMakeLists.txt`

```cmake
# Common library
add_library(eldmp_common OBJECT
    common/src/common.c
)
target_include_directories(eldmp_common PUBLIC common/include)

# Phase 1: Practice exercises
add_executable(01_memory_layout
    phase1-foundation/practice/01_memory_layout.c
)
target_link_libraries(01_memory_layout PRIVATE eldmp_common)

add_executable(02_volatile_example
    phase1-foundation/practice/02_volatile_example.c
)
target_link_libraries(02_volatile_example PRIVATE eldmp_common)

add_executable(03_pointer_arithmetic
    phase1-foundation/practice/03_pointer_arithmetic.c
)
target_link_libraries(03_pointer_arithmetic PRIVATE eldmp_common)

add_executable(04_bitwise_operations
    phase1-foundation/practice/04_bitwise_operations.c
)
target_link_libraries(04_bitwise_operations PRIVATE eldmp_common)

add_executable(05_circular_buffer
    phase1-foundation/practice/05_circular_buffer.c
)
target_link_libraries(05_circular_buffer PRIVATE eldmp_common)

# Future phases: Logger, Config, etc.
# add_subdirectory(sprint1-logger)
# add_subdirectory(sprint2-config)

# Main app
add_executable(eldmp app/main.c)
target_link_libraries(eldmp PRIVATE eldmp_common)

# Install
install(TARGETS 01_memory_layout 02_volatile_example 03_pointer_arithmetic 
                04_bitwise_operations 05_circular_buffer eldmp
        DESTINATION bin
)
```

### Tests: `tests/CMakeLists.txt`

```cmake
# Unit test framework setup
# (Optional: Add Catch2 or other framework later)

# Test executables
# add_executable(test_logger unit/test_logger.c)
# add_test(NAME test_logger COMMAND test_logger)
```

---

## How to Use This Structure

### Phase 1: Learning & Practice

```bash
# Create repository with new structure
cd ~/eldmp

# Add learning documents
docs/learning/EMBEDDED_C_FUNDAMENTALS.md

# Add practice source code
src/phase1-foundation/practice/01_memory_layout.c
src/phase1-foundation/practice/02_volatile_example.c
# ... etc

# Build all exercises with CMake
mkdir build
cd build
cmake ..
make

# Run individual exercises
./01_memory_layout
./02_volatile_example
./03_pointer_arithmetic
# ... etc
```

### Phase 2: Infrastructure

```bash
# Add build system, test framework
src/phase2-infrastructure/
```

### Sprint 1+: Development

```bash
# Add logger module
src/sprint1-logger/
├── include/logger.h
└── src/logger.c

# Add logger tests
tests/unit/test_logger.c

# CMake automatically includes when enabled
```

---

## Scalability Examples

### Adding Sprint 3 (FREERTOS)

```
src/sprint3-freertos/
├── CMakeLists.txt
├── include/
│   ├── freertos_config.h
│   ├── task_sensor.h
│   └── task_control.h
└── src/
    ├── freertos_config.c
    ├── task_sensor.c
    └── task_control.c

# In src/CMakeLists.txt:
# add_subdirectory(sprint3-freertos)

# Automatically built with rest of project
```

### Adding Linux Kernel Driver (Sprint 6)

```
src/sprint6-driver/
├── CMakeLists.txt
├── gpio_driver.c
└── gpio_driver.h

# Linux driver built separately if needed
# CMake can handle cross-compilation
```

---

## Git Workflow with New Structure

```bash
# Phase 1: Learning
git add docs/learning/EMBEDDED_C_FUNDAMENTALS.md
git add src/phase1-foundation/practice/
git add CMakeLists.txt src/CMakeLists.txt
git commit -m "phase1: Embedded C fundamentals & practice exercises"
git tag v0.1

# Test build
mkdir build && cd build
cmake ..
make
./01_memory_layout  # Test executable

cd .. && git add .
git commit -m "phase1: CMake build system working"
git tag v0.1.1
```

---

## Benefits of This Structure

✅ **Clear Phases:** Phase 1 learning separate from Phase 2+ development  
✅ **Modular CMake:** Each component independent, easy to add/remove  
✅ **Scalable:** Add sprints without reorganizing  
✅ **Practice as Code:** Exercises are source code, build like real projects  
✅ **Single Repo:** Everything together, easy to track  
✅ **Learning Path:** docs/learning/ shows progression  
✅ **Standard Layout:** Familiar for developers  
✅ **CMake Ready:** Build entire project with one command  

---

## Comparison: Old vs New

| Aspect | Old | New |
|--------|-----|-----|
| Practice location | `practice-c/` (outside src) | `src/phase1-foundation/practice/` (in src) |
| Learning docs | Scattered | `docs/learning/` (organized) |
| Build system | Manual compilation | CMake integration |
| Sprint organization | Unclear | Clear phases then sprints |
| Scalability | Difficult | Easy to extend |
| Repository coherence | Poor | Professional |

---

## Next: Update Files with This Structure

1. **PHASE1-README.md** — Add new structure diagram
2. **PHASE1-SETUP.md** — Update with new folder layout
3. **Create CMakeLists.txt files** — Root and src/
4. **Update practice exercises** — Add CMake support
5. **Git workflow** — Show how to build with new structure

Would you like me to create the updated files with this structure?
