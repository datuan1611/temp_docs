# ELDMP Detailed Architecture — Layer-by-Layer Breakdown

Chi tiết kiến trúc từng lớp của ELDMP, các interface, và cách chúng tương tác.

---

## Table of Contents

0. [Build Environment Map](#build-environment-map)
1. [Hardware Layer](#hardware-layer)
2. [MCU Firmware Layers](#mcu-firmware-layers)
3. [Linux Kernel Layers](#linux-kernel-layers)
4. [Linux User-Space Layers](#linux-user-space-layers)
5. [Inter-Processor Communication](#inter-processor-communication)
6. [Module Dependencies](#module-dependencies)
7. [Data Flow Diagrams](#data-flow-diagrams)

---

## Build Environment Map

Trước khi đi vào chi tiết từng lớp của **sản phẩm** ELDMP, bảng dưới đây map mỗi lớp tới **nơi nó thực sự được build** trong môi trường phát triển (Ubuntu Server Native + Docker Engine chính thức — xem lý do và setup đầy đủ ở [`../ARCHITECTURE.md`](../ARCHITECTURE.md#kiến-trúc-môi-trường-phát-triển--build) và [`../../SETUP.md`](../../SETUP.md)).

| Lớp / Module | Sprint | Build ở đâu | Toolchain chính |
|---|---|---|---|
| Bare-metal MCU (STM32F446, STM32H743) | 3 | Ubuntu Server (`~/eldmp`) | `arm-none-eabi-gcc`, OpenOCD |
| FreeRTOS | 4 | Ubuntu Server | `arm-none-eabi-gcc` |
| LVGL GUI | 5 | Ubuntu Server | `arm-none-eabi-gcc` |
| — *Flash xuống board* | 3–5 | **Máy có cổng USB vật lý** | `openocd` |
| Kernel driver + Device Tree (BeagleBone Black) | 6 | Ubuntu Server — chỉ cross-compile/phân tích, KHÔNG build kernel/image đầy đủ | `gcc`, kernel headers, `dtc`, `arm-linux-gnueabihf-gcc` |
| Device Manager, Health Monitor | 7–8 | Ubuntu Server | `gcc`/`g++`, CMake |
| D-Bus IPC | 9 | Ubuntu Server | `libdbus-1-dev` |
| systemd, Watchdog | 10–11 | Ubuntu Server | systemd (native, không lồng trong VM ảo hoá) |
| **Buildroot / Yocto image đầy đủ** | 12 | **Máy Linux chuyên dụng riêng** (KHÔNG phải máy phát triển chính — xem Scope Update) | Buildroot/Yocto deps đầy đủ, chạy trên máy có đủ RAM/disk |
| Protocol Linux↔MCU | 13 | Ubuntu Server | `gcc` (Linux side), `arm-none-eabi-gcc` (MCU side) |
| Networking, OTA, Security | 14–16 | Ubuntu Server | `libmosquitto`, OpenSSL |
| — *Static Analysis (MISRA C)* | Mọi sprint có code C/C++ | **Docker container `eldmp-toolchain`, Docker Engine native** | Cppcheck, Clang-Tidy |
| — *Dynamic Analysis (Sanitizers, backtrace)* | Mọi sprint có code C/C++ | **Docker container `eldmp-toolchain`, Docker Engine native** | Clang ASan/MSan/UBSan/LeakSanitizer, Valgrind, GDB |
| — *Unit Test nâng cao (Unity/CMock)* | Sprint 3+ (test bare-metal trên host) | **Docker container `eldmp-toolchain`, Docker Engine native** | Unity, CMock, Ruby |
| — *Verification Suite (4 cấp độ)* | Sprint 0, chạy lại bất cứ khi nào cần | Ubuntu Server (`scripts/helper/verify-env.sh`) | OS/Docker health, toolchain availability, STM32 compile test, ASan dynamic test |

**SCOPE UPDATE quan trọng:** dòng "Buildroot / Yocto image đầy đủ" là ngoại lệ duy nhất **không** build trên máy phát triển chính — do giới hạn RAM, việc này đã chuyển hẳn sang một máy chủ Linux chuyên dụng riêng. Mọi lớp khác trong bảng trên vẫn build trên Ubuntu Server như bình thường.

**Nguyên tắc:** phần lớn compile trực tiếp trên Ubuntu Server (toolchain Linux thật, nhất quán với CI self-hosted runner cũng chính là server này cho Sprint 6/13, và máy Linux riêng cho Sprint 12). Static/dynamic analysis và testing nâng cao chạy qua **Docker container**, dùng Docker Engine đã cài chính thức trên server (không qua wrapper, không qua socket forward từ máy khác — khác hẳn Colima/OrbStack trước đây). Chỉ riêng thao tác **flash vật lý qua USB** làm từ máy có cổng USB thật — nếu máy phát triển chính là VM, USB passthrough tuỳ hypervisor và chưa được xác minh ổn định, trong khi flash trực tiếp từ máy vật lý luôn chắc chắn hoạt động.

---

## Hardware Layer

### 1.1 MCU Hardware (STM32H743ZI)

**Physical Components:**
- **CPU:** ARM Cortex-M7, 400 MHz
- **RAM:** 1 MB (internal SRAM)
- **Flash:** 2 MB (program storage)
- **Peripherals:** GPIO, UART, SPI, I2C, CAN, ADC, PWM, Timer, DMA

**Memory Map:**
```
┌─────────────────────────┐
│ 0xE0000000              │  Cortex-M7 private peripherals
│ (NVIC, SysTick, etc.)   │
├─────────────────────────┤
│ 0x40000000              │  AHB/APB peripherals
│ (GPIO, UART, SPI, etc.) │
├─────────────────────────┤
│ 0x20000000              │  SRAM (1 MB)
│ (Runtime data, stack)   │
├─────────────────────────┤
│ 0x00000000              │  Flash (2 MB)
│ (Program, const data)   │
└─────────────────────────┘
```

**Interrupts (NVIC):**
- External interrupts: GPIO, UART, SPI, I2C, CAN, ADC
- Cortex-M7 exceptions: SysTick, PendSV, SVCall

---

### 1.2 Linux SoC Hardware (BeagleBone Black Rev C)

**Physical Components:**
- **CPU:** ARM Cortex-A8, 1 GHz
- **RAM:** 512 MB (DDR3)
- **Storage:** microSD card (user-provided, 8–16GB)
- **Peripherals:** GPIO (69 pins), UART, SPI, I2C, CAN, Ethernet, USB

**Board Connectors:**
- **UART0** (serial debug): /dev/ttyO0 (kernel serial)
- **SPI0/SPI1:** Serial communication
- **I2C0/I2C1/I2C2:** I2C buses
- **CAN0/CAN1:** CAN buses
- **GPIO pins:** 69 available GPIO lines

---

### 1.3 Communication Links

```
STM32H743 (MCU)                  BeagleBone Black (Linux SoC)

GPIO (output) ←─────────── GPIO (input)     [GPIO handshake]
              ─────────────→ GPIO (output)

UART TX ←─────────────────── UART RX       [Serial protocol]
        ─────────────────────→ UART TX

SPI MOSI ←─────────────────── SPI MISO     [SPI protocol]
     MISO ─────────────────────→ SPI MOSI
     CLK ←─────────────────────  CLK

CAN TX ←───────────────────── CAN RX       [CAN protocol]
       ─────────────────────→ CAN TX

GND ←───────────────────────── GND         [Common ground]
```

---

## MCU Firmware Layers

### 2.1 Bare-Metal Layer (Sprint 3)

**Responsibility:** Direct hardware access, interrupt handling, memory management

**Key Files:**
```
src/mcu/bare-metal/
├── startup.c          # Bootloader, memory init, call main()
├── gpio.c             # GPIO configuration, pin I/O
├── uart.c             # UART driver (polling + interrupt)
├── interrupt.c        # Interrupt handlers
├── dma.c              # DMA controller setup
└── hal/
    ├── gpio.h         # Hardware register definitions
    ├── uart.h         # UART registers
    └── timer.h        # Timer/PWM registers
```

**Critical Functions:**
```c
// Startup
void main(void);                       // Entry point
void SystemInit(void);                 // Clocks, memory

// GPIO
void gpio_pin_mode(pin, mode);        // Input/output
void gpio_write(pin, value);          // Write pin
int gpio_read(pin);                   // Read pin
void gpio_attach_interrupt(pin, isr); // Register interrupt

// UART
void uart_init(baud_rate);            // Initialize
void uart_send(data);                 // Send byte
uint8_t uart_receive(void);           // Receive byte

// Interrupt handlers
void EXTI0_IRQHandler(void);          // GPIO interrupt
void UART1_IRQHandler(void);          // UART interrupt
```

**Example: GPIO Interrupt Handler**
```c
// Interrupt occurs on GPIO pin (button press)
void EXTI0_IRQHandler(void) {
    // 1. Save context
    // 2. Disable interrupts
    NVIC_DisableIRQ(EXTI0_IRQn);
    
    // 3. Read GPIO state
    int button_state = gpio_read(PIN_BUTTON);
    
    // 4. Queue event for FreeRTOS task
    xQueueSendFromISR(button_queue, &button_state, &xHigherPriorityTaskWoken);
    
    // 5. Clear interrupt flag
    EXTI->PR |= (1 << 0);
    
    // 6. Re-enable if needed
    NVIC_EnableIRQ(EXTI0_IRQn);
    
    // 7. Request context switch if higher priority task woken
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
```

**Challenge:** Writing interrupt handlers without blocking (non-preemptive context)

---

### 2.2 FreeRTOS Kernel Layer (Sprint 4)

**Responsibility:** Task scheduling, synchronization, timing

**Key Concepts:**
- **Task:** Independent execution context (like lightweight thread)
- **Queue:** Message passing between tasks
- **Semaphore/Mutex:** Synchronization primitive
- **Timer:** Software timer triggered callback
- **Event Group:** Wait for multiple conditions

**Key Functions:**
```c
// Task management
void xTaskCreate(task_func, name, stack_size, params, priority, task_handle);
void vTaskDelay(ticks);                // Sleep task
void vTaskDelete(task_handle);         // Destroy task

// Queue operations
QueueHandle_t xQueueCreate(length, item_size);
BaseType_t xQueueSend(queue, data, timeout);
BaseType_t xQueueReceive(queue, data, timeout);

// Synchronization
SemaphoreHandle_t xSemaphoreCreateBinary();
xSemaphoreTake(semaphore, timeout);    // P operation
xSemaphoreGive(semaphore);             // V operation

// Timers
TimerHandle_t xTimerCreate(name, period, callback);
xTimerStart(timer, timeout);
```

**Scheduler Details:**
```
Task 1 (Priority 3) ──┐
Task 2 (Priority 2) ──┤  Round-robin within same priority
Task 3 (Priority 3) ──┤  Task 1 & 3 take turns (20ms each)
Task 4 (Priority 1) ──┘

Scheduler preempts lower priority when higher priority task ready.
Timer interrupt → context switch → next task runs
```

**Example: Sensor Reading Task**
```c
void sensor_task(void *param) {
    while (1) {
        // 1. Read sensor value via ADC (bare-metal API)
        uint16_t raw_value = adc_read(ADC_CHANNEL_0);
        
        // 2. Convert to physical units
        float temp_celsius = (raw_value / 4095.0) * 100.0;
        
        // 3. Send via queue for other tasks to consume
        xQueueSend(sensor_queue, &temp_celsius, 0);
        
        // 4. Delay 100ms (yields CPU to other tasks)
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}
```

**Challenge:** No preemption → non-blocking code essential, deadlock avoidance

---

### 2.3 LVGL GUI Layer (Sprint 5)

**Responsibility:** UI rendering, event handling, user interaction

**Key Concepts:**
- **Widget:** Button, label, slider, chart, etc.
- **Style:** Color, font, size, alignment
- **Event:** Widget triggered event (click, release, etc.)
- **Event Loop:** Continuously redraw screen, handle input

**Key Functions:**
```c
// Initialization
void lv_init(void);                    // Initialize LVGL
lv_disp_t *lv_disp_drv_register(disp_driver);  // Register display driver
lv_indev_t *lv_indev_drv_register(input_driver); // Register input driver

// Screen management
lv_obj_t *scr = lv_scr_act();          // Get active screen
lv_obj_t *label = lv_label_create(scr);       // Create label
lv_label_set_text(label, "Hello");    // Update text

// Event handling
void button_cb(lv_event_t *e) {        // Callback
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) { /* handle click */ }
}
lv_obj_add_event_cb(button, button_cb, LV_EVENT_ALL, NULL);

// Rendering
lv_timer_handler();                    // Call periodically (10–50ms)
lv_task_handler();                     // Alternative name (LVGL v7)
```

**Display Driver Interface:**
```c
// Display driver (must implement):
void display_flush(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_p) {
    // Write color buffer to LCD controller
    // Called by LVGL renderer
    for (int y = area->y1; y <= area->y2; y++) {
        spi_write_pixels(color_p, area->x2 - area->x1 + 1);
    }
    lv_disp_flush_ready(drv);  // Signal completion
}

// Input driver (must implement):
void input_read(lv_indev_drv_t *drv, lv_indev_data_t *data) {
    // Read touchscreen/buttons, update data->point / data->state
    // Called by LVGL event loop
    data->point.x = touchscreen_read_x();
    data->point.y = touchscreen_read_y();
    data->state = (touchscreen_pressed) ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
}
```

**Example: Temperature Display UI**
```c
void lvgl_ui_task(void *param) {
    lv_init();
    
    // Create objects
    lv_obj_t *label_temp = lv_label_create(lv_scr_act());
    lv_obj_align(label_temp, LV_ALIGN_CENTER, 0, 0);
    
    float temperature = 0.0;
    
    while (1) {
        // 1. Read latest temperature from sensor queue
        if (xQueueReceive(sensor_queue, &temperature, 0)) {
            // 2. Update label text
            char buffer[32];
            snprintf(buffer, sizeof(buffer), "Temp: %.1f°C", temperature);
            lv_label_set_text(label_temp, buffer);
        }
        
        // 3. Render frame (LVGL redraws changed widgets)
        lv_timer_handler();
        
        // 4. Delay 50ms (20 fps)
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
```

**Challenge:** Non-blocking rendering, smooth 30 fps without frame drops

---

### 2.4 MCU Application Layer

**Responsibility:** Application logic, sensor processing, motor control

**Architecture:**
```
┌─────────────────────────────────┐
│ Task 1: Sensor Reader           │
│ ├─ Read ADC every 100ms         │
│ └─ Queue → other tasks          │
├─────────────────────────────────┤
│ Task 2: Control Loop            │
│ ├─ Receive sensor from queue    │
│ ├─ Calculate motor command      │
│ └─ Set PWM duty                 │
├─────────────────────────────────┤
│ Task 3: LVGL UI Renderer        │
│ ├─ Receive data from queues     │
│ ├─ Update GUI                   │
│ └─ Call lv_timer_handler()      │
├─────────────────────────────────┤
│ Task 4: Protocol Handler        │
│ ├─ Receive from UART (Linux)    │
│ ├─ Process command              │
│ └─ Send response                │
└─────────────────────────────────┘
```

---

## Linux Kernel Layers

### 3.1 Bootloader & Device Tree (Sprint 6)

**U-Boot Bootloader:**
- **Role:** Initialize hardware, load kernel, DTB
- **Output:** `/boot/uImage` or `/boot/zImage`

**Device Tree (DTB):**
- **Role:** Describe hardware to kernel (GPIO, clocks, regulators)
- **Format:** Text (.dts) → Compiled (.dtb)

**Device Tree Overlay (Sprint 6):**
- **Role:** Dynamically patch device tree at runtime
- **Use:** Add custom driver nodes without recompiling kernel

**Example Device Tree Overlay:**
```dts
// File: overlay-eldmp.dts
/dts-v1/;
/plugin/;

&am33xx_pinmux {
    eldmp_gpio_pins: pinmux_eldmp_gpio {
        pinctrl-single,pins = <
            0x1a4 0x07  // pin P8_3 -> GPIO1_6, Mode 7
            0x1a8 0x07  // pin P8_4 -> GPIO1_7, Mode 7
        >;
    };
};

&ocp {
    eldmp_gpio {
        compatible = "eldmp,gpio-driver";
        pinctrl-names = "default";
        pinctrl-0 = <&eldmp_gpio_pins>;
        
        gpio_1_6 = <&gpio1 6>;
        gpio_1_7 = <&gpio1 7>;
        
        status = "okay";
    };
};
```

**Compile & Load:**
```bash
# Compile
dtc -O dtb -o overlay-eldmp.dtbo overlay-eldmp.dts

# Load (at boot or at runtime)
sudo dtoverlay overlay-eldmp.dtbo
```

---

### 3.2 Kernel Driver Layer (Sprint 6)

**Responsibility:** Provide device interface to user-space, handle hardware access

**Types of Drivers:**
1. **Character Device** — `/dev/eldmp_gpio` (read/write bytes)
2. **Platform Driver** — Bound to device tree node
3. **Network Driver** — Ethernet/CAN interface

**Example Character Device Driver:**
```c
// File: eldmp_gpio_driver.c
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/of_gpio.h>

static int eldmp_gpio_open(struct inode *inode, struct file *filp) {
    // Called when user opens /dev/eldmp_gpio
    return 0;
}

static ssize_t eldmp_gpio_write(struct file *filp, const char __user *buf, 
                                size_t count, loff_t *ppos) {
    // Called when user writes to device
    uint8_t command;
    if (copy_from_user(&command, buf, 1)) return -EFAULT;
    
    // Parse command, control GPIO
    if (command == 'H') gpio_set_value(gpio_1_6, 1);  // HIGH
    else if (command == 'L') gpio_set_value(gpio_1_6, 0);  // LOW
    
    return count;
}

static ssize_t eldmp_gpio_read(struct file *filp, char __user *buf,
                               size_t count, loff_t *ppos) {
    // Called when user reads from device
    uint8_t value = gpio_get_value(gpio_1_7);
    if (copy_to_user(buf, &value, 1)) return -EFAULT;
    return 1;
}

static const struct file_operations eldmp_fops = {
    .owner = THIS_MODULE,
    .open = eldmp_gpio_open,
    .read = eldmp_gpio_read,
    .write = eldmp_gpio_write,
};

static struct miscdevice eldmp_miscdev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = "eldmp_gpio",
    .fops = &eldmp_fops,
};

static int __init eldmp_gpio_init(void) {
    return misc_register(&eldmp_miscdev);
}

static void __exit eldmp_gpio_exit(void) {
    misc_deregister(&eldmp_miscdev);
}

module_init(eldmp_gpio_init);
module_exit(eldmp_gpio_exit);
MODULE_LICENSE("GPL");
```

**Using from User-Space:**
```c
// File: user_space_gpio.c
#include <fcntl.h>
#include <unistd.h>

int fd = open("/dev/eldmp_gpio", O_RDWR);
uint8_t cmd = 'H';
write(fd, &cmd, 1);      // Set GPIO HIGH

uint8_t value;
read(fd, &value, 1);     // Read GPIO
printf("GPIO value: %d\n", value);

close(fd);
```

---

### 3.3 Kernel Subsystems

**Interrupt Handling:**
```c
// Request interrupt
int irq = gpio_to_irq(gpio_1_7);  // Get IRQ number
request_irq(irq, eldmp_isr, IRQF_TRIGGER_RISING, "eldmp_gpio", NULL);

// ISR (top half - must be fast and non-blocking)
static irqreturn_t eldmp_isr(int irq, void *dev_id) {
    // Do minimal work here (just store state)
    atomic_inc(&interrupt_count);
    return IRQ_HANDLED;
}

// Defer work to bottom half
void eldmp_workqueue_handler(struct work_struct *work) {
    // Do heavy work here (can sleep, block, etc.)
    printk(KERN_INFO "GPIO interrupt %d\n", atomic_read(&interrupt_count));
}
```

**Synchronization (Linux kernel):**
- **mutex** — mutual exclusion lock (can sleep)
- **spinlock** — busy-wait lock (cannot sleep, interrupt context only)
- **RCU** — read-copy-update (lock-free reads)

---

## Linux User-Space Layers

### 4.1 HAL (Hardware Abstraction Layer)

**Responsibility:** Provide stable API to middleware, insulate from kernel/hardware changes

**Example HAL Interface:**
```c
// File: include/hal/gpio.h
typedef int gpio_handle_t;

gpio_handle_t hal_gpio_open(int gpio_number);
int hal_gpio_write(gpio_handle_t handle, int value);  // 0 or 1
int hal_gpio_read(gpio_handle_t handle);               // Returns 0 or 1
void hal_gpio_close(gpio_handle_t handle);

// File: src/hal/gpio_impl.c (Linux-specific)
gpio_handle_t hal_gpio_open(int gpio_number) {
    int fd = open("/dev/eldmp_gpio", O_RDWR);
    // Store fd in handle map
    return make_handle(fd);
}

int hal_gpio_write(gpio_handle_t handle, int value) {
    int fd = handle_to_fd(handle);
    uint8_t cmd = value ? 'H' : 'L';
    return write(fd, &cmd, 1);
}
```

**Benefit:** Change device implementation (e.g., from `/dev/eldmp_gpio` to GPIO library) without changing middleware code

---

### 4.2 Middleware Layer

**Components:** Logger, Config Manager, IPC, Storage

#### Logger (Sprint 1)
```c
// include/logger/logger.h
void logger_init(const char *filename);
void logger_log(int level, const char *format, ...);
void logger_close(void);

// Levels: DEBUG, INFO, WARN, ERROR

// Usage
logger_init("/var/log/eldmp.log");
logger_log(LOG_INFO, "Temperature: %.1f°C", temperature);
logger_close();
```

**Features:**
- ✅ Rotates log file when size exceeds threshold
- ✅ Timestamps & log levels
- ✅ Thread-safe (uses mutex)

#### Config Manager (Sprint 2)
```c
// include/config/config.h
typedef struct {
    char hostname[64];
    int mqtt_port;
    float temperature_threshold;
    // ... more fields
} eldmp_config_t;

int config_load(const char *path, eldmp_config_t *config);
int config_reload(eldmp_config_t *config);
int config_save(const char *path, eldmp_config_t *config);
```

**Features:**
- ✅ JSON format (human-readable)
- ✅ Hot reload (signal handler)
- ✅ Validation (schema checking)

---

### 4.3 Services Layer (Sprint 7–16)

**Architecture:**
```
┌──────────────────────────────────────────────────────┐
│ Service Orchestration (systemd)                      │
├──────────────────────────────────────────────────────┤
│ ┌────────────────┐  ┌──────────────────┐             │
│ │ Device Service │  │ Health Monitor   │  ...        │
│ │ D-Bus iface    │  │ D-Bus iface      │             │
│ └────────┬───────┘  └────────┬─────────┘             │
│          │                   │                       │
│          └───────────────────┘                       │
│                   D-Bus daemon                       │
│                      │                               │
│          ┌───────────┼────────────┐                  │
│          │           │            │                  │
│      ┌───▼────┐ ┌────▼───┐ ┌─────▼─┐               │
│      │ CLI    │ │ REST   │ │ Apps  │               │
│      │ Tool   │ │ Server │ │       │               │
│      └────────┘ └────────┘ └───────┘               │
└──────────────────────────────────────────────────────┘
```

**Device Manager Service (Sprint 7):**
```c
// interface: org.eldmp.Device
// methods:
//   - GetInfo() → (hostname, kernel_version, uptime, ...)
//   - GetStatus() → (is_running, last_error, ...)

int main(int argc, char *argv[]) {
    // 1. Connect to D-Bus
    DBusConnection *conn = dbus_bus_get(DBUS_BUS_SYSTEM, &error);
    
    // 2. Request name
    dbus_bus_request_name(conn, "org.eldmp.Device", 0, &error);
    
    // 3. Register object path
    dbus_connection_register_object_path(conn, "/org/eldmp/Device", 
                                          &vtable, NULL);
    
    // 4. Event loop
    dbus_connection_setup_with_g_main(conn, NULL);
    
    return 0;
}
```

**Health Monitor Service (Sprint 8):**
- Polls `/proc/stat`, `/proc/meminfo` every 10 seconds
- Publishes D-Bus signal with CPU%, RAM%, Disk% usage
- Threshold alerts (e.g., CPU > 80%)

**Network Service (Sprint 14):**
- MQTT client library (libmosquitto)
- Subscribe to commands, publish sensor data
- Auto-reconnect on network loss

**OTA Manager (Sprint 15):**
- Download signed firmware package
- Verify signature (OpenSSL)
- Atomic A/B partition swap
- Rollback if boot fails 3 times

**Watchdog (Sprint 11 & 16):**
- Periodically signal "I'm alive" to kernel watchdog
- Linux application-level watchdog
- MCU-level watchdog (triggers MCU reset if Linux hangs)

---

### 4.4 Application Layer

**CLI Tool:**
```bash
eldmp info              # Show device information
eldmp status            # Show service status
eldmp config            # Get/set configuration
eldmp firmware update   # Check & install firmware update
eldmp ota-rollback      # Rollback to previous firmware
```

**REST API (optional, Extension Track):**
```
GET    /api/v1/device/info      → device information
GET    /api/v1/device/status    → service status
GET    /api/v1/sensor/temp      → latest temperature
POST   /api/v1/motor/speed      → set motor speed
GET    /api/v1/firmware/version → current version
POST   /api/v1/firmware/update  → trigger update
```

---

## Inter-Processor Communication (Sprint 13)

### Custom Binary Protocol

**Frame Format:**
```
[SOF] [Type] [ID] [Length] [Payload] [CRC] [EOF]
 1B    1B     1B    1B      N bytes   2B    1B

SOF = 0xA5 (Start of frame)
EOF = 0x5A (End of frame)
Type = 0x00 (Command), 0x01 (Response)
CRC = CRC16-CCITT (polynomial 0x1021)
```

**Example: Set Motor Speed**
```
Command (Linux → MCU):
[A5] [00] [01] [02] [32 50] [XXXX] [5A]
     cmd  id   len  payload  crc

Hex: A5 00 01 02 32 50 XXXX 5A
Meaning: Type=Cmd, ID=1, Payload=[0x32, 0x50] (50%), CRC=XXXX

Response (MCU → Linux):
[A5] [01] [01] [01] [00] [XXXX] [5A]
     resp id   len  ack  crc

Meaning: Type=Resp, ID=1, ACK=0x00 (success)
```

**Linux Implementation:**
```c
// Send command to MCU
int protocol_send_motor_command(int fd, uint8_t motor_id, uint8_t speed_percent) {
    uint8_t frame[MAX_FRAME_LEN];
    frame[0] = SOF;
    frame[1] = MSG_TYPE_CMD;
    frame[2] = motor_id;
    frame[3] = 1;  // payload length
    frame[4] = speed_percent;
    uint16_t crc = crc16(&frame[1], 4);
    frame[5] = (crc >> 8) & 0xFF;
    frame[6] = crc & 0xFF;
    frame[7] = EOF;
    
    return write(fd, frame, 8);
}

// Receive response from MCU
int protocol_receive_response(int fd, uint8_t *ack) {
    uint8_t frame[MAX_FRAME_LEN];
    read(fd, frame, MAX_FRAME_LEN);
    
    if (frame[0] != SOF) return -EINVAL;
    if (frame[7] != EOF) return -EINVAL;
    
    uint16_t crc_received = (frame[5] << 8) | frame[6];
    uint16_t crc_calc = crc16(&frame[1], 4);
    if (crc_received != crc_calc) return -EBADMSG;  // CRC mismatch
    
    *ack = frame[4];
    return 0;
}
```

**MCU Implementation:**
```c
// Receive command from Linux
void protocol_receive_command(void) {
    uint8_t frame[MAX_FRAME_LEN];
    uart_read(frame, MAX_FRAME_LEN);
    
    if (frame[0] != SOF) return;  // Invalid frame
    
    uint8_t type = frame[1];
    uint8_t motor_id = frame[2];
    uint8_t speed = frame[4];
    
    // Verify CRC
    uint16_t crc_rx = (frame[5] << 8) | frame[6];
    uint16_t crc_calc = crc16(&frame[1], 4);
    if (crc_rx != crc_calc) {
        protocol_send_error(ERR_CRC);
        return;
    }
    
    // Execute command
    motor_set_speed(motor_id, speed);
    
    // Send acknowledgment
    protocol_send_response(RESPONSE_ACK, motor_id, 0);
}
```

---

## Module Dependencies

```
┌─────────────────────────────────────────────────────────────┐
│ Application (CLI, REST)                                     │
├─────────────────────────────────────────────────────────────┤
│ Depends on: Device Manager, Network Manager, OTA Manager    │
├─────────────────────────────────────────────────────────────┤
│ Services (Device, Health, Network, OTA)                     │
├─────────────────────────────────────────────────────────────┤
│ Depends on: D-Bus IPC, Logger, Config, HAL                  │
├─────────────────────────────────────────────────────────────┤
│ Middleware (D-Bus wrapper, Logger, Config)                  │
├─────────────────────────────────────────────────────────────┤
│ Depends on: HAL, kernel headers                             │
├─────────────────────────────────────────────────────────────┤
│ HAL (GPIO, UART, I2C, SPI, CAN)                             │
├─────────────────────────────────────────────────────────────┤
│ Depends on: Linux device drivers (/dev/*)                   │
├─────────────────────────────────────────────────────────────┤
│ Drivers (GPIO driver, char device)                          │
├─────────────────────────────────────────────────────────────┤
│ Depends on: Linux kernel, Device Tree                       │
├─────────────────────────────────────────────────────────────┤
│ Kernel & Device Tree                                        │
├─────────────────────────────────────────────────────────────┤
│ Depends on: Bootloader, hardware                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagrams

### Scenario 1: Set Motor Speed from Cloud

```
Cloud
│
└─→ MQTT Broker
    │
    └─→ Linux Network Service
        │
        └─→ D-Bus signal publish
            │
            └─→ Device Manager
                │
                ├─ Parse command
                ├─ Send via Protocol (UART/SPI/CAN)
                │
                └─→ MCU Firmware
                    │
                    ├─ Receive via UART ISR
                    ├─ Enqueue to FreeRTOS queue
                    │
                    └─→ Motor Control Task
                        │
                        ├─ Receive from queue
                        ├─ Set PWM duty (hardware)
                        │
                        └─→ Motor GPIO
                            │
                            └─→ Physical Motor
                                │
                                └─→ Speed changes
```

### Scenario 2: Read Temperature & Send to Cloud

```
MCU Sensor
│
└─→ ADC (bare-metal driver)
    │
    └─→ Sensor Reading Task (FreeRTOS)
        │
        ├─ Queue: temperature value
        │
        └─→ LVGL UI Task
            │
            ├─ Display on LCD
            │
            └─→ Also queue to Linux bridge task
                │
                └─→ Send via Protocol (UART)
                    │
                    └─→ Linux Device Driver
                        │
                        └─→ Device Manager Service
                            │
                            ├─ Log to /var/log/eldmp.log
                            ├─ Save to config database
                            │
                            └─→ Network Manager Service
                                │
                                └─→ MQTT Publish
                                    │
                                    └─→ Cloud Dashboard
                                        │
                                        └─→ Display on UI
```

---

## Performance Characteristics

| Layer | Latency | Throughput | Notes |
|---|---|---|---|
| MCU Bare-metal ISR | < 1 µs | — | Direct hardware access |
| FreeRTOS context switch | 10–50 µs | — | Depends on ARM cycle count |
| LVGL GUI render | 10–50 ms | 30 fps | Depends on LCD resolution |
| Linux system call | 1–10 µs | — | Varies with kernel load |
| D-Bus call | 1–5 ms | — | IPC overhead |
| UART protocol (9600 baud) | 1–10 ms | 1.2 KB/s | Limited by baud rate |
| MQTT publish | 100–500 ms | — | Depends on network latency |

---

## For More Details

- **[../ARCHITECTURE.md](../ARCHITECTURE.md)** — High-level architecture overview
- **[../decisions/](decisions/)** — Architecture Decision Records
- **Code examples:** `src/` directory

---

**Last Updated:** Sprint 0 (Milestone 0.1)  
**Next Review:** Sprint 6 (Kernel & Driver details)  
**Status:** 📋 Architecture framework complete
