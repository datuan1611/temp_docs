# ELDMP Setup Guide — Ubuntu Server Native + Docker Engine Chuẩn Công Nghiệp

Hướng dẫn đầy đủ để chuẩn hoá môi trường phát triển ELDMP trên **Ubuntu Server** (bất kỳ hạ tầng: bare-metal, VM với hypervisor bất kỳ, hay Cloud Instance) với **Docker Engine cài chính thức qua apt repository** — không qua bất kỳ lớp wrapper/giả lập nào (Colima, OrbStack, Docker Desktop). Đây là mô hình sát nhất với môi trường Production/CI Server thực tế trong công nghiệp, đảm bảo tính độc lập tuyệt đối và khả năng tái sử dụng trên bất kỳ hệ thống Linux nào.

---

## Table of Contents

1. [Bối Cảnh & Vì Sao Chuẩn Hoá Sang Ubuntu Server Native](#bối-cảnh--vì-sao-chuẩn-hoá-sang-ubuntu-server-native)
2. [Yêu Cầu](#yêu-cầu)
3. [Phụ Lục — Nếu Bạn Chưa Có Ubuntu Server (Ghi Chú VMware Fusion Trên MacBook M1/Big Sur)](#phụ-lục--nếu-bạn-chưa-có-ubuntu-server-ghi-chú-vmware-fusion-trên-macbook-m1big-sur)
4. [Bước 1 — Tối Ưu Hệ Thống (Swap 4GB + Sysctl)](#bước-1--tối-ưu-hệ-thống-swap-4gb--sysctl)
5. [Bước 2 — Cài Docker Engine Chính Thức (APT Repository) + Compose Plugin](#bước-2--cài-docker-engine-chính-thức-apt-repository--compose-plugin)
6. [Bước 3 — Docker User Permissions & Daemon JSON](#bước-3--docker-user-permissions--daemon-json)
7. [Bước 4 — Xây Dựng Toolchain Hoàn Chỉnh Thủ Công (Bare-Metal, FreeRTOS, Debug, UT/IT, Sanitizers)](#bước-4--xây-dựng-toolchain-hoàn-chỉnh-thủ-công-bare-metal-freertos-debug-utit-sanitizers)
8. [Bước 5 — Verification Suite (`verify-env.sh`)](#bước-5--verification-suite-verify-envsh)
9. [Bước 6 — Kết Nối VS Code Remote-SSH (Windows/macOS/Linux)](#bước-6--kết-nối-vs-code-remote-ssh-windowsmacoslinux)
10. [Bước 7 — Clone Repo & Kết Nối GitHub](#bước-7--clone-repo--kết-nối-github)
11. [Bước 8 — Build & Test Trực Tiếp Trên Server](#bước-8--build--test-trực-tiếp-trên-server)
12. [Bước 9 — Tái Lập Môi Trường Trên Một Máy Ubuntu Khác (Học Cách "Đóng Gói" Thật Sự)](#bước-9--tái-lập-môi-trường-trên-một-máy-ubuntu-khác-học-cách-đóng-gói-thật-sự)
13. [Bước 10 — Flash Firmware MCU (Từ Máy Có Cổng USB Vật Lý)](#bước-10--flash-firmware-mcu-từ-máy-có-cổng-usb-vật-lý)
14. [Bước 11 — Cross-Compile & Phân Tích Ứng Dụng Linux (BeagleBone Black)](#bước-11--cross-compile--phân-tích-ứng-dụng-linux-beaglebone-black)
15. [Bước 12 — Phối Hợp Với Máy Linux Build Yocto/Buildroot Riêng (Sprint 12)](#bước-12--phối-hợp-với-máy-linux-build-yoctobuildroot-riêng-sprint-12)
16. [Bước 13 — CI/CD Hai Tầng](#bước-13--cicd-hai-tầng)
17. [Quản Lý Docker & Hệ Thống](#quản-lý-docker--hệ-thống)
18. [Troubleshooting](#troubleshooting)
19. [Ghi Chú Về Các Công Cụ Trước Đó (Lima/OrbStack/Colima)](#ghi-chú-về-các-công-cụ-trước-đó-limaorbstackcolima)

---

## Bối Cảnh & Vì Sao Chuẩn Hoá Sang Ubuntu Server Native

**Lịch sử quyết định (portfolio value — quá trình tư duy kỹ thuật thật):**

1. **Lima** (VM mã nguồn mở đầu tiên) — hoạt động, nhưng cần thêm Docker riêng.
2. **OrbStack** — cấp RAM động, nhưng yêu cầu macOS mới, không phù hợp máy chạy Big Sur.
3. **Colima** — thử tiếp vì mã nguồn mở, nhưng **THẤT BẠI THẬT khi cài đặt**: Colima không còn hỗ trợ macOS 11.7.11 Big Sur. Đây là lỗi thực tế đã gặp phải, không phải suy đoán trước.
4. **VMware Fusion** cũng được cân nhắc thay Colima, nhưng bị loại ngay từ đầu — Fusion 13 yêu cầu tối thiểu macOS 12 Monterey, không hỗ trợ Big Sur.
5. **Ubuntu Server Native + Docker Engine chuẩn công nghiệp** (tài liệu này) — dùng **VMware Fusion Professional** (bản Pro, mã phiên bản bạn cung cấp: 20191287) để cài **Ubuntu Server 26.04 LTS ARM64** trực tiếp, sau đó **mọi thứ từ đây trở đi là Ubuntu Server 100%** — không còn phụ thuộc bất kỳ công cụ ảo hoá/giả lập macOS nào nữa.

   **Đính chính so với ghi chú trước đó trong tài liệu này:** trước đây tài liệu từng loại VMware Fusion khỏi lựa chọn, dựa trên thông tin Fusion 13 yêu cầu tối thiểu macOS 12 Monterey (không hỗ trợ Big Sur). Trên thực tế, **VMware Fusion Professional (mã phiên bản 20191287 bạn cung cấp) đã chạy tốt trên macOS 11.7.11 Big Sur** — tôi chưa xác minh được chính xác "20191287" tương ứng version/build number cụ thể nào của Fusion (không tra cứu ra), nên không khẳng định chắc đây là Fusion mấy — chỉ ghi lại đúng mã bạn cung cấp làm tham chiếu. Bằng chứng thực nghiệm trực tiếp (đã cài đặt và chạy Ubuntu Server thành công) được ưu tiên hơn suy đoán trước đó — tài liệu này cập nhật theo đúng thực tế đã kiểm chứng.

**Vì sao đây là điểm dừng chân đúng đắn (không phải "công cụ thứ 5 rồi lại đổi tiếp"):**
- Ubuntu Server + Docker Engine cài qua apt là **tiêu chuẩn ngành**, không phải sản phẩm của một công ty tư nhân có thể ngừng hỗ trợ macOS phiên bản nào đó bất cứ lúc nào (như đã xảy ra với Colima).
- Toàn bộ script/tài liệu từ đây **không còn nhắc gì tới macOS hay Big Sur** — chúng mô tả một Ubuntu Server chuẩn, chạy được y nguyên trên máy thật, VM khác, hay Cloud Instance (AWS/GCP/Azure) sau này nếu cần mở rộng.
- Việc "làm sao có được một Ubuntu Server đang chạy" (VMware Fusion trên Mac, hay bất kỳ cách nào khác) tách biệt hoàn toàn khỏi "làm sao chuẩn hoá môi trường phát triển trên Ubuntu Server đó" — tài liệu này chỉ tập trung vào vế thứ hai, vế thứ nhất được ghi chú riêng ở Mục 3 (Phụ Lục) cho đúng bối cảnh thực tế của bạn.

---

## Yêu Cầu

- Một Ubuntu Server đang chạy — **26.04 LTS ARM64 "Resolute Raccoon"** (khuyến nghị, ARM64 native cho Apple Silicon), hoặc 24.04/22.04 LTS nếu bạn dùng x86_64
- Tối thiểu 4GB RAM (khuyến nghị 8GB+; 3.5GB là mức tối thiểu thực tế đã kiểm chứng cho dự án ELDMP, có swap 4GB bù thêm)
- Tối thiểu 40GB dung lượng đĩa trống
- Quyền `sudo` trên server
- SSH access từ máy client (Windows/macOS/Linux đều được — Bước 6)

---

## Phụ Lục — Nếu Bạn Chưa Có Ubuntu Server (Ghi Chú VMware Fusion Trên MacBook M1/Big Sur)

Nếu bạn ở đúng bối cảnh của dự án ELDMP (MacBook Pro M1, 8GB RAM, macOS 11.7.11 Big Sur) và chưa có Ubuntu Server nào đang chạy, đây là cách đã kiểm chứng thành công thực tế:

```bash
# Trên macOS — cài VMware Fusion Professional (nay đã MIỄN PHÍ cho cá nhân
# và thương mại, không cần license key — tải trực tiếp từ Broadcom Support
# Portal: https://support.broadcom.com, hoặc thử qua Homebrew cask nếu có)
brew install --cask vmware-fusion
```

Nếu lệnh Homebrew trên báo lỗi không tìm thấy cask, tải trực tiếp bộ cài từ Broadcom Support Portal (đăng nhập bằng tài khoản Broadcom/VMware miễn phí) rồi cài như ứng dụng macOS thông thường.

Trong VMware Fusion (GUI): **File → New...** → **Install from disc or image** → kéo thả ISO **Ubuntu Server 26.04 LTS ARM64** (tải từ [ubuntu.com/download/server/arm](https://ubuntu.com/download/server/arm)) → chọn hệ điều hành khách **Linux → Ubuntu 64-bit ARM** → **Customize Settings** trước khi khởi tạo, cấu hình:

| Thông số | Giá trị (trong Fusion: Processors & Memory / Hard Disk) |
|---|---|
| Architecture | ARM64 (aarch64) — native cho Apple Silicon |
| Processors | 3 cores |
| Memory | 3584 MB (3.5GB) |
| Hard Disk | 40GB — Fusion mặc định dùng disk dạng "growable" (tương đương Dynamic/Sparse, không preallocate hết ngay) |

Cài Ubuntu Server theo trình cài đặt chuẩn (chọn OpenSSH server khi được hỏi để có SSH ngay từ lần boot đầu). Sau khi cài xong, ghi lại địa chỉ IP của VM (`ip addr show` trong VM, hoặc xem trong Fusion ở tab Network của VM) để SSH vào từ Bước 6.

**Nếu bạn dùng hạ tầng khác** (bare-metal, UTM, VMware ESXi, Proxmox, cloud instance AWS/GCP/Azure ARM64 hoặc x86_64, WSL2, ...) — bỏ qua toàn bộ mục này, chỉ cần đảm bảo có Ubuntu Server 22.04/24.04/26.04 LTS đang chạy và SSH được vào, rồi tiếp tục từ Bước 1.

---

## Bước 1 — Tối Ưu Hệ Thống (Swap 4GB + Sysctl)

> **Mục đích của mục này:** giải thích đủ sâu để bạn tự tay làm được từng lệnh mà KHÔNG cần chạy `setup-ubuntu-docker.sh` — script chỉ nên dùng sau khi bạn đã hiểu nó làm gì, không phải thay thế việc hiểu.

### 1.1 Mental Model — Swap Là Gì, Vì Sao Cần

RAM là bộ nhớ nhanh nhưng hữu hạn. Khi tiến trình (compile, container, VS Code Server) xin cấp phát nhiều hơn RAM còn trống, kernel Linux có hai lựa chọn: **OOM Killer giết tiến trình** (mất việc đang làm), hoặc **swap ra đĩa** — tạm chuyển các trang bộ nhớ (memory page) ít dùng tới xuống một vùng đĩa dành riêng, giải phóng RAM cho tiến trình đang cần. Swap **không thay thế RAM** (đĩa chậm hơn RAM hàng nghìn lần) — nó chỉ là van an toàn tránh crash khi RAM tạm thời quá tải.

Với máy 3.5GB RAM chạy đồng thời: hệ điều hành, Docker daemon, một vài container, và trình biên dịch (`cmake --build` có thể spawn nhiều tiến trình `cc1`/`ld` song song) — việc chạm ngưỡng RAM là bình thường, không phải bất thường. Swap 4GB là van an toàn cho đúng tình huống này.

### 1.2 Tự Tay Tạo Swap File — Từng Lệnh, Giải Thích Từng Cờ

```bash
swapon --show               # liệt kê mọi vùng swap đang active, kèm kích thước/priority
cat /etc/fstab | grep swap  # thấy xuất hiện /swap.img là đạt chuẩn, tự động mount khi boot
```
Command trên kiểm tra toàn bộ phân vùng swap đang active của hệ thống.
Nếu phân vùng swap đã đạt chuẩn thì không cần tạo Swap File như bên dưới.

```bash
sudo fallocate -l 4G /swapfile
```
`fallocate` cấp phát ngay 4GB dung lượng đĩa liên tục cho file `/swapfile` (nhanh hơn `dd if=/dev/zero` vì không cần ghi từng byte — chỉ đánh dấu block đã cấp phát trong filesystem). Nếu filesystem không hỗ trợ `fallocate` (hiếm, một số ZFS/network filesystem cũ), dùng thay: `sudo dd if=/dev/zero of=/swapfile bs=1M count=4096`.

```bash
sudo chmod 600 /swapfile
```
Chỉ root đọc/ghi được. **Nếu bỏ qua bước này, `mkswap`/`swapon` sẽ TỪ CHỐI chạy** với cảnh báo "insecure permissions" — đây là cơ chế bảo vệ có chủ đích của kernel: swap file chứa nội dung RAM thô (có thể có mật khẩu, key đang xử lý trong bộ nhớ), quyền lỏng lẻo là lỗ hổng bảo mật thật.

```bash
sudo mkswap /swapfile
```
Ghi một **swap signature** vào đầu file — một header đặc biệt đánh dấu "đây là vùng swap hợp lệ", kèm UUID riêng. Không có bước này, `swapon` sẽ báo lỗi "not a valid swap partition/file".

```bash
sudo swapon /swapfile
```
Báo kernel **kích hoạt ngay lập tức** vùng swap này — từ giây phút này, kernel có thể bắt đầu dùng nó khi cần, không cần reboot.

```bash
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```
`swapon` chỉ có hiệu lực tới lần reboot tiếp theo. Dòng này trong `/etc/fstab` (bảng mount filesystem) báo hệ thống tự `swapon` lại file này **mỗi lần boot** — thiếu dòng này, swap "biến mất" sau khi restart máy dù file `/swapfile` vẫn còn nguyên trên đĩa (dễ gây bối rối khi debug).

### 1.3 Dự Đoán Trước Khi Kiểm Chứng (Prediction Exercise)

Trước khi chạy lệnh kiểm chứng bên dưới, hãy tự dự đoán: nếu bạn tạo swap NHƯNG quên bước `chmod 600`, `mkswap` sẽ báo lỗi gì? (Gợi ý: tìm chữ "insecure" trong output). Nếu bạn quên dòng `/etc/fstab`, sau khi `reboot`, lệnh `free -h` sẽ hiện Swap bằng bao nhiêu? Tự trả lời trước, rồi thử nghiệm thật trên VM để so khớp dự đoán với thực tế — đây là cách học nhớ lâu hơn nhiều so với đọc suông.

### 1.4 Kiểm Chứng

```bash
swapon --show           # liệt kê mọi vùng swap đang active, kèm kích thước/priority
cat /proc/swaps         # tương đương, đọc trực tiếp từ kernel qua virtual filesystem /proc
free -h                 # xem tổng RAM + Swap dễ đọc
```

### 1.5 Tối Ưu Kernel Parameters (sysctl) — Cơ Chế Bên Trong

`/proc/sys/` là một **virtual filesystem** — không phải file thật trên đĩa, mà là cửa sổ để đọc/ghi trực tiếp vào biến số của kernel đang chạy trong RAM. Lệnh `sysctl` chỉ là một cách gõ lệnh tiện lợi để đọc/ghi vào đó; bạn hoàn toàn có thể làm thủ công bằng `cat`/`echo`:

```bash
# Cách sysctl làm bên dưới (tự tay thử để hiểu, không cần thiết phải làm vậy hàng ngày):
cat /proc/sys/vm/swappiness              # đọc giá trị hiện tại
echo 10 | sudo tee /proc/sys/vm/swappiness   # ghi trực tiếp — có hiệu lực NGAY, nhưng mất khi reboot
```

Vì ghi trực tiếp vào `/proc/sys/` mất hiệu lực sau reboot, ta dùng file cấu hình để `sysctl --system` tự đọc và áp dụng lại mỗi lần boot:

```bash
sudo tee /etc/sysctl.d/99-eldmp-tuning.conf << 'EOF'
vm.swappiness=10
vm.overcommit_memory=1
fs.inotify.max_user_watches=524288
fs.inotify.max_user_instances=512
EOF
sudo sysctl --system
```

| Tham số | Cơ chế bên trong | Vì sao cần cho ELDMP cụ thể | Nếu KHÔNG đặt |
|---|---|---|---|
| `vm.swappiness=10` | Thang điểm 0-100 kernel dùng để quyết định "nên swap hay nên giải phóng cache trang trước". Mặc định Ubuntu là 60 (khá thiên về swap sớm) | Compile C/C++ tạo nhiều file cache tạm — muốn kernel ưu tiên giữ RAM cho tiến trình compile, chỉ swap khi thực sự bí | Hệ thống swap "quá sớm" dù RAM còn trống kha khá → compile/container chậm không cần thiết |
| `vm.overcommit_memory=1` | Mặc định (0) kernel ước lượng "liệu có đủ RAM+swap không" trước khi cho phép cấp phát; giá trị 1 cho phép cấp phát thoải mái, kernel chỉ thực sự cấp RAM khi trang đó được ghi lần đầu (copy-on-write) | `fork()` (dùng khi shell spawn tiến trình con, Docker khởi tạo container) tạm thời "xin gấp đôi" bộ nhớ tiến trình cha trước khi `exec()` thay thế — trên máy RAM ít, kiểu ước lượng mặc định dễ từ chối cấp phát dù thực tế đủ dùng | `fork()` có thể thất bại giả ("Cannot allocate memory") ngay cả khi RAM+swap còn dư thực tế |
| `fs.inotify.max_user_watches` | Giới hạn số file/thư mục một user có thể "theo dõi thay đổi" cùng lúc qua cơ chế `inotify` của kernel | VS Code Server (Remote-SSH) theo dõi toàn bộ file trong workspace để tự refresh — một repo nhiều file như ELDMP dễ vượt mức mặc định (thường 8192-65536 tuỳ bản Ubuntu) | Lỗi "ENOSPC: System limit for number of file watchers reached", VS Code ngừng tự phát hiện thay đổi file |

### 1.6 Lỗi Thường Gặp Ở Bước Này

- **`mkswap` báo "insecure permissions"** → quên `chmod 600` trước đó (mục 1.2)
- **Swap "biến mất" sau reboot** → quên dòng `/etc/fstab`, hoặc gõ sai cú pháp dòng đó (kiểm tra bằng `cat /etc/fstab | grep swap`)
- **`sysctl --system` không báo lỗi nhưng giá trị không đổi** → kiểm tra file `.conf` có đúng thư mục `/etc/sysctl.d/` không, và tên file phải kết thúc bằng `.conf`

---

## Bước 2 — Cài Docker Engine Chính Thức (APT Repository) + Compose Plugin

### 2.1 Mental Model — "Docker Engine" Thực Ra Là Gì

"Docker" không phải một chương trình duy nhất — đó là **kiến trúc nhiều lớp client/daemon**:

```
docker (CLI client, bạn gõ lệnh)
   │  giao tiếp qua Unix socket /var/run/docker.sock
   ▼
dockerd (Docker daemon — tiến trình nền, quản lý image/network/volume)
   │
   ▼
containerd (tách riêng từ Docker năm 2017, quản lý vòng đời container thực tế)
   │
   ▼
runc (thực thi thấp nhất — dùng namespace + cgroup của kernel Linux để cô lập container)
```

Hiểu điều này giải thích vì sao `docker ps` chạy được ngay cả khi bạn gõ lệnh từ một terminal khác — bạn đang nói chuyện với `dockerd` qua socket, không phải chạy trực tiếp container trong tiến trình CLI.

### 2.2 Vì Sao KHÔNG Dùng `apt install docker.io`

Ubuntu có sẵn gói `docker.io` trong kho apt mặc định — cài nhanh hơn, nhưng đây là bản do **Ubuntu/Debian tự đóng gói lại**, theo chu kỳ release của Ubuntu chứ không phải chu kỳ phát hành của Docker Inc. — thường **cũ hơn vài phiên bản** so với bản chính thức, và không có Buildx/Compose Plugin tích hợp sẵn theo chuẩn mới. Cài từ apt repository của chính Docker Inc. đảm bảo luôn có bản mới nhất, đúng cách một server production/CI thật trong công nghiệp làm.

### 2.3 Tự Tay Từng Bước — Giải Thích Cơ Chế GPG Repository

```bash
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
```
Tải **public key GPG** của Docker Inc. về máy — đây là "chữ ký" mà mọi gói `.deb` từ repository của họ sẽ được ký bằng private key tương ứng. Không có key này, `apt` sẽ từ chối cài (hoặc cảnh báo "unsigned") — đây chính là cơ chế chống giả mạo gói phần mềm (supply chain security): nếu ai đó chèn một server giả mạo vào giữa đường truyền, gói `.deb` của họ sẽ không khớp chữ ký, `apt` phát hiện và từ chối.

```bash
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list
```
Dòng này tạo một **repository entry mới** — báo `apt` "còn một nguồn cài đặt nữa ở đây". Ba biến động quan trọng:
- `$(dpkg --print-architecture)` → tự phát hiện `arm64` hay `amd64`, không hard-code
- `signed-by=...` → chỉ định RÕ dùng key nào để verify (khác cách cũ `apt-key add` không rõ ràng, đã bị Debian/Ubuntu loại bỏ vì lý do bảo mật)
- `$VERSION_CODENAME` → tự lấy đúng tên bản Ubuntu (`noble`, `resolute`, ...) từ `/etc/os-release`, tránh gõ nhầm tay

```bash
sudo apt-get update -y
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```
`apt-get update` đọc lại danh sách gói từ MỌI repository đã khai báo (bao gồm repo Docker vừa thêm). Bốn gói cài vào tương ứng đúng 4 lớp kiến trúc ở mục 2.1: `docker-ce` (daemon), `docker-ce-cli` (client), `containerd.io`, cộng `docker-buildx-plugin` (build đa kiến trúc) và `docker-compose-plugin` (subcommand `docker compose`, thay thế công cụ `docker-compose` độc lập cũ).

### 2.4 Kiểm Chứng

```bash
sudo docker --version
sudo docker compose version
sudo systemctl status docker      # xác nhận daemon đang chạy (active/running)
sudo ls -la /var/run/docker.sock  # xác nhận socket file tồn tại, group "docker" sở hữu
```

### 2.5 Lỗi Thường Gặp

- **"E: The repository ... does not have a Release file"** → sai `$VERSION_CODENAME` (thường do dùng bản Ubuntu quá mới, Docker chưa kịp build repo cho bản đó — kiểm tra tại `download.docker.com/linux/ubuntu/dists/`)
- **"NO_PUBKEY" khi apt update** → bước tải GPG key ở 2.3 thất bại hoặc bị bỏ qua

---

## Bước 3 — Docker User Permissions & Daemon JSON

### 3.1 Mental Model — Vì Sao `usermod -aG docker` Là Vấn Đề Bảo Mật Đáng Biết

```bash
sudo usermod -aG docker "$USER"
```

Lệnh này thêm user hiện tại vào group Linux tên `docker` — group này **sở hữu quyền đọc/ghi** socket `/var/run/docker.sock`. Nghe vô hại, nhưng **về bản chất tương đương cấp quyền root**: bất kỳ ai điều khiển được Docker daemon đều có thể mount toàn bộ filesystem host vào một container rồi thao túng tự do (`docker run -v /:/host ubuntu chroot /host`). Đây KHÔNG phải lỗ hổng — là thiết kế có chủ đích của Docker — nhưng là điều một Senior Engineer cần biết rõ, không chỉ gõ lệnh theo quán tính. Trên server multi-user thật, cân nhắc kỹ ai được vào group này.

### 3.2 Daemon JSON — Cơ Chế Đọc Cấu Hình

`dockerd` đọc file `/etc/docker/daemon.json` **một lần duy nhất lúc khởi động** (không phải mỗi request) — đây là lý do sau khi sửa file này luôn cần `systemctl restart docker`, chỉ `reload` không đủ.

```bash
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json << 'EOF'
{
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "3" },
  "storage-driver": "overlay2"
}
EOF
sudo systemctl restart docker
```

`log-driver: json-file` là driver mặc định của Docker — MỌI dòng `stdout`/`stderr` của container được ghi vào một file JSON trên host, **không tự giới hạn dung lượng nếu không khai báo** `log-opts`. Với đĩa 40GB, một container chạy lâu ngày in log liên tục (ví dụ lỗi loop vô hạn) có thể lặng lẽ lấp đầy ổ đĩa — `max-size`/`max-file` giới hạn tổng dung lượng log mỗi container tối đa 30MB (10MB × 3 file xoay vòng).

### 3.3 Dự Đoán Trước Khi Thử

Trước khi chạy `docker ps`, dự đoán: nếu bạn VỪA chạy `usermod -aG docker` nhưng CHƯA đăng xuất/đăng nhập lại, lệnh `docker ps` (không sudo) sẽ thành công hay báo lỗi? Vì sao? (Gợi ý: group membership của một tiến trình đang chạy được nạp lúc login, không tự cập nhật realtime — đây là khái niệm quan trọng áp dụng cho MỌI thay đổi group trên Linux, không riêng Docker).

### 3.4 Kiểm Chứng

```bash
groups                              # xác nhận "docker" xuất hiện trong danh sách group
docker ps                           # không sudo — phải chạy được nếu group đã nạp
docker run --rm hello-world         # kiểm tra end-to-end: pull image + chạy container
sudo python3 -m json.tool /etc/docker/daemon.json   # xác nhận JSON hợp lệ (dockerd im lặng fail nếu JSON sai cú pháp)
```

---

## Bước 4 — Xây Dựng Toolchain Hoàn Chỉnh Thủ Công (Bare-Metal, FreeRTOS, Debug, UT/IT, Sanitizers)

> **Đây là phần cốt lõi trả lời "làm sao dựng một VM cho embedded system qua Docker Engine đúng chuẩn"** — đọc và tự tay gõ từng lệnh, đừng chỉ chạy `scripts/helper/setup-ubuntu-docker.sh` (script chỉ tự động hoá Bước 1-3, KHÔNG cài toolchain ở mục này).

### 4.1 Mental Model — Vì Sao Cần Nhiều Compiler Khác Nhau

Ubuntu Server có sẵn `gcc` — nhưng đó là compiler sinh mã cho **chính kiến trúc CPU của máy đang chạy** (arm64 nếu VM là ARM64). Firmware STM32 chạy trên lõi **ARM Cortex-M** hoàn toàn khác (không hệ điều hành, không libc đầy đủ, tập lệnh Thumb) → cần **cross-compiler**: chạy trên Ubuntu nhưng sinh ra mã máy cho kiến trúc khác hẳn.

BeagleBone Black chạy Linux thật nhưng trên lõi **ARM Cortex-A8** (armv7, 32-bit, "armhf") — khác cả target Cortex-M lẫn host — cần cross-compiler **thứ hai** riêng biệt. Một máy dev embedded cần nhiều compiler cùng lúc, mỗi cái nhắm một đích khác nhau — đây là khái niệm nền tảng, không phải đặc thù riêng ELDMP.

### 4.2 Cài Đặt Từng Nhóm Công Cụ — Giải Thích Lý Do, Không Chỉ Lệnh

#### 4.2.1 Cross-compiler Bare-metal (STM32F446, STM32H743)

```bash
sudo apt-get install -y gcc-arm-none-eabi gdb-multiarch
```

Tên gói giải mã: **arm** (kiến trúc đích) — **none** (không hệ điều hành, bare-metal) — **eabi** (Embedded Application Binary Interface, chuẩn ABI riêng cho hệ nhúng — khác `gnueabihf` dùng cho Linux có OS ở mục 4.2.4).

Kiểm chứng bằng một lần biên dịch thử (không cần hardware thật):

```bash
echo 'int main(void){return 0;}' > /tmp/test.c
arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -c /tmp/test.c -o /tmp/test.o
file /tmp/test.o   # phải hiện "ELF 32-bit LSB relocatable, ARM"
```

Nếu `file` báo đúng kiến trúc ARM 32-bit (khác kiến trúc máy host) — cross-compile đã hoạt động đúng.

#### 4.2.2 FreeRTOS — Không Cần Toolchain Riêng

FreeRTOS là **source code thuần** (không phải binary cài qua apt) — Sprint 4 sẽ `git clone` kernel FreeRTOS, rồi build bằng CHÍNH toolchain ở mục 4.2.1. Không có bước cài đặt riêng ở Sprint 0 — chỉ cần xác nhận toolchain bare-metal đã sẵn sàng là đủ điều kiện tiên quyết.

#### 4.2.3 Debug Tooling

`gdb-multiarch` (đã cài cùng 4.2.1) là bản GDB hỗ trợ debug **nhiều kiến trúc CPU từ cùng một binary GDB** — cần thiết vì bạn sẽ debug cả code Cortex-M (qua OpenOCD + ST-Link, từ máy có cổng USB vật lý — xem Bước 10) lẫn code chạy trên host. GDB thường của Ubuntu chỉ debug được đúng kiến trúc của máy đó.

#### 4.2.4 Cross-compiler Embedded Linux (BeagleBone Black)

```bash
sudo apt-get install -y gcc-arm-linux-gnueabihf g++-arm-linux-gnueabihf
```

`gnueabihf` = GNU EABI **Hard-Float** — dùng thẳng đơn vị dấu phẩy động phần cứng (FPU) của Cortex-A8 thay vì giả lập bằng phần mềm, đúng khả năng phần cứng thật của BeagleBone Black.

```bash
printf '#include <stdio.h>\nint main(void){printf("OK\\n");return 0;}\n' > /tmp/test2.c
arm-linux-gnueabihf-gcc -o /tmp/test2 /tmp/test2.c
file /tmp/test2   # ELF 32-bit LSB executable, ARM, EABI5
```

#### 4.2.5 Static Analysis (Nền Tảng MISRA C — Cppcheck, Clang-Tidy)

```bash
sudo apt-get install -y clang clang-tidy clang-tools cppcheck
```

- **Cppcheck** phân tích mã nguồn **không cần compile được** — quét pattern lỗi phổ biến (biến chưa khởi tạo, chia cho 0, out-of-bounds tĩnh...). Addon `--addon=misra` áp chuẩn MISRA C nhưng cần file rule text riêng (bản quyền MISRA/HORIBA MIRA, không tự do tải).
- **Clang-Tidy** phân tích sâu hơn — cần biên dịch được thật (dùng chung AST với Clang), bắt được nhiều lỗi ngữ nghĩa hơn Cppcheck, đổi lại chạy chậm hơn.

#### 4.2.6 Dynamic Analysis — Sanitizers (Trọng Tâm)

**AddressSanitizer (ASan)** — chèn code kiểm tra vào MỌI lần truy cập bộ nhớ lúc compile (instrumentation): bao quanh mỗi vùng cấp phát bằng "redzone" (vùng đệm vô hình) và một bảng "shadow memory" theo dõi byte nào hợp lệ. Truy cập lệch ra redzone → chương trình dừng ngay, in báo cáo chi tiết (địa chỉ, stack trace, loại lỗi: heap-buffer-overflow / use-after-free / stack-buffer-overflow).

**UndefinedBehaviorSanitizer (UBSan)** — bắt hành vi chuẩn C/C++ định nghĩa là "undefined" mà compiler thường không cảnh báo: tràn số nguyên có dấu, chia cho 0, dịch bit vượt độ rộng kiểu, truy cập qua con trỏ NULL.

**LeakSanitizer** — theo dõi mọi `malloc`/`new`; khi chương trình kết thúc, kiểm tra vùng nào chưa `free`/`delete`, báo cáo kèm stack trace **lúc cấp phát** (không phải lúc leak — vì leak chỉ phát hiện được khi chương trình đã kết thúc).

**MemorySanitizer (MSan)** — bắt lỗi đọc biến CHƯA khởi tạo. Khác 3 loại trên, MSan **chỉ hoạt động với Clang** (không có trên GCC), và **cần toàn bộ thư viện liên kết cùng (kể cả libc++) cũng được build lại có instrument MSan** — thiếu điều kiện này sẽ có false positive tràn lan. Đây là lý do MSan phức tạp hơn hẳn để dùng đúng.

```bash
sudo apt-get install -y valgrind libc++-dev libc++abi-dev binutils
```

**Cách compile với sanitizer:**

```bash
clang -fsanitize=address,undefined,leak -fno-omit-frame-pointer -g -o myprogram myprogram.c
./myprogram
```

- `-fno-omit-frame-pointer`: giữ frame pointer để sanitizer in được stack trace đầy đủ, dễ đọc
- `-g`: thêm debug symbol — thiếu cờ này, báo cáo sanitizer chỉ có địa chỉ hex, không có tên hàm/số dòng

**Bài tập kiểm chứng thực tế** — dự án đã có sẵn file cố ý lỗi để tự thử ngay:

```bash
clang -fsanitize=address,undefined,leak -fno-omit-frame-pointer -g \
    -o /tmp/test_asan tests/4_verification/test_asan.c
/tmp/test_asan 1   # 1 = memory leak cố ý
/tmp/test_asan 2   # 2 = use-after-free
/tmp/test_asan 3   # 3 = heap-buffer-overflow
```

Đọc kỹ output mỗi lần chạy — ASan in rõ loại lỗi, địa chỉ, và stack trace tới đúng dòng code trong [`tests/4_verification/test_asan.c`](tests/4_verification/test_asan.c). Đây là cách học nhanh nhất để nhận diện các loại lỗi bộ nhớ khi gặp thật trong code sau này.

**Valgrind** — công cụ bổ sung, cơ chế khác hẳn: **không cần recompile** (chạy binary gốc qua CPU ảo hoá mô phỏng, chậm hơn 10-50 lần nhưng không cần build lại) — hữu ích khi không có source để recompile, hoặc cần kiểm tra binary release:

```bash
valgrind --leak-check=full --track-origins=yes ./myprogram
```

#### 4.2.7 Testing Frameworks (UT/IT)

```bash
sudo apt-get install -y libgtest-dev catch2 ruby
cd /usr/src/googletest && sudo cmake -B build -S . && sudo cmake --build build && sudo cp build/lib/*.a /usr/lib
git clone --depth=1 https://github.com/ThrowTheSwitch/Unity.git /opt/unity
git clone --depth=1 https://github.com/ThrowTheSwitch/CMock.git /opt/cmock
```

| Framework | Dùng cho | Vì sao |
|---|---|---|
| **GoogleTest + CTest** | UT code C++ chạy trên Linux (Logger, Config, Services từ Sprint 1+) | Chuẩn công nghiệp phổ biến nhất cho C++, tích hợp sẵn qua CTest |
| **Unity + CMock** | UT code C bare-metal (Sprint 3+, "test on host" — chạy logic thuần trên máy dev, không cần hardware thật) | Unity nhẹ, không phụ thuộc STL/exception — phù hợp tài nguyên MCU; CMock tự sinh mock từ header, cần Ruby để chạy generator |
| **D-Bus** (đã cài `libdbus-1-dev` ở Bước 2) | IT — nhiều service giao tiếp qua IPC (Sprint 9+) | IT khác UT ở chỗ kiểm tra tương tác giữa nhiều thành phần THẬT đang chạy, không mock — D-Bus daemon là hạ tầng bắt buộc |

GoogleTest apt chỉ cấp SOURCE, không cấp sẵn thư viện đã biên dịch — dòng `cmake ... && cmake --build ...` tự build ra `libgtest.a`/`libgtest_main.a` rồi copy vào `/usr/lib` để link như thư viện hệ thống bình thường.

### 4.3 Kiểm Chứng Toàn Bộ Bằng Tay (Không Dùng Script)

```bash
arm-none-eabi-gcc --version && echo "✓ bare-metal toolchain"
arm-linux-gnueabihf-gcc --version && echo "✓ Linux app toolchain"
clang --version && cppcheck --version && clang-tidy --version && echo "✓ static analysis"
ls /usr/lib/libgtest*.a && echo "✓ GoogleTest built"
ls /opt/unity /opt/cmock && echo "✓ Unity/CMock cloned"
clang -fsanitize=address -x c -o /tmp/t -<<< 'int main(){return 0;}' && /tmp/t && echo "✓ ASan compile+run OK"
```

### 4.4 Đóng Gói Thành Container — Dockerfile Chính Là "Ghi Lại" Các Bước Trên

Mở [`.devcontainer/Dockerfile`](.devcontainer/Dockerfile) và đối chiếu — mỗi `RUN apt-get install` trong đó **chính là các lệnh bạn vừa gõ tay ở mục 4.2**, gộp thành các "layer" (mỗi `RUN` là một layer, Docker cache riêng từng layer — sửa layer cuối không phải build lại layer đầu, đây là lý do Dockerfile tách nhóm 1→7 thay vì gộp một `RUN` khổng lồ). Hiểu điều này nghĩa là bạn **không cần đọc Dockerfile như hộp đen** — nó là chính xác quy trình vừa làm thủ công, viết lại dưới dạng tái lập được:

```bash
docker build -f .devcontainer/Dockerfile -t eldmp-toolchain .
docker run --rm -it -v "$(pwd)":/workspace eldmp-toolchain
```

**Khi nào dùng container thay vì cài thẳng trên host:** container hữu ích khi cần **cô lập** (không muốn toolchain "làm bẩn" hệ thống host) hoặc cần **tái lập chính xác trên nhiều máy** (CI runner, đồng nghiệp khác). Với máy dev cá nhân đã hiểu rõ từng bước, cài thẳng trên host (mục 4.2) cũng hoàn toàn hợp lệ và nhanh hơn — không có "cách đúng duy nhất", chỉ có đánh đổi cô lập/tái lập vs tốc độ/đơn giản.

### 4.5 Lỗi Thường Gặp

- **`arm-none-eabi-gcc: command not found` sau khi cài** → mở terminal/SSH session MỚI (một số shell không tự nạp lại PATH trong session cũ)
- **ASan báo lỗi nhưng không có tên hàm, chỉ địa chỉ hex** → quên cờ `-g`
- **MSan báo hàng loạt false positive không liên quan code của bạn** → thư viện chuẩn chưa được build lại có instrument MSan (mục 4.2.6) — đây là lý do MSan phức tạp, không phải lỗi dùng sai
- **`cppcheck --addon=misra` báo lỗi thiếu rule file** → đúng như dự kiến, cần tự cung cấp (bản quyền MISRA)

---

## Bước 5 — Verification Suite (`verify-env.sh`)

```bash
./scripts/helper/verify-env.sh
```

| Cấp độ | Kiểm tra |
|---|---|
| **Level 1** | Ubuntu OS & Docker Health — `systemctl status docker`, `docker ps` không cần sudo, RAM/CPU/Swap |
| **Level 2** | Toolchain Availability — `arm-none-eabi-gcc`, `arm-linux-gnueabihf-gcc`, `clang`, `cppcheck`, `clang-tidy`, `cmake`, `ninja` |
| **Level 3** | STM32 & Embedded Linux Compilation Test — biên dịch [`tests/4_verification/test_stm32.c`](tests/4_verification/test_stm32.c) qua ARM GCC + cross-compile armhf |
| **Level 4** | Dynamic Sanitizer Test — biên dịch + chạy [`tests/4_verification/test_asan.c`](tests/4_verification/test_asan.c), xác nhận AddressSanitizer/LeakSanitizer bắt đúng lỗi memory leak cố ý |

Exit code `0` nếu mọi cấp độ PASS, `1` nếu có FAIL — dùng trực tiếp được trong CI (xem Bước 13).

**Lưu ý:** Level 2–4 cần toolchain (arm-none-eabi-gcc, clang, ...) có sẵn. Nếu bạn đã làm theo Bước 4 mục 4.2 (cài trực tiếp trên host), toolchain đã sẵn sàng và Level 2-4 chạy PASS ngay trên host, không cần container. Nếu bạn chọn phương án container ở Bước 4 mục 4.4 thay vì cài trên host, chạy `verify-env.sh` **bên trong container** để kiểm tra:

```bash
docker build -f .devcontainer/Dockerfile -t eldmp-toolchain .
docker run --rm -v "$(pwd)":/workspace eldmp-toolchain /workspace/scripts/helper/verify-env.sh
```

---

## Bước 6 — Kết Nối VS Code Remote-SSH (Windows/macOS/Linux)

### 6.1 Cài extension

Trên máy client (Windows, macOS, hoặc Linux — quy trình giống nhau):

```bash
code --install-extension ms-vscode-remote.remote-ssh
```

### 6.2 Cấu hình SSH config

Nếu vừa cài lại máy ảo, tạo lại container/VM mới với cùng IP 192.168.65.135,
có thể phát sinh lỗi "Host key SSH của máy ảo Ubuntu đã bị thay đổi",
thì ở trên máy host (macOS) chạy command dưới

```bash
ssh-keygen -R 192.168.65.135
```

Chạy các command dưới để cài đặt openssh-server trên VM Ubuntu

```bash
sudo apt update && sudp apt upgrade -y
sudo apt install openssh-server -y

sudo systemctl enable --now ssh
sudo systemctl status ssh

sudo ufw allow ssh
sudo ufw reload
```

**macOS/Linux** — thêm vào `~/.ssh/config`:

```
Host eldmp-server
    HostName <IP-CUA-UBUNTU-SERVER>
    User eldmp
    IdentityFile ~/.ssh/id_ed25519
```

**Windows 10/11** — dùng OpenSSH Client tích hợp sẵn (không cần PuTTY):

```powershell
# 1. Xác nhận OpenSSH Client đã bật (thường có sẵn từ Windows 10 1809+)
Get-WindowsCapability -Online | Where-Object Name -like 'OpenSSH.Client*'
# Nếu "State: NotPresent" → cài: Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0

# 2. Tạo SSH key nếu chưa có (chạy trong PowerShell)
ssh-keygen -t ed25519 -f "$env:USERPROFILE\.ssh\id_ed25519"

# 3. Copy public key sang server (hoặc dán thủ công vào ~/.ssh/authorized_keys trên server)
type "$env:USERPROFILE\.ssh\id_ed25519.pub" | ssh eldmp@<IP-SERVER> "cat >> ~/.ssh/authorized_keys"
```

Sau đó thêm vào `C:\Users\<tên-bạn>\.ssh\config` (tạo file mới nếu chưa có, không có phần mở rộng `.txt`):

```
Host eldmp-server
    HostName <IP-CUA-UBUNTU-SERVER>
    User eldmp
    IdentityFile C:\Users\<tên-bạn>\.ssh\id_ed25519
```

VS Code trên Windows tự đọc file config này khi dùng Remote-SSH — không cần cấu hình gì thêm trong extension.

**Phương án thay thế trên Windows — WSL2:** nếu máy Windows đã cài WSL2, có thể chạy toàn bộ workflow SSH/git từ bên trong WSL2 (dùng OpenSSH của Linux, quen thuộc hơn với người đã làm Linux) thay vì PowerShell — VS Code Remote-SSH vẫn hoạt động y hệt khi kết nối từ terminal WSL2. Đây là tuỳ chọn, không bắt buộc.

**Không dùng PuTTY** cho VS Code Remote-SSH — extension này chỉ hỗ trợ OpenSSH-compatible client (`ssh.exe`), PuTTY dùng định dạng key/registry riêng không tương thích trực tiếp (cần plugin chuyển đổi phức tạp hơn, không cần thiết khi Windows đã có OpenSSH tích hợp sẵn).

### 6.3 Kết nối

`Cmd/Ctrl+Shift+P` → **Remote-SSH: Connect to Host** → chọn `eldmp-server` → mở thư mục `~/eldmp`.

Từ đây, bạn code trực tiếp trên filesystem của Ubuntu Server như đang ngồi trên một Linux dev server thật — terminal tích hợp, IntelliSense, debug, tất cả chạy trên server. Quy trình này **giống hệt nhau bất kể máy client là Windows, macOS, hay Linux** — điểm khác biệt duy nhất là cách tạo SSH key/config ở Bước 6.2.

### 6.4 Dev Containers (Bước 4 mục 4.4 đã nói chi tiết)

```bash
code --install-extension ms-vscode-remote.remote-containers
```

Sau khi đã Remote-SSH vào server: `Cmd/Ctrl+Shift+P` → **Dev Containers: Reopen in Container** — VS Code dùng thẳng Docker Engine đang chạy sẵn trên server, không cần cấu hình socket/context gì thêm (khác hẳn Colima/OrbStack).

---

## Bước 7 — Clone Repo & Kết Nối GitHub

```bash
# Trên Ubuntu Server (qua SSH hoặc VS Code Remote-SSH terminal)
# ssh-keygen -t ed25519 -C "eldmp-ubuntu-server" -f ~/.ssh/id_ed25519 -N ""
ssh-keygen -t ed25519 -C "datuan1611@gmail.com"
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
cat ~/.ssh/id_ed25519.pub
# → Thêm public key này vào GitHub: Settings → SSH and GPG keys → New SSH key

gh auth login   # nếu đã cài GitHub CLI, tuỳ chọn
git clone git@github.com:yourusername/eldmp.git ~/eldmp
cd ~/eldmp
```

---

## Bước 8 — Build & Test Trực Tiếp Trên Server

```bash
cd ~/eldmp
mkdir -p build && cd build
cmake ..
cmake --build . -j "$(nproc)"
ctest --output-on-failure
```

---

## Bước 9 — Tái Lập Môi Trường Trên Một Máy Ubuntu Khác (Học Cách "Đóng Gói" Thật Sự)

### 9.1 Hai Tầng Tái Lập Khác Nhau Về Bản Chất

```
Tầng 1 — OS-level (swap, sysctl, Docker Engine — Bước 1-3)
  → PHẢI lặp lại thủ công (hoặc chạy setup-ubuntu-docker.sh) trên MỌI máy
    Ubuntu mới — đây là trạng thái của HỆ ĐIỀU HÀNH, không "đi theo" repo git.

Tầng 2 — Toolchain + Container-level (Bước 4, .devcontainer/Dockerfile)
  → TỰ ĐỘNG tái lập 100% ở bất kỳ đâu có Docker Engine, chỉ cần:
      docker build -f .devcontainer/Dockerfile -t eldmp-toolchain .
    Toàn bộ toolchain được ĐÓNG GÓI NGAY TRONG image — đây chính là lý do
    Docker tồn tại: "build một lần, chạy giống hệt ở mọi nơi".
```

Hiểu đúng: bạn **không cần** "đóng gói toàn bộ máy ảo" để chuyển môi trường sang máy khác — chỉ cần (a) máy mới có Ubuntu + Docker Engine (Tầng 1, lặp lại Bước 1-3), và (b) `git clone` repo rồi `docker build` (Tầng 2, tự động 100% nhờ Dockerfile). Đây là ưu điểm cốt lõi của kiến trúc container so với việc "clone nguyên VM" (nặng, chậm, khó version-control).

### 9.2 Bài Tập Thực Hành — Tự Tay Kiểm Chứng Tính Tái Lập

Cách chắc chắn nhất để hiểu là tự làm trên một máy/VM Ubuntu **thứ hai**:

1. Cài Ubuntu Server 26.04 LTS sạch (không copy gì từ máy cũ)
2. Lặp lại Bước 1-4 **thủ công, gõ tay từng lệnh** (không chạy script lần này — mục đích tự kiểm tra bạn nhớ đúng trình tự không)
3. `git clone` repo ELDMP vào máy mới
4. `docker build -f .devcontainer/Dockerfile -t eldmp-toolchain .` — so sánh thời gian build lần đầu (tải hết layer) và build lại lần hai (Docker cache layer, nhanh hơn hẳn — khái niệm Docker layer caching)
5. Chạy `scripts/helper/verify-env.sh` trên máy mới (Bước 5) — kết quả PASS/FAIL phải giống hệt máy đầu tiên nếu bạn làm đúng

Nếu có bước nào bạn phải tra lại tài liệu mới nhớ ra — đó chính xác là chỗ bạn chưa hiểu sâu, không phải chỗ cần thuộc lòng nhanh hơn.

### 9.3 Khi Nào Nên Dùng Script Tự Động

Sau khi đã tự tay làm đúng ít nhất một lần và hiểu rõ từng bước, `scripts/helper/setup-ubuntu-docker.sh` trở thành công cụ tiết kiệm thời gian hợp lý cho các lần setup sau (máy CI, máy Linux build Yocto riêng ở Sprint 12, v.v.) — **không phải để né việc học ban đầu**, mà để không phải gõ tay 20 dòng lệnh mỗi lần đã hiểu rõ chúng làm gì.

```bash
chmod +x scripts/helper/setup-ubuntu-docker.sh
./scripts/helper/setup-ubuntu-docker.sh
```

---

## Bước 10 — Flash Firmware MCU (Từ Máy Có Cổng USB Vật Lý)

Firmware compile trên Ubuntu Server (hoặc trong container) → copy về máy có cổng USB vật lý kết nối ST-Link để flash:

```bash
# Từ máy client (nơi có cổng USB thật)
scp eldmp@<IP-SERVER>:~/eldmp/build/mcu/firmware.elf ./firmware.elf

# Cài openocd trên máy client đó (ví dụ macOS)
brew install openocd arm-none-eabi-gcc

# STM32F446
openocd -f interface/stlink.cfg -f target/stm32f4x.cfg -c "program firmware.elf verify reset exit"

# STM32H743
openocd -f interface/stlink.cfg -f target/stm32h7x.cfg -c "program firmware.elf verify reset exit"
```

Nếu Ubuntu Server của bạn là máy thật (bare-metal) có sẵn cổng USB, bạn có thể cài `openocd` thẳng trên server và flash trực tiếp — không cần bước copy. Nếu là VM, USB passthrough tuỳ hypervisor (UTM/VMware/...） cần cấu hình riêng và chưa được xác minh ổn định trong tài liệu này — flash từ máy vật lý là phương án chắc chắn hoạt động.

---

## Bước 11 — Cross-Compile & Phân Tích Ứng Dụng Linux (BeagleBone Black)

```bash
arm-linux-gnueabihf-gcc -o app_armhf src/app/main.c
file app_armhf   # xác nhận: ELF 32-bit LSB, ARM

cppcheck --enable=all src/sprint6-kernel-driver/
```

Test chạy thật (không chỉ compile) cho code armhf cần board BeagleBone Black thật hoặc máy Linux riêng có QEMU user-mode.

---

## Bước 12 — Phối Hợp Với Máy Linux Build Yocto/Buildroot Riêng (Sprint 12)

Khi tới Sprint 12, image Yocto/Buildroot đầy đủ được build trên **máy chủ Linux chuyên dụng riêng** — do giới hạn RAM của máy phát triển hiện tại (Yocto/Buildroot khuyến nghị 8GB+ RAM chỉ riêng cho build).

**Quy trình phối hợp:**

1. Code nguồn (recipe Yocto, config Buildroot) vẫn nằm trong repo `eldmp`, viết/chỉnh sửa qua Ubuntu Server này hoặc SSH trực tiếp vào máy Linux riêng — cùng git history.
2. Build thật chạy trên máy Linux riêng: `git clone` cùng repo, chạy Yocto/Buildroot ở đó.
3. Artifact (`.wic`/`.img`) chuyển về để flash SD card — `scp` trực tiếp giữa hai máy.
4. CI self-hosted runner cho Sprint 12 đăng ký trên chính máy Linux riêng đó.

---

## Bước 13 — CI/CD Hai Tầng

### Tầng 1 — GitHub-hosted runner (nhẹ, miễn phí)

```yaml
runs-on: ubuntu-24.04-arm   # Runner arm64 chính chủ GitHub, miễn phí với repo public
```

### Tầng 2a — Self-hosted runner trên Ubuntu Server này (Sprint 6, 13)

```bash
mkdir ~/actions-runner && cd ~/actions-runner
curl -o actions-runner-linux-arm64.tar.gz -L <URL_TỪ_GITHUB>
tar xzf actions-runner-linux-arm64.tar.gz
./config.sh --url https://github.com/yourusername/eldmp --token <TOKEN> --labels ubuntu-server-native
sudo ./svc.sh install
sudo ./svc.sh start
```

```yaml
runs-on: [self-hosted, ubuntu-server-native]
```

### Tầng 2b — Self-hosted runner trên máy Linux build Yocto riêng (Sprint 12)

```yaml
runs-on: [self-hosted, yocto-build-server]
```

> Ghi chú: nếu `eldmp` là repo **public**, mọi tầng CI đều miễn phí không giới hạn.

---

## Quản Lý Docker & Hệ Thống

```bash
sudo systemctl status docker              # trạng thái Docker daemon
sudo systemctl restart docker             # restart (cần khi đổi daemon.json)
docker ps -a                              # container đang chạy/đã dừng
docker system df                          # dung lượng Docker đang chiếm
docker system prune -a                    # dọn image/container/cache không dùng
free -h                                   # RAM + Swap
df -h /                                   # dung lượng đĩa
journalctl -u docker --since "1 hour ago" # log Docker daemon gần đây
```

---

## Troubleshooting

### `docker ps` báo "permission denied"

```bash
groups   # kiểm tra "docker" có trong danh sách group không
newgrp docker   # hoặc đăng nhập lại SSH
```

### Docker daemon không start sau khi sửa `daemon.json`

```bash
sudo python3 -m json.tool /etc/docker/daemon.json   # kiểm tra JSON hợp lệ
sudo journalctl -u docker -n 50 --no-pager           # xem log lỗi cụ thể
```

### RAM/Swap không đủ khi build nhiều container song song

```bash
free -h
# Nếu Swap gần đầy liên tục, giảm số job song song khi build:
cmake --build build -j 2   # thay vì -j $(nproc)
```

### `fs.inotify.max_user_watches` vẫn báo lỗi ENOSPC dù đã sysctl

```bash
cat /proc/sys/fs/inotify/max_user_watches   # xác nhận giá trị đã áp dụng
sudo sysctl -p /etc/sysctl.d/99-eldmp-tuning.conf   # áp dụng lại thủ công
```

### Sprint 12 (Yocto/Buildroot) chạy trên máy này bị OOM

Nhắc lại: sprint này **không** chạy trên máy phát triển chính — luôn thực hiện trên máy Linux riêng theo Bước 12.

---

## Ghi Chú Về Các Công Cụ Trước Đó (Lima/OrbStack/Colima)

| Việc | Lima | OrbStack | Colima | Ubuntu Server Native (hiện tại) |
|---|---|---|---|---|
| Nền tảng | VM wrapper (macOS) | VM wrapper (macOS) | VM wrapper (macOS) | Không có wrapper — Linux thật |
| Docker | Cài thủ công trong VM | Cấp sẵn tầng macOS | Cấp sẵn trong VM | Cài apt chính thức, daemon thật |
| Yêu cầu macOS | Không nghiêm ngặt | macOS mới | **Không hỗ trợ Big Sur (đã xác nhận lỗi thật)** | Không áp dụng — không phụ thuộc macOS |
| Tái sử dụng trên server thật | Không trực tiếp | Không | Không | **Có — đây chính là server thật** |

Đây là điểm dừng chân kiến trúc — không dự kiến đổi công cụ nền tảng thêm lần nữa, vì đã đạt được tiêu chuẩn ngành (Ubuntu Server + Docker Engine chính thức) thay vì một sản phẩm bên thứ ba có thể ngừng hỗ trợ.

---

## Bước Tiếp Theo

1. ✅ Ubuntu Server chạy, Docker Engine cài chính thức, swap + sysctl tối ưu
2. ✅ Repo cloned vào `~/eldmp`, build & test pass, verify-env.sh PASS toàn bộ
3. ✅ Container `eldmp-toolchain` build được, static/dynamic analysis chạy được
4. ✅ VS Code Remote-SSH kết nối được từ máy client
5. Commit: `git add . && git commit -m "Sprint 0: Ubuntu Server Native + Docker Engine chuẩn công nghiệp"`
6. Tag: `git tag v0.0.1`
7. 🚀 Sẵn sàng Sprint 1 — Logger Module

---

**Last Updated:** Sprint 0 (Milestone 0.1)  
**Môi trường:** Ubuntu Server 26.04 LTS ARM64 Native + Docker Engine (apt chính thức)  
**Scope:** Yocto/Buildroot build vẫn tách sang máy Linux chuyên dụng riêng  
**Status:** ✅ Setup guide sẵn sàng
