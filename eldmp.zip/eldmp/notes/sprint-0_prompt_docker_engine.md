# CHỈ THỊ THIẾT LẬP MÔ TRƯỜNG DỰ ÁN: CHUẨN HÓA UBUNTU SERVER & DOCKER ENGINE

Bạn hãy thực hiện thiết lập/chuyển đổi TOÀN BỘ cấu hình, script và tài liệu của dự án `eldmp-portfolio` sang quy chuẩn **Hệ điều hành Ubuntu Server (Linux Native) và Docker Engine**.

Mục tiêu cốt lõi: Coi môi trường Ubuntu Server hiện tại (dù là máy thật Bare-metal, máy ảo VM hay Cloud Instance) là hạ tầng Linux tiêu chuẩn. Tập trung tối ưu hóa OS, cài đặt Docker Engine chính thức và thiết lập môi trường phát triển Embedded chuyên nghiệp, đảm bảo tính độc lập tuyệt đối và có thể tái sử dụng trên bất kỳ hệ thống Linux nào trong công nghiệp.

---

## I. BỐI CẢNH & ĐIỀU CHỈNH PHẠM VI (SCOPE UPDATE)

1. **QUY CHUẨN HẠ TẦNG UBUNTU SERVER:**
   * **Bỏ qua các bước tạo/khởi tạo máy ảo:** Giả định hệ điều hành Ubuntu Server (22.04 LTS / 24.04 LTS / 26.04 LTS ARM64 hoặc x86_64) đã được cài đặt thành công.
   * **Bỏ tác vụ build Yocto/Buildroot Heavy Local:** Tách biệt phần build OS Yocto/Buildroot nặng ra máy chủ build riêng.
   * **Tối ưu hóa Hệ điều hành (OS Hardening & Optimization):** Tập trung vào việc cấu hình Swap File (4GB), phân bổ tài nguyên bộ nhớ, tối ưu Kernel parameters và thiết lập Docker Engine chuẩn để chạy mượt mà ngay cả trên các cấu hình máy giới hạn RAM (từ 4GB - 8GB RAM).

2. **CÁC TÁC VỤ BẮT BUỘC GIỮ NGUYÊN & ĐẢM BẢO:**
   * **Target Hardware:** Biên dịch thành công source code Bare-metal & FreeRTOS cho STM32F446 và STM32H743.
   * **Static Code Analysis:** Hệ thống kiểm tra chuẩn MISRA C (Cppcheck, Clang-Tidy).
   * **Dynamic Analysis & Memory Debug:** Tích hợp Clang Sanitizers (ASan, MSan, UBSan, LeakSanitizer, Backtrace).
   * **Testing Framework:** Bộ chạy test UT/IT/ST (Unity/CMock, GoogleTest hoặc CTest).
   * **Cross-Compile & Analysis cho Embedded Linux:** Kiểm tra, phân tích tĩnh/động cho ứng dụng Linux App (BeagleBone Black) thông qua Toolchain/Container.
   * **IDE & Workflow:** Tích hợp VS Code Remote-SSH / Dev Containers và CI/CD GitHub Workflows.

---

## II. RÀNG BUỘC ĐẦU RA (STRICT OUTPUT CONSTRAINTS)

* **BẢO ĐẢM TÍNH NGUYÊN VẸN 100%:** Giữ lại toàn bộ cấu trúc, chi tiết kỹ thuật, bảng biểu và nội dung chuyên môn Embedded đã có. CHỈ CHỈNH SỬA các nội dung hướng dẫn thành quy chuẩn thao tác trực tiếp trên Ubuntu Server + Docker Engine. Tuyệt đối KHÔNG cắt bớt, thu gọn hay lược bỏ bất kỳ phần nào.
* **XUẤT FULL CODE / TEXT:** Tuyệt đối KHÔNG dùng các ký hiệu ngắt đoạn/viết tắt như `...`, `// giữ nguyên code cũ`, `<!-- rest of code -->`.
* **ĐẶT FILE ĐÚNG VỊ TRÍ CHUẨN:** Đảm bảo toàn bộ cấu trúc thư mục sạch sẽ, đúng theo chuẩn repo structure, tuyệt đối KHÔNG đẩy các file cấu hình hay Dockerfile ra thư mục root.

---

## III. QUY HOẠCH ĐƯỜNG DẪN CÁC FILE (DIRECTORY ALIGNMENT)

Hãy xuất nội dung đầy đủ cho các file theo đúng sơ đồ thư mục dưới đây:

### 1. Thư mục Root:
* `README.md`: Tổng quan dự án, cập nhật Architecture diagram chuẩn hóa (Client Workstation -> VS Code Remote-SSH -> Ubuntu Server -> Docker Engine -> Dev Containers).
* `SETUP.md`: Cập nhật toàn bộ 15+ mục hướng dẫn chi tiết từng bước quy chuẩn trên Ubuntu Server:
  1. Tối ưu hệ thống (Tạo Swap 4GB, cấu hình sysctl).
  2. Cài đặt Docker Engine chính thức từ Docker APT Repository + Docker Compose Plugin.
  3. Cấu hình Docker User Permissions & Daemon JSON.
  4. Hướng dẫn kết nối VS Code Remote-SSH từ máy Client (Windows/macOS/Linux).

### 2. Thư mục `.devcontainer/`:
* `.devcontainer/Dockerfile`: Môi trường Dockerfile đầy đủ toolchain (ARM GCC `arm-none-eabi-gcc`, `arm-linux-gnueabihf-gcc`, Clang Tools, Sanitizers, Test Frameworks).
* `.devcontainer/devcontainer.json`: Cấu hình VS Code Dev Containers kết nối trực tiếp thông qua Docker Socket trên Ubuntu Server.

### 3. Thư mục `scripts/`:
* `scripts/setup-ubuntu-docker.sh`: Script "One-click" tự động hóa toàn bộ việc tối ưu Ubuntu (Swap, Swappiness), cài đặt Docker Engine chính thức, thêm user vào nhóm docker, và kích hoạt systemd service.
* `scripts/verify-env.sh`: Script tự động chạy Verification Suite kiểm tra toàn bộ môi trường (Docker Daemon, Toolchains, Sanitizers, Cross-Compilers).

### 4. Thư mục `tests/verification/`:
* `tests/verification/test_asan.c`: Code C cố tình dính lỗi Memory Leak/Use-After-Free để test Clang ASan.
* `tests/verification/test_stm32.c`: Code C mẫu cho STM32 Bare-metal để test `arm-none-eabi-gcc`.

### 5. Thư mục `docs/`:
* `docs/ARCHITECTURE.md` & `docs/architecture/ARCHITECTURE.md`: Cập nhật mô tả Dev Environment quy chuẩn trên Ubuntu Server Linux Native, giải trình ưu điểm của việc loại bỏ các lớp giả lập (Virtualization Wrapper) và tách tác vụ Yocto Build out-of-host.
* Rà soát đồng bộ tất cả các file markdown khác trong `docs/`, `notes/` để thay toàn bộ tham chiếu môi trường cũ thành `Ubuntu Server Native` & `Docker Engine`.

---

## IV. BỘ KỊCH BẢN VERIFICATION SUITE TỰ ĐỘNG

Hãy viết một script kiểm tra tên là `scripts/verify-env.sh` và các file test data tương ứng trong `tests/verification/`. Script này sẽ kiểm tra theo 4 cấp độ:

1. **Level 1 - Ubuntu OS & Docker Health Check:** Kiểm tra trạng thái Docker Service (`systemctl status docker`), dung lượng RAM/CPU/Swap khả dụng, và quyền truy cập Docker socket không cần `sudo`.
2. **Level 2 - Toolchain Availability:** Kiểm tra phiên bản của `arm-none-eabi-gcc`, `arm-linux-gnueabihf-gcc`, `clang`, `cppcheck`, `clang-tidy`, `cmake`, và `ninja` bên trong Container/Host.
3. **Level 3 - STM32 & Embedded Linux Compilation Test:** Thử biên dịch file `tests/verification/test_stm32.c` bằng ARM GCC Toolchain ra file `.elf`/`.hex` thành công.
4. **Level 4 - Dynamic Sanitizer Test:** Biên dịch `tests/verification/test_asan.c` bằng `clang -fsanitize=address` và thực thi để đảm bảo ASan bắt đúng lỗi memory leak/out-of-bounds.

---

## V. KỊCH BẢN ĐÓNG GÓI TỰ ĐỘNG (PROJECT PACKAGING SCRIPT)

Sau khi cung cấp đầy đủ nội dung chi tiết của từng file bên trên, hãy viết một Bash Script độc lập tên là `generate_project.sh`. Script này khi chạy trên Ubuntu Server sẽ tự động:

1. Tạo toàn bộ cây thư mục chuẩn cho dự án `eldmp-portfolio` (bao gồm cả `tests/verification/`).
2. Ghi chính xác nội dung toàn bộ các file đã cập nhật và kịch bản test vào đúng đường dẫn chỉ định.
3. Tự động nén toàn bộ thư mục dự án thành file `eldmp-portfolio-ubuntu-standard.zip`.

**YÊU CẦU CỦA QUY TRÌNH:** Không hỏi lại, hãy xuất ra phiên bản hoàn chỉnh và đầy đủ nhất ngay lập tức!