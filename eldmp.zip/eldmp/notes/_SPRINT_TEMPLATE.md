# Sprint N — [Sprint Name]

## Problem (Vấn Đề)
What problem is this sprint solving?

## Expected Outcome (Kỳ Vọng)
What should be achieved by end of sprint?

## What Actually Happened (Thực Tế)
What was the actual experience? Any surprises?

## Root Cause / How to Fix (Giải Pháp)
Why did things happen this way? How to improve?

## Lessons Learned (Bài Học)
Key takeaways to apply in future sprints.

## References Used (Tài Liệu Tham Khảo)
- Books/chapters used
- Source code reviewed
- Datasheets/docs
- Stack Overflow posts

## Time Spent
- Planned: X hours
- Actual: Y hours
- Reason for variance: ...

## Commits
List main commits for this sprint
