# src/common — Thư Viện Dùng Chung (C)

Thư viện tĩnh (`libcommon.a`) chứa code dùng chung giữa `src/app` và các module tương lai — hiện gồm CLI parser và cơ chế versioning từ git tag.

**Ngôn ngữ:** C (xem ghi chú chiến lược ngôn ngữ ở [`../app/README.md`](../app/README.md) — sẽ chuyển sang C++ khi dự án bước vào phần Linux, Sprint 6+).

## Nội Dung

| File | Vai trò |
|---|---|
| `include/cli.h` / `src/cli.c` | Parse tham số dòng lệnh (`--help`, `--version`, lệnh không hợp lệ) |
| `include/version.h.in` / `src/version.c` | Sinh version string từ `git describe --tags --always` lúc cấu hình CMake |

## Cơ Chế Versioning — Cách Hoạt Động

`CMakeLists.txt` chạy `execute_process(COMMAND git describe --tags --always)` lúc **configure** (không phải lúc build) để lấy tag/commit hash hiện tại, rồi `configure_file()` sinh ra `version.h` thật (điền `@GIT_TAG@`) vào thư mục build — `version.h.in` chỉ là **template**, không tự include được, không commit `version.h` sinh ra vào git (đã nằm trong `build/`, đã gitignore).

**Xử lý khi không có `.git`:** nếu build từ cây do [`scripts/helper/generate_project.sh`](../../scripts/helper/generate_project.sh) sinh ra (cây đó **không** copy `.git` theo thiết kế), `git describe` sẽ thất bại — `CMakeLists.txt` đã bắt lỗi này qua `RESULT_VARIABLE` và fallback về chuỗi `"unknown"` thay vì để trống hoặc in lỗi ra màn hình. Đã kiểm chứng cả hai trường hợp (có `.git` → in đúng commit hash; không `.git` → in "unknown") đều build sạch, không cảnh báo với `-Wall -Wextra`.

## Build

Thư viện này build cùng lúc với `src/app` từ CMake gốc — không có bước build riêng:

```bash
mkdir -p build && cd build
cmake .. && cmake --build .
./src/app/eldmp --version
```
