#include "version.h"

const char* get_version() {
    return APP_VERSION;
}