#include <stdio.h>
#include <string.h>
#include "cli.h"
#include "version.h"

void print_usage(const char* prog_name) {
    printf("Usage: %s [--help|-h] [--version|-v]\n", prog_name);
}

void print_version() {
    printf("eldmp version %s\n", get_version());
}

int cli_run(int argc, char *argv[]) {
    if (argc < 2) {
        print_usage(argv[0]);
        return 0;
    }

    if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
        print_usage(argv[0]);
        return 0;
    }

    if (strcmp(argv[1], "--version") == 0 || strcmp(argv[1], "-v") == 0) {
        print_version();
        return 0;
    }

    printf("Unknown command: %s\n", argv[1]);
    print_usage(argv[0]);
    return 1;
}