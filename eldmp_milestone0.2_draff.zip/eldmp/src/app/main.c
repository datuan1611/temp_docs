#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "cli.h"

static void init_env(void)
{
    // TODO: Khởi tạo môi trường, biến toàn cục, logging, v.v.
}

int main(int argc, char *argv[])
{
    init_env();
    return cli_run(argc, argv);
}