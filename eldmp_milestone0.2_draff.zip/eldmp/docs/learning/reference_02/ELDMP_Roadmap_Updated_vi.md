# ELDMP — Embedded Linux Device Management Platform
## Lộ Trình Phát Triển Hoàn Chỉnh (MCU-First Track)

---

## Tổng Quan Core Track — Sprints

### Phase 0: Nền Tảng
- **Milestone 0.1** — Cấu Hình Môi Trường (2 tuần)
- **Milestone 0.2** — Ôn Tập Embedded C (2-3 tuần)

### Phase 1: MCU Cơ Bản (Bare-Metal → RTOS → GUI)
- **Sprint 1** — Logger Module (2 tuần)
- **Sprint 2** — Configuration Manager (2 tuần)
- **Sprint 3** — Bare-Metal MCU (4-5 tuần)
- **Sprint 4** — FreeRTOS Integration (3-4 tuần)
- **Sprint 5** — Embedded GUI (LVGL) (2-3 tuần)
- **Release V0.5** — MCU Firmware Hoàn Chỉnh

### Phase 2: Linux Kernel & Tích Hợp
- **Sprint 6** — Kernel & Device Tree (8-10 tuần)
- **Sprint 7** — Device Manager (2-3 tuần)
- **Sprint 8** — Health Monitor (2-3 tuần)
- **Sprint 9** — D-Bus IPC Layer (3-4 tuần)
- **Sprint 10** — systemd Integration (2 tuần)
- **Sprint 11** — Watchdog (2-3 tuần)
- **Release V1.0** — Platform Linux Hoàn Chỉnh

### Phase 3: Build System & Triển Khai
- **Sprint 12** — Buildroot/Yocto Build (4-5 tuần)
- **Release V1.5** — Custom Linux Image

### Phase 4: Tích Hợp & Tính Năng Nâng Cao
- **Sprint 13** — Custom Protocol & CAN (4-5 tuần)
- **Sprint 14** — Networking & MQTT (3-4 tuần)
- **Sprint 15** — OTA Update System (3-4 tuần)
- **Release V2.0** — Tích Hợp Hoàn Chỉnh

### Phase 5: An Toàn & Hoàn Thiện
- **Sprint 16** — Security & TLS (3-4 tuần)
- **Release V3.5** — Sản Xuất Sẵn Sàng

---

## Mô Tả Chi Tiết Các Sprint

### Milestone 0.1 — Cấu Hình Môi Trường
- **Mục tiêu:** Thiết lập môi trường phát triển và khung repository.
- **Thời gian:** ~2 tuần | **Điều kiện tiên quyết:** Không có
- **Học tập:** Git, Bash, CMake, Markdown
- **Xây dựng:** Khung repository, hướng dẫn style, README, LICENSE, CI cơ bản
- **Definition of Done (cụ thể):**
  - [ ] Repository build thành công
  - [ ] README giải thích cách build và chạy
  - [ ] CI pipeline chạy thành công

---

### Milestone 0.2 — Ôn Tập Embedded C Cơ Bản

**Mục tiêu:** Củng cố kiến thức Embedded C trước khi viết mã sản xuất.

**Thời gian:** ~2-3 tuần | **Điều kiện tiên quyết:** Sprint 0

**Tại sao sprint này tồn tại:**
- Cầu nối giữa kiến thức C chung và mẫu embedded cụ thể
- Xây dựng tự tin với volatile, const, pointers, bitwise operations
- Tạo thư viện tiện ích tái sử dụng (circular buffer, bit macros, defensive checks)
- Giảm bugs trong các sprint sản xuất sau (register access, interrupt handlers)

**Tài Liệu Học Tập:**
- *The C Programming Language* (Kernighan & Ritchie) — pointers, bitwise ops, volatile
- *Computer Organization and Design: ARM Edition* (Patterson & Hennessy) — ARM ISA, registers
- Best practices Embedded C (compiler warnings, undefined behavior, memory safety)

**Đọc Tài Liệu:**
- Linux kernel source: `include/linux/bitops.h` — production bitwise macro patterns
- FreeRTOS source: `list.c` — data structure implementation thực tế
- LLVM/Clang documentation: pointer aliasing rules

**Xây Dựng (nằm trong `eldmp-learning`):**
- Circular buffer (queue) implementation với unit tests
- Bit manipulation macros (SET_BIT, CLEAR_BIT, READ_BIT)
- Safe pointer patterns và NULL checks
- Practice exercises với compilation và execution
- Memory layout demonstrations (stack, heap, static, const)

**Ví Dụ Code:**
```c
// Deliverables trong sprint này:
- src/common/include/macros.h           // Bit macros, compiler directives
- src/common/include/types.h            // Common types, error codes
- src/common/include/circular_buffer.h  // Reusable FIFO queue
- src/common/src/circular_buffer.c      // Implementation
- tests/learning/test_circular_buffer.c // Comprehensive tests
```

**Definition of Done (cụ thể):**
- [ ] Tất cả practice exercises compile với `-Wall -Wextra` zero warnings
- [ ] Circular buffer pass tất cả unit tests (full, empty, wraparound cases)
- [ ] Bit macros verified against real register access patterns
- [ ] Memory layout demonstrated với actual measurements (stack growth, heap)
- [ ] Technical note (500-800 từ) covers: why volatile matters, UB pitfalls, defensive coding
- [ ] Có thể giải thích tại sao mỗi pattern tồn tại và khi nào dùng/không dùng

**Deliverables:**
- Reusable `circular_buffer` library (dùng trong Sprint 3's UART ISR buffer)
- `macros.h` với bit manipulation utilities (dùng ở mỗi sprint)
- `types.h` với common types và error codes
- Comprehensive unit tests cho tất cả utilities
- Written learning notes về Embedded C pitfalls và solutions

**Tại Sao Điều Này Quan Trọng Cho Interview:**
- Chứng minh hiểu biết embedded fundamentals *trước* khi dive vào frameworks
- Circular buffer là câu hỏi thực tế interviewers hỏi
- Thể hiện defensive programming mindset (critical cho mission-critical systems)
- Bit manipulation patterns dùng ở mỗi driver/firmware trong roadmap này

---

### Sprint 1 — Logger
- **Mục tiêu:** Thư viện logging tái sử dụng cho tất cả components.
- **Thời gian:** ~2 tuần | **Điều kiện tiên quyết:** Sprint Learning
- **Học tập:** TLPI File I/O; OSTEP File Systems
- **Đọc Tài Liệu:** spdlog hoặc Boost.Log source
- **Xây dựng:** Logger library, log levels, file rotation, unit tests
- **Definition of Done (cụ thể):**
  - [ ] Standalone library khác modules có thể link
  - [ ] File rotation verified với tests

---

### Sprint 2 — Configuration Manager
- **Mục tiêu:** Quản lý config tập trung, có thể reload.
- **Thời gian:** ~2 tuần | **Điều kiện tiên quyết:** Sprint 1
- **Học tập:** JSON parsing và schema design
- **Đọc Tài Liệu:** nlohmann/json hoặc tương tự
- **Xây dựng:** Config Manager, `config.json`, live reload
- **Definition of Done (cụ thể):**
  - [ ] Không có config hard-coded trong code
  - [ ] Invalid config bị reject với clear error

---

### Sprint 3 — Bare-Metal MCU
- **Mục tiêu:** Bring up MCU từ bare-metal — registers, interrupts, MMIO.
- **Thời gian:** ~4–5 tuần | **Điều kiện tiên quyết:** Sprint 2
- **Học tập:** ARM Cortex-M4 exception model; STM32H743 peripherals
- **Đọc Tài Liệu:** STM32 reference manual; *Mastering STM32*
- **Lab:** blink LED via direct register writes (throwaway lab)
- **Xây dựng:** polling-based sensor read, interrupt-driven GPIO, basic DMA
- **Definition of Done (cụ thể):**
  - [ ] Sensor read via polling ổn định
  - [ ] Interrupt-driven GPIO input verified (not polling)
  - [ ] Ít nhất 1 peripheral via direct register access (documented)

---

### Sprint 4 — FreeRTOS Integration
- **Mục tiêu:** Restructure bare-metal thành FreeRTOS application.
- **Thời gian:** ~3–4 tuần | **Điều kiện tiên quyết:** Sprint 3
- **Học tập:** FreeRTOS tasks, queues, semaphores/mutexes, timing
- **Đọc Tài Liệu:** FreeRTOS kernel source cho scheduling và queue implementation
- **Lab:** producer/consumer với FreeRTOS queue (throwaway)
- **Xây dựng:** sensor + motor control loop như FreeRTOS tasks với queue synchronization
- **Definition of Done (cụ thể):**
  - [ ] Control loop chạy ở deterministic, measured rate
  - [ ] Tasks synchronized via FreeRTOS primitives (not globals)

---

### Sprint 5 — Embedded GUI (LVGL)
- **Mục tiêu:** Thêm live embedded GUI rendering sensor data trên RTOS.
- **Thời gian:** ~2–3 tuần | **Điều kiện tiên quyết:** Sprint 4
- **Học tập:** LVGL widgets, event loop, display/input driver interface
- **Đọc Tài Liệu:** LVGL's display/input driver porting guide
- **Lab:** run built-in LVGL demo widget (throwaway)
- **Xây dựng:** sensor data rendered live trên LVGL UI, isolated FreeRTOS task
- **Definition of Done (cụ thể):**
  - [ ] LVGL UI updates live mà không tearing hoặc frame drops
  - [ ] UI task không block control loop's timing (measured)

**→ Release V0.5** — First demoable MCU capability (FreeRTOS + LVGL)

---

### Sprint 6 — Kernel & Device Tree
- **Mục tiêu:** Chuyển vào Linux kernel-space work thực tế.
- **Thời gian:** ~8–10 tuần | **Điều kiện tiên quyết:** V0.5
- **Học tập:** Linux Kernel Labs — boot, character drivers, interrupts, Device Model
- **Đọc Tài Liệu:** mainline kernel `drivers/char/` example; BeagleBone Black Device Tree
- **Lab:** 2-3 Linux Kernel Labs exercises (throwaway)
- **Xây dựng:** custom character device driver, GPIO driver, Device Tree overlay
- **Definition of Done (cụ thể):**
  - [ ] Driver loads via `insmod`, visible in `dmesg` mà không errors
  - [ ] Device Tree overlay binds driver tới hardware
  - [ ] Interrupt-driven GPIO verified (not polling)

### Sprint 7 — Device Manager
- **Mục tiêu:** Expose device identity và system information.
- **Thời gian:** ~2–3 tuần | **Điều kiện tiên quyết:** Sprint 6
- **Học tập:** `/proc` và `/sys` filesystem structure
- **Xây dựng:** `eldmp info` tool — CPU, RAM, kernel version
- **Definition of Done (cụ thể):**
  - [ ] Output matches actual system state (verified against `uname`/`free`/`lscpu`)

### Sprint 8 — Health Monitor
- **Mục tiêu:** Continuous system health monitoring.
- **Thời gian:** ~2–3 tuần | **Điều kiện tiên quyết:** Sprint 7
- **Học tập:** watchdog mechanisms, systemd state
- **Xây dựng:** Health monitor service, threshold alerts
- **Definition of Done (cụ thể):**
  - [ ] Detects CPU/memory/disk thresholds correctly

### Sprint 9 — D-Bus IPC Layer
- **Mục tiêu:** Inter-process communication via D-Bus.
- **Thời gian:** ~3–4 tuần | **Điều kiện tiên quyết:** Sprint 8
- **Học tập:** D-Bus protocol, service activation
- **Xây dựng:** Device Manager và Health Monitor communicate via D-Bus
- **Definition of Done (cụ thể):**
  - [ ] IPC messages verified với `dbus-monitor`
  - [ ] Service activation works correctly

### Sprint 10 — systemd Integration
- **Mục tiêu:** Chạy mọi service dưới dạng systemd unit được quản lý.
- **Thời gian:** ~2 tuần | **Điều kiện tiên quyết:** Sprint 9
- **Học tập:** systemd unit file, `journalctl`, `systemctl`
- **Xây dựng:** `logger.service`, `device.service`, `monitor.service`
- **Definition of Done (cụ thể):**
  - [ ] Mọi service tự khởi động khi boot
  - [ ] Service tự restart khi crash ở cấp systemd

### Sprint 11 — Watchdog
- **Mục tiêu:** Giám sát ở cấp ứng dụng, phía trên systemd.
- **Thời gian:** ~2–3 tuần | **Điều kiện tiên quyết:** Sprint 10
- **Xây dựng:** Cơ chế heartbeat, tự động restart service không phản hồi, ghi log lỗi
- **Definition of Done (cụ thể):**
  - [ ] Một service bị treo có chủ đích được phát hiện và restart trong khoảng thời gian đã định

**→ Release V1.0** — Full Linux platform (kernel driver + services)

---

### Sprint 12 — Buildroot/Yocto Build System
- **Mục tiêu:** Custom embedded Linux image.
- **Thời gian:** ~4–5 tuần | **Điều kiện tiên quyết:** Sprint 11
- **Học tập:** Buildroot hoặc Yocto layer creation
- **Xây dựng:** Custom Linux image cho BeagleBone Black
- **Definition of Done (cụ thể):**
  - [ ] Image boots successfully, tất cả services start

**→ Release V1.5** — Custom Linux image

---

### Sprint 13 — Custom Protocol & CAN
- **Mục tiêu:** Custom binary protocol cho MCU↔Linux communication.
- **Thời gian:** ~4–5 tuần | **Điều kiện tiên quyết:** V1.5
- **Học tập:** binary protocol design, CAN bus, error detection (CRC)
- **Xây dựng:** Protocol definition, Linux↔MCU communication, fault injection tests
- **Definition of Done (cụ thể):**
  - [ ] Protocol survives deliberate corruption (bad CAN frames, timeouts)

### Sprint 14 — Networking & MQTT
- **Mục tiêu:** Cloud connectivity via MQTT.
- **Thời gian:** ~3–4 tuần | **Điều kiện tiên quyết:** Sprint 13
- **Học tập:** MQTT protocol, TLS in embedded contexts
- **Xây dựng:** MQTT client publishing sensor data
- **Definition of Done (cụ thể):**
  - [ ] Publishes tới MQTT broker, messages persist correctly

### Sprint 15 — OTA Update System
- **Mục tiêu:** Over-the-air firmware và system updates.
- **Thời gian:** ~3–4 tuần | **Điều kiện tiên quyết:** Sprint 14
- **Học tập:** signed updates, rollback mechanisms
- **Xây dựng:** OTA client, signed update validation, rollback on failure
- **Definition of Done (cụ thể):**
  - [ ] Update succeeds và fails safely (rollback works)

**→ Release V2.0** — Full integration (protocol + networking + OTA)

---

### Sprint 16 — Security & TLS
- **Mục tiêu:** Encrypt và secure tất cả communications.
- **Thời gian:** ~3–4 tuần | **Điều kiện tiên quyết:** Sprint 15
- **Học tập:** TLS/SSL, key management, signed firmware
- **Xây dựng:** TLS cho tất cả network communication, signed firmware validation
- **Definition of Done (cụ thể):**
  - [ ] TLS handshake verified với `openssl s_client`
  - [ ] Firmware signatures validated on boot

**→ Release V3.5** — Production-ready platform

---

## Bảng Thời Gian Tóm Tắt

| Phase | Sprints | Thời Gian | Output |
|-------|---------|-----------|--------|
| Nền Tảng | 0, Learning, 1-2 | ~8 tuần | Environment + C fundamentals + utilities |
| MCU | 3-5 | ~9-12 tuần | V0.5: FreeRTOS + LVGL |
| Linux cơ bản | 6-11 | ~20-25 tuần | V1.0: Kernel + services |
| Build system | 12 | ~4-5 tuần | V1.5: Custom image |
| Tích hợp | 13-15 | ~10-13 tuần | V2.0: Full platform |
| An toàn | 16 | ~3-4 tuần | V3.5: Production-ready |
| **TỔNG CỘNG** | **0-16 + Learning** | **~16-19 tháng** (part-time) | Hệ thống chất lượng portfolio |

---

## Tài Liệu Tham Khảo Cập Nhật

### Nền Tảng (Sprint 0 & Learning)
- *The C Programming Language* — Kernighan & Ritchie
- Embedded C best practices documentation
- Linux kernel bitops và data structure examples

### MCU Track (Sprints 1-5)
- *Mastering STM32* — Carmine Noviello
- *Mastering the FreeRTOS Real Time Kernel* — Richard Barry
- LVGL documentation và examples

### Linux Track (Sprints 6-12)
- Linux Kernel Labs — hands-on exercises
- *Linux Device Drivers* (3rd ed.) — Corbet et al.
- Buildroot/Yocto documentation

### Tích hợp (Sprints 13-16)
- D-Bus documentation
- MQTT protocol specification
- OpenSSL/TLS documentation

---

## Cấu Trúc Portfolio

Roadmap này **không phải là một framework**. Đó là **một lộ trình học tập được chứng minh qua artifacts**:

```
eldmp-portfolio/
├── README.md                      # Overview + results achieved
├── docs/learning/                 # Tất cả tài liệu học tập tổ chức theo sprint
├── src/
│   ├── learning/                  # Sprint Learning deliverables (C foundations)
│   ├── sprint1-logger/            # Sprint 1: Logger module
│   ├── sprint2-config/            # Sprint 2: Config manager
│   ├── sprint3-bare-metal/        # Sprint 3: MCU firmware
│   └── ... (tổ chức theo sprint)
├── tests/                         # Comprehensive test suite
├── notes/                         # Sprint learning journals
└── releases/                      # Tagged versions (V0.5, V1.0, V1.5, V2.0, V3.5)
```

**Mỗi artifact chứng minh:**
- ✅ Kỹ năng kỹ thuật cụ thể (kernel drivers, RTOS, embedded GUI, etc.)
- ✅ Khả năng giải quyết vấn đề (cách bugs được debug và fix)
- ✅ Giao tiếp (technical notes giải thích những gì đã học)
- ✅ Sâu sắc (real production patterns, không phải tutorials)

---

## Interview Talking Points

Sau mỗi major release (V0.5, V1.0, V1.5, V2.0, V3.5), bạn có thể thảo luận:

- **V0.5:** "Tôi xây dựng một real-time firmware stack với FreeRTOS và LVGL GUI chạy trên STM32, chứng minh interrupt handling, task synchronization, và GUI rendering dưới deterministic timing constraints."
- **V1.0:** "Tôi viết một Linux kernel driver và user-space services communicate via D-Bus, implement IPC patterns được dùng trong production embedded Linux systems."
- **V1.5:** "Tôi tạo một custom Yocto layer và build một complete embedded Linux image, chứng minh build system knowledge và board bring-up."
- **V2.0:** "Tôi thiết kế và implement một custom binary protocol với CRC error detection, MQTT networking, và OTA update system — full end-to-end platform integration."
- **V3.5:** "Tôi bảo mật toàn bộ platform với TLS encryption và signed firmware validation, thể hiện security-conscious embedded systems design."

---

## Những Gì Đã Thay Đổi Từ Roadmap Gốc

1. ✅ **Sprint Learning được thêm vào** giữa Sprint 0 và Sprint 1
   - Tập trung vào Embedded C fundamentals
   - Tạo utilities tái sử dụng (circular buffer, bit macros, defensive patterns)
   - Giảm bugs trong mã sản xuất
   - Chuẩn bị tốt hơn cho MCU work

2. ✅ **Cấu trúc được thay đổi hướng tới portfolio**
   - Không phải là "framework để build trên"
   - Là "một hành trình học với concrete artifacts"
   - Nhấn mạnh vào những gì đã học, không phải những gì đã shipped

3. ✅ **Mapping rõ ràng của kiến thức tới sprints**
   - Mỗi sprint xây dựng dựa trên học tập trước đó
   - Interview talking points rõ ràng
   - Cấu trúc portfolio chuyên nghiệp và dễ hiểu

---

**Phiên bản:** Updated với Sprint Learning  
**Hiệu lực:** [Ngày]  
**Review tiếp theo:** Sau khi Sprint Learning hoàn thành
