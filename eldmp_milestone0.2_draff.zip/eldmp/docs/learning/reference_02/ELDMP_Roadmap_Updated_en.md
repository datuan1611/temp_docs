# ELDMP — Embedded Linux Device Management Platform
## Complete Development Roadmap (MCU-First Track)

---

## Core Track — Sprints Overview

### Phase 0: Foundation
- **Milestone 0.1** — Environment Setup (2 weeks)
- **Milestone 0.2** — Embedded C Fundamentals Review (2-3 weeks)

### Phase 1: MCU Fundamentals (Bare-Metal → RTOS → GUI)
- **Sprint 1** — Logger Module (2 weeks)
- **Sprint 2** — Configuration Manager (2 weeks)
- **Sprint 3** — Bare-Metal MCU (4-5 weeks)
- **Sprint 4** — FreeRTOS Integration (3-4 weeks)
- **Sprint 5** — Embedded GUI (LVGL) (2-3 weeks)
- **Release V0.5** — MCU Firmware Complete

### Phase 2: Linux Kernel & Integration
- **Sprint 6** — Kernel & Device Tree (8-10 weeks)
- **Sprint 7** — Device Manager (2-3 weeks)
- **Sprint 8** — Health Monitor (2-3 weeks)
- **Sprint 9** — D-Bus IPC Layer (3-4 weeks)
- **Sprint 10** — systemd Integration (2 weeks)
- **Sprint 11** — Watchdog (2-3 weeks)
- **Release V1.0** — Full Linux Platform

### Phase 3: Build System & Deployment
- **Sprint 12** — Buildroot/Yocto Build (4-5 weeks)
- **Release V1.5** — Custom Linux Image

### Phase 4: Integration & Advanced Features
- **Sprint 13** — Custom Protocol & CAN (4-5 weeks)
- **Sprint 14** — Networking & MQTT (3-4 weeks)
- **Sprint 15** — OTA Update System (3-4 weeks)
- **Release V2.0** — Full Integration

### Phase 5: Security & Polish
- **Sprint 16** — Security & TLS (3-4 weeks)
- **Release V3.5** — Production Ready

---

## Detailed Sprint Descriptions

### Milestone 0.1 — Environment Setup
- **Goal:** reproducible dev environment and repository skeleton.
- **Duration:** ~2 weeks | **Prerequisites:** none
- **Study:** Git, Bash, CMake, Markdown
- **Build:** repository skeleton, coding style guide, initial README, LICENSE, minimal CI workflow
- **Definition of Done (specific):**
  - [ ] Repository builds successfully
  - [ ] README explains how to build and run
  - [ ] CI pipeline passes

---

### Milestone 0.2 — Embedded C Fundamentals Review

**Goal:** Consolidate Embedded C knowledge before production coding.

**Duration:** ~2-3 weeks | **Prerequisites:** Sprint 0

**Why this sprint exists:** 
- Bridges gap between generic C knowledge and embedded-specific patterns
- Builds confidence with volatile, const, pointers, bitwise operations
- Creates reusable utilities library (circular buffer, bit macros, defensive checks)
- Reduces bugs in later production sprints (register access, interrupt handlers)

**Study Materials:**
- *The C Programming Language* (Kernighan & Ritchie) — pointers, bitwise ops, volatile
- *Computer Organization and Design: ARM Edition* (Patterson & Hennessy) — ARM ISA, registers
- Embedded C best practices (compiler warnings, undefined behavior, memory safety)

**Reading:**
- Linux kernel source: `include/linux/bitops.h` — production bitwise macro patterns
- FreeRTOS source: `list.c` — real-world data structure implementation
- LLVM/Clang documentation: pointer aliasing and strict aliasing rules

**Build (ships in `eldmp-learning`):**
- Circular buffer (queue) implementation with unit tests
- Bit manipulation macros (SET_BIT, CLEAR_BIT, READ_BIT)
- Safe pointer patterns and NULL checks
- Practice exercises with compilation and execution
- Memory layout demonstrations (stack, heap, static, const)

**Code Examples:**
```c
// Deliverables in this sprint:
- src/common/include/macros.h           // Bit macros, compiler directives
- src/common/include/types.h            // Common types, error codes
- src/common/include/circular_buffer.h  // Reusable FIFO queue
- src/common/src/circular_buffer.c      // Implementation
- tests/learning/test_circular_buffer.c // Comprehensive tests
```

**Definition of Done (specific):**
- [ ] All practice exercises compile with `-Wall -Wextra` zero warnings
- [ ] Circular buffer passes all unit tests (full, empty, wraparound, thread-safe edge cases)
- [ ] Bit macros verified against real register access patterns
- [ ] Memory layout demonstrated with actual measurements (stack growth, heap fragmentation)
- [ ] Technical note (500-800 words) covers: why volatile matters for MMIO, undefined behavior pitfalls, defensive coding for embedded systems
- [ ] Can articulate why each pattern exists and when to use/avoid it

**Deliverables:**
- Reusable `circular_buffer` library (used in Sprint 3's UART ISR buffer)
- `macros.h` with bit manipulation utilities (used in every sprint)
- `types.h` with common types and error codes
- Comprehensive unit tests for all utilities
- Written learning notes on embedded C pitfalls and solutions

**Why this matters for interviews:**
- Demonstrates understanding of embedded fundamentals *before* diving into frameworks
- Circular buffer is a real question interviewers ask
- Shows defensive programming mindset (critical for mission-critical systems)
- Bit manipulation patterns are used in every driver/firmware this roadmap builds

---

### Sprint 1 — Logger
- **Goal:** reusable logging library used by every later component.
- **Duration:** ~2 weeks | **Prerequisites:** Sprint Learning
- **Study:** TLPI File I/O; OSTEP File Systems
- **Reading:** source of spdlog or Boost.Log
- **Build:** logger library, log levels, file rotation, unit tests
- **Definition of Done (specific):**
  - [ ] Standalone library other modules can link against
  - [ ] File rotation verified with tests

---

### Sprint 2 — Configuration Manager
- **Goal:** centralized, reloadable configuration.
- **Duration:** ~2 weeks | **Prerequisites:** Sprint 1
- **Study:** JSON parsing and schema design
- **Reading:** nlohmann/json or similar library
- **Build:** Config Manager, `config.json`, live reload
- **Definition of Done (specific):**
  - [ ] No config hard-coded in code
  - [ ] Invalid config rejected with clear error

---

### Sprint 3 — Bare-Metal MCU Fundamentals
- **Goal:** bring up MCU from bare-metal — registers, interrupts, MMIO.
- **Duration:** ~4–5 weeks | **Prerequisites:** Sprint 2
- **Study:** ARM Cortex-M4 exception model; STM32H743 peripherals
- **Reading:** STM32 reference manual; *Mastering STM32* peripheral chapters
- **Lab:** blink LED via direct register writes (throwaway lab)
- **Build:** polling-based sensor read, interrupt-driven GPIO, basic DMA
- **Definition of Done (specific):**
  - [ ] Sensor read via polling is stable
  - [ ] Interrupt-driven GPIO input verified (not polling)
  - [ ] At least one peripheral via direct register access (documented)

---

### Sprint 4 — FreeRTOS Integration
- **Goal:** restructure bare-metal into FreeRTOS application.
- **Duration:** ~3–4 weeks | **Prerequisites:** Sprint 3
- **Study:** FreeRTOS tasks, queues, semaphores/mutexes, timing
- **Reading:** FreeRTOS kernel source for scheduling and queue implementation
- **Lab:** producer/consumer with FreeRTOS queue (throwaway)
- **Build:** sensor + motor control loop as FreeRTOS tasks with queue synchronization
- **Definition of Done (specific):**
  - [ ] Control loop runs at deterministic, measured rate
  - [ ] Tasks synchronized via FreeRTOS primitives (not globals)

---

### Sprint 5 — Embedded GUI (LVGL)
- **Goal:** add live embedded GUI rendering sensor data on RTOS.
- **Duration:** ~2–3 weeks | **Prerequisites:** Sprint 4
- **Study:** LVGL widgets, event loop, display/input driver interface
- **Reading:** LVGL's display/input driver porting guide
- **Lab:** run built-in LVGL demo widget (throwaway)
- **Build:** sensor data rendered live on LVGL UI, isolated FreeRTOS task
- **Definition of Done (specific):**
  - [ ] LVGL UI updates live without tearing or frame drops
  - [ ] UI task does not block control loop's timing (measured)

**→ Release V0.5** — First demoable MCU capability (FreeRTOS + LVGL)

---

### Sprint 6 — Kernel & Device Tree Fundamentals
- **Goal:** move into real Linux kernel-space work.
- **Duration:** ~8–10 weeks | **Prerequisites:** V0.5
- **Study:** Linux Kernel Labs — boot, character drivers, interrupts, Device Model
- **Reading:** mainline kernel `drivers/char/` example; BeagleBone Black Device Tree source
- **Lab:** 2-3 Linux Kernel Labs exercises (throwaway)
- **Build:** custom character device driver, GPIO driver, Device Tree overlay
- **Definition of Done (specific):**
  - [ ] Driver loads via `insmod`, visible in `dmesg` without errors
  - [ ] Device Tree overlay binds driver to hardware
  - [ ] Interrupt-driven GPIO verified (not polling)

### Sprint 7 — Device Manager
- **Goal:** expose device identity and system information.
- **Duration:** ~2–3 weeks | **Prerequisites:** Sprint 6
- **Study:** `/proc` and `/sys` filesystem structure
- **Build:** `eldmp info` tool — CPU, RAM, kernel version
- **Definition of Done (specific):**
  - [ ] Output matches actual system state (verified against `uname`/`free`/`lscpu`)

### Sprint 8 — Health Monitor
- **Goal:** continuous system health monitoring.
- **Duration:** ~2–3 weeks | **Prerequisites:** Sprint 7
- **Study:** watchdog mechanisms, systemd state
- **Build:** Health monitor service, threshold alerts
- **Definition of Done (specific):**
  - [ ] Detects CPU/memory/disk thresholds correctly

### Sprint 9 — D-Bus IPC Layer
- **Goal:** inter-process communication via D-Bus.
- **Duration:** ~3–4 weeks | **Prerequisites:** Sprint 8
- **Study:** D-Bus protocol, service activation
- **Build:** Device Manager and Health Monitor communicate via D-Bus
- **Definition of Done (specific):**
  - [ ] IPC messages verified with `dbus-monitor`
  - [ ] Service activation works correctly

### Sprint 10 — systemd Integration
- **Goal:** run every service as a managed systemd unit.
- **Duration:** ~2 weeks | **Prerequisites:** Sprint 9
- **Study:** systemd unit files, `journalctl`, `systemctl`
- **Build:** `logger.service`, `device.service`, `monitor.service`
- **Definition of Done (specific):**
  - [ ] All services start automatically on boot
  - [ ] Services restart automatically on crash at the systemd level

### Sprint 11 — Watchdog
- **Goal:** application-level supervision on top of systemd.
- **Duration:** ~2–3 weeks | **Prerequisites:** Sprint 10
- **Build:** heartbeat mechanism, automatic restart of unresponsive services, failure logging
- **Definition of Done (specific):**
  - [ ] A deliberately hung service is detected and restarted within a defined timeout

**→ Release V1.0** — Full Linux platform (kernel driver + services)

---

### Sprint 12 — Buildroot/Yocto Build System
- **Goal:** custom embedded Linux image.
- **Duration:** ~4–5 weeks | **Prerequisites:** Sprint 11
- **Study:** Buildroot or Yocto layer creation
- **Build:** Custom Linux image for BeagleBone Black
- **Definition of Done (specific):**
  - [ ] Image boots successfully, all services start

**→ Release V1.5** — Custom Linux image

---

### Sprint 13 — Custom Protocol & CAN
- **Goal:** custom binary protocol for MCU↔Linux communication.
- **Duration:** ~4–5 weeks | **Prerequisites:** V1.5
- **Study:** binary protocol design, CAN bus, error detection (CRC)
- **Build:** Protocol definition, Linux↔MCU communication, fault injection tests
- **Definition of Done (specific):**
  - [ ] Protocol survives deliberate corruption (bad CAN frames, timeouts)

### Sprint 14 — Networking & MQTT
- **Goal:** cloud connectivity via MQTT.
- **Duration:** ~3–4 weeks | **Prerequisites:** Sprint 13
- **Study:** MQTT protocol, TLS in embedded contexts
- **Build:** MQTT client publishing sensor data
- **Definition of Done (specific):**
  - [ ] Publishes to MQTT broker, messages persist correctly

### Sprint 15 — OTA Update System
- **Goal:** over-the-air firmware and system updates.
- **Duration:** ~3–4 weeks | **Prerequisites:** Sprint 14
- **Study:** signed updates, rollback mechanisms
- **Build:** OTA client, signed update validation, rollback on failure
- **Definition of Done (specific):**
  - [ ] Update succeeds and fails safely (rollback works)

**→ Release V2.0** — Full integration (protocol + networking + OTA)

---

### Sprint 16 — Security & TLS
- **Goal:** encrypt and secure all communications.
- **Duration:** ~3–4 weeks | **Prerequisites:** Sprint 15
- **Study:** TLS/SSL, key management, signed firmware
- **Build:** TLS for all network communication, signed firmware validation
- **Definition of Done (specific):**
  - [ ] TLS handshake verified with `openssl s_client`
  - [ ] Firmware signatures validated on boot

**→ Release V3.5** — Production-ready platform

---

## Timeline Summary

| Phase | Sprints | Duration | Output |
|-------|---------|----------|--------|
| Foundation | 0, Learning, 1-2 | ~8 weeks | Environment + C fundamentals + utilities |
| MCU | 3-5 | ~9-12 weeks | V0.5: FreeRTOS + LVGL |
| Linux basics | 6-11 | ~20-25 weeks | V1.0: Kernel + services |
| Build system | 12 | ~4-5 weeks | V1.5: Custom image |
| Integration | 13-15 | ~10-13 weeks | V2.0: Full platform |
| Security | 16 | ~3-4 weeks | V3.5: Production-ready |
| **TOTAL** | **0-16 + Learning** | **~16-19 months** (part-time) | Portfolio-quality system |

---

## Key Resources Updated

### Foundation (Sprint 0 & Learning)
- *The C Programming Language* — Kernighan & Ritchie
- Embedded C best practices documentation
- Linux kernel bitops and data structure examples

### MCU Track (Sprints 1-5)
- *Mastering STM32* — Carmine Noviello
- *Mastering the FreeRTOS Real Time Kernel* — Richard Barry
- LVGL documentation and examples

### Linux Track (Sprints 6-12)
- Linux Kernel Labs — hands-on exercises
- *Linux Device Drivers* (3rd ed.) — Corbet et al.
- Buildroot/Yocto documentation

### Integration (Sprints 13-16)
- D-Bus documentation
- MQTT protocol specification
- OpenSSL/TLS documentation

---

## Portfolio Structure

This roadmap **is not a framework**. It's a **learning path demonstrated through artifacts**:

```
eldmp-portfolio/
├── README.md                    # Overview + results achieved
├── docs/learning/               # All learning materials organized by sprint
├── src/
│   ├── learning/               # Sprint Learning deliverables (C foundations)
│   ├── sprint1-logger/         # Sprint 1: Logger module
│   ├── sprint2-config/         # Sprint 2: Config manager
│   ├── sprint3-bare-metal/     # Sprint 3: MCU firmware
│   └── ... (organized by sprint)
├── tests/                       # Comprehensive test suite
├── notes/                       # Sprint learning journals
└── releases/                    # Tagged versions (V0.5, V1.0, V1.5, V2.0, V3.5)
```

**Each artifact demonstrates:**
- ✅ Specific technical skill (kernel drivers, RTOS, embedded GUI, etc.)
- ✅ Problem-solving ability (how issues were debugged and fixed)
- ✅ Communication (technical notes explaining what was learned)
- ✅ Depth (real production patterns, not tutorials)

---

## Interview Talking Points

After each major release (V0.5, V1.0, V1.5, V2.0, V3.5), you can discuss:

- **V0.5:** "I built a real-time firmware stack with FreeRTOS and LVGL GUI running on STM32, demonstrating interrupt handling, task synchronization, and GUI rendering under deterministic timing constraints."
- **V1.0:** "I wrote a Linux kernel driver and user-space services communicating via D-Bus, implementing IPC patterns used in production embedded Linux systems."
- **V1.5:** "I created a custom Yocto layer and built a complete embedded Linux image, demonstrating build system knowledge and board bring-up."
- **V2.0:** "I designed and implemented a custom binary protocol with CRC error detection, MQTT networking, and OTA update system — full end-to-end platform integration."
- **V3.5:** "I secured the entire platform with TLS encryption and signed firmware validation, showing security-conscious embedded systems design."

---

## What Changed from Original Roadmap

1. ✅ **Sprint Learning added** between Sprint 0 and Sprint 1
   - Focuses on Embedded C fundamentals
   - Creates reusable utilities (circular buffer, bit macros, defensive patterns)
   - Reduces bugs in production code
   - Better preparation for MCU work

2. ✅ **Structure changed to portfolio orientation**
   - Not a "framework to build on"
   - A "learning journey with concrete artifacts"
   - Emphasis on what was learned, not what was shipped

3. ✅ **Clear mapping of knowledge to sprints**
   - Each sprint builds on previous learning
   - Interview talking points clear
   - Portfolio structure professional and understandable

---

**Version:** Updated with Sprint Learning  
**Effective:** [Date]  
**Next Review:** After Sprint Learning completion
