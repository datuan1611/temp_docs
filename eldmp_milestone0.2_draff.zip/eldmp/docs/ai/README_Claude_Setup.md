# ELDMP trên Claude — Hướng dẫn Thiết lập & Vận hành

Dự án dùng **hai bối cảnh Claude riêng biệt, cùng gói Claude Pro** — chi tiết vai trò từng bên ở mục 13 (`CLAUDE_PROJECT_INSTRUCTIONS.md`) và mục 20 (`ELDMP_AI_MENTOR_PROTOCOL.md`):

- **Claude Web** (project trên claude.ai) — mentor & kiến trúc sư, dùng 4 file tài liệu dưới.
- **Claude Code** (CLI, chạy trong VM Ubuntu tại gốc repo) — thực thi trực tiếp, chỉ đọc `CLAUDE.md` ở gốc repo, **không** đọc 4 file này.

| File | Dùng để làm gì | Đưa vào đâu |
|---|---|---|
| `CLAUDE_PROJECT_INSTRUCTIONS.md` | Bản "bộ não" cô đọng cho Claude Web — vai trò, ngôn ngữ, các chế độ, DoD, chống bịa đặt, mục 13 mô tả mô hình 2 công cụ | Dán vào ô **Project instructions**; lưu bản sao tại `docs/ai/` trong repo |
| `ELDMP_AI_MENTOR_PROTOCOL.md` | Bản đầy đủ, chi tiết cho Claude Web (hợp nhất `AI_CONSTITUTION.md` + `AI_LEARNING_PROTOCOL.md` gốc, đã loại trùng lặp; mục 20 mô tả mô hình 2 công cụ) | Upload vào **Project knowledge**; lưu bản sao tại `docs/ai/` trong repo |
| `ELDMP_Roadmap_MCU_vi.md` | Roadmap kỹ thuật chi tiết từng Sprint. **Lưu ý:** việc gộp file roadmap này với các bản khác trong repo thành 1 bản VI + 1 bản EN là một việc riêng, chưa thực hiện ở lần cập nhật này — xem ghi chú cuối file | Upload vào **Project knowledge**; lưu bản sao tại `docs/ai/` hoặc `docs/roadmap/` trong repo |
| `ELDMP_PORTFOLIO_STRUCTURE.md` | Cấu trúc repo/portfolio chi tiết — tham khảo phụ, không phải roadmap sprint (xem `docs/README.md` trong repo) | Upload vào **Project knowledge**; bản gốc tại `docs/learning/reference_02/` |
| `ELDMP_Roadmap_Updated_en.md`, `ELDMP_Roadmap_Updated_vi.md` | Biến thể roadmap khác (đánh số sprint 10/11 khác bản chính) — tham khảo phụ cho câu hỏi cấu trúc portfolio, **không** dùng để lập kế hoạch sprint | Upload vào **Project knowledge**; bản gốc tại `docs/learning/reference_02/` |
| `README_Claude_Setup.md` | File hướng dẫn này | Không cần upload lên claude.ai; lưu tại `docs/ai/` trong repo để tra cứu lại |
| `CLAUDE.md` | Quy tắc vận hành cho **Claude Code** — ngắn gọn, cố tình lệch khỏi Socratic/giảm-dependency của protocol trên (mục 13/20 giải thích lý do) | Đặt ở **gốc repo** (`./CLAUDE.md`), không upload lên claude.ai |

**Repo Git là nguồn sự thật.** Sửa 4 file tài liệu ở `docs/ai/` trong repo trước, rồi upload lại (hoặc dán lại với `CLAUDE_PROJECT_INSTRUCTIONS.md`) vào claude.ai — không sửa trực tiếp bản trên claude.ai rồi quên đồng bộ ngược lại repo.

**Vì sao tách thành 2 lớp (Instructions ngắn + Knowledge đầy đủ)?** Project instructions được nạp vào *mọi* tin nhắn trong project, nên càng dài càng "loãng" sự chú ý của Claude vào các quy tắc quan trọng nhất — Anthropic không công bố một giới hạn ký tự cố định cho ô này (khác ChatGPT), nhưng khuyến nghị chung vẫn là giữ súc tích. Vì vậy phần lõi hành vi (không thể thiếu ở mọi câu trả lời) nằm trong Instructions; phần chi tiết/ví dụ mở rộng (chỉ cần khi liên quan) nằm trong Project knowledge — Claude sẽ tự tra cứu khi cần, vì trong một cuộc hội thoại Claude nhìn thấy toàn bộ nội dung project knowledge (ở gói trả phí, nếu tổng dung lượng vượt cửa sổ ngữ cảnh, Claude tự bật chế độ tìm kiếm theo đoạn — RAG — để mở rộng dung lượng).

---

## 1. Thiết lập Project trên Claude (khoảng 5 phút)

1. Vào **claude.ai** → bấm **Projects** ở thanh bên trái (hoặc vào thẳng `claude.ai/projects`).
2. Bấm **"+ New Project"** ở góc trên bên phải.
3. Đặt tên, ví dụ: `ELDMP — Embedded Linux Roadmap`.
4. Trong trang project, tìm mục **Instructions** → dán toàn bộ nội dung file `CLAUDE_PROJECT_INSTRUCTIONS.md`.
5. Tìm mục **Project knowledge** → upload 2 file: `ELDMP_AI_MENTOR_PROTOCOL.md` và `ELDMP_Roadmap_MCU_vi.md`.
6. Bấm lưu. Bắt đầu chat mới **bên trong project này** — mọi hội thoại mới sẽ tự động nạp Instructions + có quyền truy cập Project knowledge.

> **Lưu ý tài khoản:** Projects khả dụng cho mọi loại tài khoản Claude, kể cả free — nhưng tài khoản free giới hạn tối đa **5 project**. Ngữ cảnh (context) **không** tự chia sẻ giữa các cuộc hội thoại khác nhau trong cùng project trừ khi thông tin đó nằm trong Project knowledge — nên nếu có quyết định quan trọng mới phát sinh trong lúc chat (đổi board, đổi kiến trúc...), hãy cập nhật lại roadmap/notes và re-upload để các chat sau cũng "biết".

---

## 2. Kích hoạt ngữ cảnh Sprint

Đầu mỗi phiên làm việc, ghi kèm ngữ cảnh hiện tại để Claude bám đúng phạm vi:

```
[Sprint 3 - MCU Bare-metal] Tôi đang cấu hình UART DMA cho STM32F4...
[Sprint 6 - Linux Kernel] Tôi đang viết Device Tree cho I2C sensor...
```

## 3. Chuyển đổi chế độ (Operational Modes)

Gõ các lệnh sau bất cứ lúc nào để đổi phong cách làm việc:

| Câu lệnh | Mục đích |
|---|---|
| `Chuyển sang DEBUG MODE` | Phân tích lỗi theo từng lớp, không đưa đáp án ngay, gợi ý thực nghiệm |
| `Chuyển sang CODE REVIEW MODE` | Soi code chuẩn C/C++ nhúng: UB, memory leak, race condition |
| `Chuyển sang TEACH MODE` | Giải thích từ gốc rễ: What → Why → How → Internals → Trade-offs |
| `Chuyển sang INTERVIEW MODE` | Đóng vai Senior Interviewer, hỏi dồn và đánh giá |
| `Chuyển sang ARCHITECTURE MODE` | Thiết kế hệ thống: Requirements → Trade-offs → Recommendation |
| `Chuyển sang ANSWER MODE` | Trả lời nhanh, ngắn gọn, đi thẳng đáp án |

## 4. Câu mở đầu gợi ý cho phiên đầu tiên

- *"[Sprint 3 - MCU Bare-metal] Hãy tóm tắt nhiệm vụ và mục tiêu của Sprint này giúp tôi."*
- *"Hãy xác nhận lại vai trò, nguyên tắc cốt lõi và các chế độ hoạt động của bạn."*

---

## 5. Mẹo dùng thêm trong hệ sinh thái Claude (không bắt buộc)

- **Kỹ thuật note / sprint review ở Claude Web**: nếu đang làm việc thiết kế/học ở đây và muốn lưu lại thành note, có thể nhờ Claude Web xuất Technical Note (300–600 từ theo DoD) hoặc bảng review milestone thành file Markdown, để lưu vào `notes/` của repo. Trong luồng làm việc chính (Sprint 1 trở đi), Claude Code tự viết và cập nhật Technical Note khi thực thi trong repo — mẹo này chỉ cần khi bạn tự làm việc đó ở Claude Web.
- **Coding thực tế trên repo**: dùng **Claude Code** (mục 13/20) — không phải một "bổ trợ" tuỳ chọn nữa mà là công cụ chính cho việc viết/sửa code từ Sprint 1. Xem mục 7 dưới để cài đặt.

---

## 6. Cài đặt Claude Code trong repo (từ Sprint 1)

1. `CLAUDE.md` nằm ở **gốc repo** (`./CLAUDE.md`), không phải trong `docs/ai/` — đây là quy ước Claude Code tự tìm và nạp.
2. Cài CLI trong VM (không phải máy host): `curl -fsSL https://claude.ai/install.sh | bash`, rồi `claude --version` và `claude doctor` để xác minh.
3. Trong thư mục gốc repo, chạy `claude` → đăng nhập (cần Claude Pro trở lên) → gõ `/context`, mục "Memory files" phải hiện `CLAUDE.md`.
4. Theo dõi `/usage` thường xuyên vì Claude Web và Claude Code dùng chung một pool quota (mục 13/20).
5. Không upload `CLAUDE.md` lên Project knowledge của Claude Web — lý do ở mục 13/20 (hai bộ quy tắc trái chiều nếu nạp chung).

---

## 7. Nếu ô Project Instructions báo vượt giới hạn ký tự

`CLAUDE_PROJECT_INSTRUCTIONS.md` hiện ~10.900 ký tự (tăng từ ~8.600 sau khi thêm mục 13). Nếu giao diện của bạn báo vượt giới hạn, cắt theo thứ tự ưu tiên sau (nội dung bị cắt vẫn còn nguyên trong `ELDMP_AI_MENTOR_PROTOCOL.md`, Claude vẫn tra cứu được khi cần):
1. Mục 9 (bảng cầu nối MCU↔Linux) — đã có đầy đủ trong file protocol.
2. Mục 11 (an toàn phần cứng) — rút còn 1 câu nhắc, chi tiết đã có trong file protocol.
3. Rút gọn phần liệt kê các mode ở mục 5 xuống chỉ còn tên mode + 1 cụm từ khoá.

Luôn giữ lại mục 0, 1, 3, 4, 8, 13 (vai trò, ngôn ngữ, chống bịa đặt, direct-answer-first, giảm dependency, mô hình 2 công cụ) — đây là nhóm ảnh hưởng đến hành vi ở mọi câu trả lời.
