# ELDMP — Embedded Linux Device Management Platform

[![Build Status](https://img.shields.io/badge/build-passing-brightgreen?style=flat-square)](https://github.com/yourusername/eldmp/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=flat-square)](LICENSE)
[![Version: 0.1-dev](https://img.shields.io/badge/version-0.1--dev-blue?style=flat-square)](#)
[![C++17](https://img.shields.io/badge/C++-17-blue?style=flat-square)](#)

---

## Về Dự Án

**ELDMP** là một **dự án kỹ thuật cá nhân dài hạn** (16–19 tháng) được xây dựng để phát triển năng lực **Embedded Linux Engineer** / **Embedded Systems Engineer** ở cấp độ **Senior**.

Dự án bao gồm một **hệ thống thực tế hoàn chỉnh**: từ firmware MCU bare-metal, FreeRTOS RTOS, GUI nhúng (LVGL), Linux kernel, user-space services, custom protocol, networking, OTA update — cho đến bảo mật đầu-cuối (TLS).

**Không phải framework hay template.** Đây là một **portfolio công khai**, được phiên bản rõ ràng (V0.5 → V1.0 → V1.5 → ... → V3.5), mỗi phiên bản là một trạng thái hệ thống **hoàn toàn chạy được** và **khả demo**.

---

## Phương Pháp Học Tập

Dự án áp dụng **project-driven learning** qua ba kênh:

1. **Study:** Các chương sách được gắn **chính xác vào sprint cần nó** (không đọc toàn bộ một cuốn trước)
2. **Reading:** Đọc **source code sản xuất thực tế** (Linux kernel, FreeRTOS, LVGL, systemd, RAUC, ...)
3. **Build/Experiment:** Xây dựng **cấu trúc lớp thực tế** (Application → Middleware → HAL → Driver → Kernel), phân biệt **Lab** (thử nghiệm bỏ đi) vs **Ship** (code đạt chuẩn)

---

## Môi Trường Phát Triển

Dự án được build trên một **hạ tầng Ubuntu Server Native chuẩn hoá** — Docker Engine cài **trực tiếp theo đúng hướng dẫn chính thức của Docker Inc.**, không qua bất kỳ lớp wrapper/giả lập nào (Colima, OrbStack, Docker Desktop). Toàn bộ script/tài liệu trong repo này **không phụ thuộc hạ tầng bên dưới** — chạy được như nhau trên máy thật (bare-metal), VM (bất kỳ hypervisor nào), hay Cloud Instance. Đây là mô hình **sát nhất với môi trường Production/CI Server thực tế trong công nghiệp**, và đảm bảo tính độc lập tuyệt đối — không còn phụ thuộc vào một công cụ giả lập macOS cụ thể nào có thể ngừng hỗ trợ bất cứ lúc nào.

**Bối cảnh triển khai thực tế của dự án (lịch sử quyết định, portfolio value):**
- **Colima đã được xác nhận THẤT BẠI thật** trên macOS 11.7.11 Big Sur (không còn hỗ trợ phiên bản macOS cũ) — lý do trực tiếp dẫn tới việc chuẩn hoá sang Ubuntu Server Native.
- **VMware Fusion cũng bị loại khi cân nhắc** — Fusion 13 yêu cầu tối thiểu macOS 12 Monterey, không hỗ trợ Big Sur.
- **VMware Fusion Professional** (bản Pro, mã phiên bản bạn cung cấp: 20191287 — hiện Fusion Pro đã miễn phí cho cá nhân/thương mại, không cần license key) được dùng để cài **Ubuntu Server 26.04 LTS ARM64** thành công trên MacBook Pro M1, 8GB RAM, macOS 11.7.11 Big Sur. Từ điểm này trở đi, mọi thứ (Docker Engine, toolchain, DevContainer) đều là **Ubuntu Server chuẩn công nghiệp** — không còn phụ thuộc VMware Fusion hay macOS nữa, và **có thể tái sử dụng y nguyên trên bất kỳ máy chủ Linux nào khác**.

**Scope Update (không đổi qua các lần chuẩn hoá môi trường):** do giới hạn RAM của máy phát triển hiện tại, việc **build toàn bộ image Yocto/Buildroot cho BeagleBone Black vẫn nằm ngoài máy này**, thực hiện trên một máy chủ Linux chuyên dụng riêng.

```
Client Workstation (macOS/Windows/Linux — bất kỳ)
├─ VS Code (Remote-SSH) ──────────────────────────►  Ubuntu Server (26.04 LTS ARM64)
│    └─ Dev Containers (Reopen in Container)          "eldmp" — Docker Engine NATIVE
│         → dùng Docker Engine trực tiếp trên         (cài qua apt chính thức)
│           server, không qua wrapper/socket          Swap 4GB, sysctl tối ưu
│           forward nào                                └─ eldmp-toolchain container:
└─ openocd (flash MCU qua USB, từ máy có                    arm-none-eabi-gcc,
   cổng vật lý kết nối board)                               arm-linux-gnueabihf-gcc,
                                                            Cppcheck/Clang-Tidy/
                                                            Sanitizers/Valgrind/
                                                            Unity/CMock/GoogleTest

                    Máy Linux chuyên dụng riêng (build server)
                    └─ Build Yocto/Buildroot image cho BeagleBone Black (Sprint 12)
```

### Quick Start

Giả định Ubuntu Server đã được cài đặt sẵn (xem [`SETUP.md`](SETUP.md) nếu chưa có — bao gồm cả ghi chú cách dựng qua VMware Fusion Professional trên MacBook M1/Big Sur nếu bạn ở đúng bối cảnh này):

```bash
# 1. SSH vào Ubuntu Server
ssh <user_server>@<IP-SERVER>

# 2. Tối ưu OS + cài Docker Engine chính thức + swap 4GB (idempotent)
git clone git@github.com:user_git/eldmp.git ~/eldmp
cd ~/eldmp
./scripts/helper/setup-ubuntu-docker.sh
# (thoát SSH, đăng nhập lại để nhóm "docker" có hiệu lực)

# 3. Verify toàn diện — 4 cấp độ
./scripts/helper/verify-env.sh

# 4. Build & test trực tiếp trên server
mkdir build && cd build && cmake .. && cmake --build . && ctest --output-on-failure

# 5. Hoặc dùng container toolchain đầy đủ (static analysis, sanitizers)
docker build -f .devcontainer/Dockerfile -t eldmp-toolchain .
docker run --rm -it -v "$(pwd)":/workspace eldmp-toolchain
```

Hướng dẫn đầy đủ (tối ưu OS, cài Docker Engine, permissions & daemon.json, VS Code Remote-SSH từ Windows/macOS/Linux, DevContainer, flash MCU, self-hosted CI runner) → xem [`SETUP.md`](SETUP.md)

---

## Lộ Trình Core Track (Sprint 0–16)

### Phase 1: MCU Fundamentals (Sprint 3–5)
- **Sprint 3** — Bare-Metal MCU (registers, interrupts, MMIO)
- **Sprint 4** — FreeRTOS Integration (task, queue, semaphore)
- **Sprint 5** — Embedded GUI (LVGL)
- **→ Release V0.5** — MCU firmware hoàn chỉnh (FreeRTOS + LVGL)

### Phase 2: Linux Kernel & Services (Sprint 6–11)
- **Sprint 6** — Kernel & Device Tree (character driver, DT overlay)
- **Sprint 7–10** — Services (Device Manager, Health Monitor, D-Bus IPC, systemd)
- **Sprint 11** — Watchdog & Service Management
- **→ Release V1.0** — Full Linux platform (kernel + user-space)

### Phase 3: Build System (Sprint 12)
- **Sprint 12** — Buildroot / Yocto custom image — **thực hiện trên máy Linux chuyên dụng riêng**, không phải VM này (xem Scope Update ở trên)
- **→ Release V1.5** — Hoàn chỉnh image build

### Phase 4: Integration & Advanced (Sprint 13–15)
- **Sprint 13** — Custom Protocol Linux↔MCU (CRC, retry, versioning)
- **Sprint 14** — Networking & MQTT
- **Sprint 15** — OTA (Over-the-Air Updates)
- **→ Release V2.0** — Full integration

### Phase 5: Security (Sprint 16)
- **Sprint 16** — TLS, signed OTA, encryption
- **→ Release V3.5** — Production-ready (Core Track hoàn thành)

**Extension Track** (V4.0+): Tuỳ chọn sau khi hoàn thành Core Track (Performance/Observability, Secure Boot/TEE, i.MX93 port, ROS2, ...)

---

## Kỹ Năng Được Chứng Minh

Dự án này chứng minh:

✅ **Bare-metal MCU programming** — registers, interrupts, memory-mapped I/O  
✅ **Real-time systems** — FreeRTOS task scheduling, synchronization  
✅ **Embedded GUI** — LVGL integration, event-driven UI  
✅ **Linux kernel** — driver development, Device Tree, interrupt handling  
✅ **Inter-process communication** — D-Bus, systemd services  
✅ **Build systems** — CMake, Buildroot, Yocto (trên máy Linux chuyên dụng)  
✅ **Custom protocol design** — CRC, retry logic, versioning, fault tolerance  
✅ **Networking & cloud** — MQTT, TLS, OTA updates  
✅ **Security** — signed firmware, encryption, key management  
✅ **Testing & debugging** — unit tests, sanitizers, fault injection, system-level verification  
✅ **Docker Engine chuẩn công nghiệp** — apt install thật trên Linux server, DevContainer, không phụ thuộc wrapper macOS

---

## Cấu Trúc Repository

```
eldmp/
├── src/                         # Source code (cập nhật theo sprint)
├── tests/                       # Unit + integration + verification tests
├── docs/                        # Architecture, roadmap, learning materials
├── notes/                       # Sprint learning journals
├── scripts/                     # Build, test, deployment automation
│   ├── setup-ubuntu-docker.sh   # Cài Docker Engine + swap trên Ubuntu VM
│   └── verify-env.sh            # Verification Suite 4 cấp độ
├── .devcontainer/               # Dockerfile + devcontainer.json (Docker Engine native)
├── config/                      # Configuration templates, systemd units
└── CMakeLists.txt               # Root CMake configuration
```

**Bốn repository spin-out** (mỗi cái là một artifact độc lập):
- `eldmp-mcu-firmware/` (Sprint 3–5) — Firmware FreeRTOS + LVGL
- `eldmp-kernel-driver/` (Sprint 6) — Kernel module + Device Tree overlay
- `eldmp-yocto-layer/` (Sprint 12) — Meta-layer tuỳ chỉnh, build trên máy Linux riêng
- `eldmp-linux-mcu-protocol/` (Sprint 13) — Custom protocol, **đây là điểm khác biệt mạnh nhất**

Chi tiết cấu trúc → xem [`ELDMP_PORTFOLIO_STRUCTURE.md`](docs/learning/reference_02/ELDMP_PORTFOLIO_STRUCTURE.md)

---

## Trạng Thái Hiện Tại

**Phiên bản:** `0.1-dev`  
**Sprint hiện tại:** Milestone 0.1 — Thiết lập môi trường (Ubuntu Server Native + Docker Engine chuẩn công nghiệp)  
**Tiến độ:** Repository skeleton, môi trường VM thật + DevContainer setup  
**Release đầu tiên:** V0.5 (dự kiến Sprint 5, ~tuần thứ 18)

---

## Tài Liệu

- **[SETUP.md](SETUP.md)** — Hướng dẫn setup chi tiết (Ubuntu Server Native + Docker Engine chuẩn công nghiệp)
- **[docs/README.md](docs/README.md)** — Index tài liệu
- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** — Tổng quan kiến trúc hệ thống
- **[docs/architecture/ARCHITECTURE.md](docs/architecture/ARCHITECTURE.md)** — Chi tiết từng lớp
- **[Roadmap Chi Tiết](docs/learning/reference_01/ELDMP_Roadmap_MCU_vi.md)** — Kế hoạch sprint từng bước
- **[notes/](notes/)** — Sprint learning journals (300–600 từ mỗi sprint)

---

## Learning Materials

Các tài liệu học tập được tổ chức theo sprint — gắn vào đúng sprint cần nó, không đọc theo trình tự sách từ đầu.

---

## Phỏng Vấn & Portfolio

Sau mỗi milestone chính, bạn có thể nói:

- **V0.5:** "Tôi xây dựng firmware FreeRTOS chạy một GUI LVGL trực tiếp, từ bare-metal registers tới task scheduling."
- **V1.0:** "Tôi viết Linux kernel driver và user-space services trao đổi via D-Bus, trên nền kernel nguyên gốc."
- **V1.5:** "Tôi tạo custom Yocto layer và build một hoàn chỉnh embedded Linux image."
- **V2.0:** "Tôi thiết kế một protocol tuỳ chỉnh nối Linux với firmware MCU, với CRC, retry, và versioning."
- **V3.5:** "Toàn bộ platform được mã hoá TLS đầu-cuối và update được ký số."

Mỗi statement đều có **code + test + documentation** để chứng minh.

---

## Hardware Mục Tiêu

| Giai đoạn | Board | Lý do | Sprint |
|---|---|---|---|
| MCU | STM32 Nucleo-F446RE / H743ZI | Bare-metal + FreeRTOS | Sprint 3 |
| Display | Module LCD nhỏ (SPI/parallel) | LVGL GUI | Sprint 5 |
| Linux SoC | BeagleBone Black Rev C | Embedded Linux bring-up | Sprint 6 |
| Advanced | NXP i.MX93 | Extension Track (V6.0+) | After V3.5 |

**Chính sách:** Hardware chỉ được mua khi sprint **thực sự cần** — không mua trước, không để "cho chắc".

---

## License

MIT — Source code được viết để mọi người đọc và tái sử dụng.

---

**Status:** 🚀 Development in progress (Sprint 0)  
**Next Milestone:** V0.5 (Sprint 5) — MCU firmware complete  
**Roadmap:** [ELDMP_Roadmap_MCU_vi.md](docs/learning/reference_01/ELDMP_Roadmap_MCU_vi.md)

---

*Last Updated: Sprint 0 (Milestone 0.1 — Ubuntu Server VM + Docker Engine chuẩn công nghiệp)*
