#!/bin/bash

echo "🎨 Formatting code with clang-format"

find src tests -name "*.cpp" -o -name "*.h" | while read file; do
    echo "Formatting: $file"
    clang-format -i "$file"
done

echo "✅ Formatting complete"
