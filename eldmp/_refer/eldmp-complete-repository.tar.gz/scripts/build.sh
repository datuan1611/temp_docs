#!/bin/bash
set -e

echo "🔨 Building ELDMP (Linux side)"
echo "=============================="
echo ""

# Check dependencies
for cmd in cmake gcc g++; do
    if ! command -v $cmd &> /dev/null; then
        echo "❌ Missing: $cmd"
        exit 1
    fi
done

# Create & configure build directory
rm -rf build
mkdir build && cd build

cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXPORT_COMPILE_COMMANDS=ON ..

# Build
echo "Compiling..."
make -j$(nproc)

# Run tests
echo ""
echo "Running tests..."
ctest --output-on-failure || echo "⚠️ Some tests failed"

echo ""
echo "✅ Build successful!"
echo "📦 Output: build/src/app/eldmp"
echo "📋 Compile commands: build/compile_commands.json"
