#ifndef ELDMP_CONFIG_MANAGER_H
#define ELDMP_CONFIG_MANAGER_H

#include <string>
#include <map>

class ConfigManager {
public:
    ConfigManager(const std::string& config_file);
    
    std::string get_string(const std::string& key, const std::string& default_value = "");
    int get_int(const std::string& key, int default_value = 0);
    bool get_bool(const std::string& key, bool default_value = false);
    
private:
    std::map<std::string, std::string> config_;
};

#endif /* ELDMP_CONFIG_MANAGER_H */
