#include "config_manager.h"
#include <fstream>
#include <sstream>

ConfigManager::ConfigManager(const std::string& config_file) {
    // Load configuration from JSON file
}

std::string ConfigManager::get_string(const std::string& key, const std::string& default_value) {
    auto it = config_.find(key);
    return (it != config_.end()) ? it->second : default_value;
}

int ConfigManager::get_int(const std::string& key, int default_value) {
    auto str = get_string(key);
    return str.empty() ? default_value : std::stoi(str);
}

bool ConfigManager::get_bool(const std::string& key, bool default_value) {
    auto str = get_string(key);
    if (str.empty()) return default_value;
    return str == "true" || str == "1" || str == "yes";
}
