#include "logger.h"
#include <fstream>
#include <iostream>
#include <chrono>
#include <iomanip>

Logger::Logger(const std::string& filename, LogLevel level)
    : filename_(filename), current_level_(level) {
    // Open file for appending
}

Logger::~Logger() {
    // Clean up
}

void Logger::log(LogLevel level, const std::string& message) {
    if (level < current_level_) return;
    
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    
    std::ofstream file(filename_, std::ios::app);
    file << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S")
         << " [" << static_cast<int>(level) << "] " << message << "\n";
}

void Logger::set_level(LogLevel level) {
    current_level_ = level;
}
