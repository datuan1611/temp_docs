#ifndef ELDMP_LOGGER_H
#define ELDMP_LOGGER_H

#include <string>
#include <memory>

enum class LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARN = 2,
    ERROR = 3,
};

class Logger {
public:
    Logger(const std::string& filename, LogLevel level = LogLevel::INFO);
    ~Logger();
    
    void log(LogLevel level, const std::string& message);
    void set_level(LogLevel level);
    
private:
    std::string filename_;
    LogLevel current_level_;
};

#endif /* ELDMP_LOGGER_H */
