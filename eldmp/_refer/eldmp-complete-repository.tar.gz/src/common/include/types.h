#ifndef ELDMP_TYPES_H
#define ELDMP_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/* Error codes */
typedef int32_t ErrorCode;

#define ELDMP_OK        0
#define ELDMP_ERR_NOMEM -1
#define ELDMP_ERR_PARAM -2
#define ELDMP_ERR_IO    -3
#define ELDMP_ERR_STATE -4

#endif /* ELDMP_TYPES_H */
