#include <iostream>
#include "logger.h"
#include "config_manager.h"

int main(int argc, char* argv[]) {
    std::cout << "ELDMP - Embedded Linux Device Management Platform\n";
    std::cout << "Version: 3.5.0\n\n";
    
    // Initialize logger
    Logger logger("/tmp/eldmp.log", LogLevel::INFO);
    logger.log(LogLevel::INFO, "ELDMP started");
    
    // Initialize config
    ConfigManager config("config.json");
    
    std::cout << "✓ Application initialized\n";
    
    return 0;
}
