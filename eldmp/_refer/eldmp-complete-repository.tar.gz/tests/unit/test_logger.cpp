#include <catch2/catch_test_macros.hpp>
#include "logger.h"
#include <filesystem>
#include <fstream>

TEST_CASE("Logger can be instantiated", "[logger]") {
    Logger logger("/tmp/test_logger.log", LogLevel::DEBUG);
    REQUIRE(true);  // Just test construction
}

TEST_CASE("Logger writes to file", "[logger]") {
    std::string test_file = "/tmp/test_logger_write.log";
    
    // Clean up if exists
    if (std::filesystem::exists(test_file)) {
        std::filesystem::remove(test_file);
    }
    
    Logger logger(test_file, LogLevel::INFO);
    logger.log(LogLevel::INFO, "Test message");
    
    // Verify file exists and contains message
    REQUIRE(std::filesystem::exists(test_file));
}
