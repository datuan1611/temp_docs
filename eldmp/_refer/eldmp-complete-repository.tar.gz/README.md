# ELDMP — Embedded Linux Device Management Platform

[![CI Build](https://github.com/you/eldmp/actions/workflows/ci-build.yml/badge.svg)](https://github.com/you/eldmp/actions)

**Version:** 3.5.0 (Core Track Complete)

## Overview

ELDMP is a complete embedded Linux platform integrating real-time MCU firmware with Linux services, demonstrating:

- **Bare-metal & RTOS:** STM32 firmware from registers to FreeRTOS to LVGL GUI
- **Linux Kernel:** Custom device driver + Device Tree
- **System Integration:** D-Bus IPC, systemd services, watchdog
- **Build System:** Buildroot & Yocto image generation
- **Protocol:** Custom Linux↔MCU communication with CRC/retry
- **OTA & Security:** Signed updates, TLS encryption

## Quick Start

```bash
# Clone repository
git clone https://github.com/you/eldmp.git
cd eldmp

# Build
./scripts/build.sh

# Run tests
cd build && ctest

# View documentation
cat docs/learning/SETUP_GUIDE.md
```

## Architecture

```
┌──────────────────┐
│  Cloud / MQTT    │
└────────┬─────────┘
         │
    ┌────┴─────────────────────┐
    │   Linux (BeagleBone)      │
    ├───────────────────────────┤
    │ Services: Device, Monitor │
    │ IPC: D-Bus, systemd       │
    │ Kernel Driver, Device Tree│
    └────────┬─────────────────┘
             │ UART/SPI/CAN
    ┌────────┴──────────────────┐
    │  MCU (STM32H743)          │
    ├───────────────────────────┤
    │ FreeRTOS + LVGL GUI       │
    │ Sensors & Control Loop    │
    └───────────────────────────┘
```

## Project Status

- ✅ V0.5 (Sprint 5): FreeRTOS + LVGL
- ✅ V1.0 (Sprint 11): Linux Kernel Driver + systemd
- ✅ V1.5 (Sprint 12): Buildroot/Yocto
- ✅ V2.0 (Sprint 13): Linux↔MCU Protocol
- ✅ V2.5 (Sprint 14): Networking (MQTT)
- ✅ V3.0 (Sprint 15): OTA Updates
- ✅ V3.5 (Sprint 16): Security (TLS + Signed Updates)

## Learning Resources

**Start here:** [EMBEDDED_C_MASTERY_GUIDE](docs/learning/EMBEDDED_C_MASTERY_GUIDE.md)

- [Setup Guide](docs/learning/SETUP_GUIDE.md) — Environment installation
- [ARM Cortex-M](docs/learning/ARM_CORTEX_M_GUIDE.md) — MCU architecture
- [FreeRTOS Basics](docs/learning/FREERTOS_BASICS.md) — RTOS fundamentals
- [LVGL Guide](docs/learning/LVGL_GUIDE.md) — Embedded GUI
- [Full Roadmap](SPRINT_ROADMAP.md) — Sprint-by-sprint plan

## Documentation

- **[Architecture Decisions](docs/architecture/decisions/)** — 4 key ADRs
- **[Protocol Spec](docs/protocols/ELDMP_PROTOCOL_SPEC.md)** — Linux↔MCU wire format
- **[Releases](docs/release-notes/)** — What's new in each version

## Repository Structure

```
eldmp/
├── src/              — C++ source code (Linux) + C firmware (MCU)
├── tests/            — Unit & integration tests
├── docs/             — Architecture, learning guides, release notes
├── notes/            — Sprint-by-sprint learning notes
├── scripts/          — Build & deployment helpers
├── yocto/            — Yocto layer (meta-eldmp)
├── buildroot/        — Buildroot configuration
├── device-tree/      — Device Tree overlays
├── CMakeLists.txt    — Build system root
└── README.md         — This file
```

## Build Instructions

### Prerequisites

```bash
sudo apt-get install -y \
  build-essential cmake git \
  arm-none-eabi-gcc arm-none-eabi-gdb
```

### Compile Linux Side

```bash
./scripts/build.sh
```

### Compile MCU Firmware

```bash
./scripts/build-mcu.sh
```

### Run Tests

```bash
cd build && ctest --output-on-failure
```

## Hardware

- **MCU:** STM32 Nucleo-H743ZI
- **SoC:** BeagleBone Black Rev C
- **Display:** Small SPI/parallel LCD (LVGL compatible)
- **Connectivity:** UART/SPI/CAN transceiver modules

## License

MIT License — See [LICENSE](LICENSE) for details.

## Future Work (Extension Track)

- V4.0: Performance profiling (eBPF, perf)
- V5.0: Secure boot & TEE (OP-TEE, TF-A)
- V6.0: Port to NXP i.MX93 (RemoteProc, asymmetric multiprocessing)
- V7.0: REST API + WebUI + Cloud dashboard
- V8.0: ROS2 integration & on-device AI

## Author

Written as a learning project for embedded systems mastery.
