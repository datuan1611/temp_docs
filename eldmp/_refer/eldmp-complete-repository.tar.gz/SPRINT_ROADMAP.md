# ELDMP Sprint Roadmap

[Full roadmap is in docs/learning/ — see ELDMP_Roadmap_MCU_vi.md]

## Quick Reference

| Phase | Sprints | Duration | Output |
|-------|---------|----------|--------|
| **MCU Foundational** | 0-5 | ~4 months | V0.5: FreeRTOS + LVGL |
| **Linux & Driver** | 6-11 | ~5 months | V1.0: Kernel + systemd |
| **Build System** | 12 | ~2 months | V1.5: Yocto/Buildroot |
| **Integration** | 13-16 | ~4 months | V3.5: OTA + Security |

**Total Core Track:** ~16 months (bán thời gian basis)

See detailed breakdown in repository docs/learning/
