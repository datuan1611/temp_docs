# Tài Liệu Học Tập (docs/learning)

Mỗi chủ đề có một tài liệu học, **gắn vào đúng sprint cần nó**. Đọc tài liệu *ngay trước* sprint tương ứng — đừng đọc trước cả chồng như một danh sách điều kiện tiên quyết; roadmap chọn lọc chương theo sprint có chủ đích.

## Danh mục

| Tài liệu | Sprint | Trạng thái | Được dùng bởi |
|---|---|---|---|
| [`EMBEDDED_C_MASTERY_GUIDE.md`](EMBEDDED_C_MASTERY_GUIDE.md) | Milestone 0.2 — Sprint Learning | **Đang dùng** | [`src/learning/`](../../src/learning/README.md), [`src/common/`](../../src/common/README.md), [`tests/1_learning/`](../../tests/1_learning/README.md) |
| `ARM_CORTEX_M.md` | Sprint 3 — Bare-metal MCU | Chưa viết (placeholder `.ARM_CORTEX_M.md`) | — |
| `FREERTOS_BASICS.md` | Sprint 4 — FreeRTOS | Chưa viết (placeholder) | — |
| `LVGL_GUI.md` | Sprint 5 — GUI nhúng | Chưa viết (placeholder) | — |
| `LINUX_KERNEL.md` | Sprint 6 — Kernel & Device Tree | Chưa viết (placeholder) | — |
| `SYSTEMD_SERVICES.md` | Sprint 10 — systemd | Chưa viết (placeholder) | — |

File có tên bắt đầu bằng dấu chấm là **placeholder rỗng**: khi sprint của nó bắt đầu, đổi tên (bỏ dấu chấm) và điền nội dung đầy đủ.

`reference_01/` và `reference_02/` chứa bản sao tham khảo của roadmap và các tài liệu quy hoạch ban đầu — là **ngữ cảnh**, không phải tài liệu học (xem `reference_01/NOTE.md`).

## Sprint Learning: chương guide → code → test

Bạn **làm** gì với từng chương nằm ở [`src/learning/README.md`](../../src/learning/README.md). Bảng này chỉ cho thấy chúng nối với nhau thế nào:

| Chương guide | Bài thực hành (Lab) | Code dùng chung (Ship) | Test |
|---|---|---|---|
| 1. Memory layout | `01_memory_layout.c` | — | tự kiểm tra |
| 2. `volatile`, `const`, `static` | `02_volatile_example.c` | `types.h` (`REG_RW`, `REG_RO`) | tự kiểm tra + xem mã máy |
| 3. Con trỏ, căn lề, callback | `03_pointer_arithmetic.c` | `defensive.h` (`eldmp_load_*`) | `test_defensive_patterns.c` |
| 4. Phép toán bit | `04_bitwise_operations.c` | `macros.h` | `test_bit_macros.c` |
| 5. Cấu trúc dữ liệu | `05_circular_buffer.c` | `circular_buffer.h/.c` | `test_circular_buffer.c` |
| 6. Lập trình phòng thủ | xuyên suốt 01–05 | `error_codes.h`, `defensive.h` | `test_defensive_patterns.c` |

## Chỗ code khác với guide (và vì sao)

Guide là tài liệu giảng dạy; code Ship cố ý khác ở **hai** chỗ. Cả hai được phát hiện bằng cách **kiểm thử**, không phải bằng cách đọc:

1. **Ring buffer (§5.1):** guide giữ biến `count` do cả ISR lẫn vòng lặp chính cùng ghi → mất cập nhật (lost update). `circular_buffer.c` không có `count` dùng chung. Bài 05, thí nghiệm A, tái hiện lỗi này một cách tất định.
2. **`SET_BIT(value, n)` (§4.1):** guide nhận **số bit**, trong khi header STM32 CMSIS định nghĩa `SET_BIT(REG, BIT)` theo **mask** — cùng tên, khác nghĩa. `macros.h` từ chối biên dịch nếu tên đã bị chiếm. Việc đổi tên là **quyết định cần đưa ra trước Sprint 3**.

> Hai chỗ này **không** phải lỗi của bạn khi học — chúng là bài học: tài liệu tốt vẫn có thể có lỗi, và test là cách duy nhất để biết.

## Thêm một tài liệu học mới

1. Đổi tên placeholder của sprint (bỏ dấu chấm) và viết nội dung đầy đủ.
2. Thêm một dòng vào bảng danh mục ở trên.
3. Tham chiếu tài liệu từ ghi chú kỹ thuật của sprint trong [`notes/`](../../notes/README.md).
4. Cập nhật [`docs/README.md`](../README.md).
