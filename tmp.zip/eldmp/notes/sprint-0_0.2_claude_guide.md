# Milestone 0.2 — Bản hoàn chỉnh cuối cùng (v0.0.2)

Tổng kết bản giao `eldmp-milestone-0.2-audited.zip` — ELDMP, Sprint Learning (Embedded C) — 21/10/2026

## Tóm tắt

Bản hoàn chỉnh nằm ở `eldmp-milestone-0.2-audited.zip`, đã gồm `.git` (các thao tác đổi tên đã stage, chưa commit). Tôi đã giải nén chính file zip, build với `-Werror` và chạy `ctest`: 8/8 pass. Hai mục `/build` trong zip là file thật của Sprint 12 (`buildroot/`), không phải artifact.

Tôi chưa thể chạy trên VM ARM64 của bạn, nên đó vẫn là bước xác nhận cuối cùng.

Bạn không nêu lỗi cụ thể, nên tôi đã rà soát toàn bộ bản trước để tìm lỗi còn sót.

## Lỗi tìm ra và đã sửa

1. **`git add -A` sẽ commit nhầm file biên dịch.** README bảo tạo `build-asan/` và `build-tsan/` ở gốc repo, mà `.gitignore` chỉ chặn `build/`. Giờ README dùng `build/asan` và `build/tsan`; đã kiểm tra bằng git, cây sạch.
2. **Hướng dẫn hoàn tác nguy hiểm.** `git checkout <file>` khi chưa stage sẽ xoá nội dung các file vừa đổi tên (mô phỏng cho kết quả 0 byte). README giờ có quy trình an toàn: `git add -A` trước khi thử nghiệm.
3. **Dangling pointer trong bài 03.** Bảng vector toàn cục vẫn trỏ vào biến cục bộ sau khi hàm kết thúc. `clang-tidy` phát hiện; đã sửa, rồi cố ý đưa lỗi trở lại để xác nhận lệnh vẫn bắt được.
4. **Test có thể crash thay vì báo FAIL** khi gặp con trỏ NULL, cùng một số điểm style nhỏ: đã sửa.
5. **Bài 01 và 02 không biên dịch với `-std=c11`** do `sbrk` và `usleep` thuộc POSIX; đã thêm `_DEFAULT_SOURCE` ở đầu file. Ma trận chuẩn C giờ 0/64 lỗi.
6. **Hồi quy do chính tôi gây ra:** một lần refactor làm vỡ riêng build TSan. Ma trận kiểm tra bắt được, đã sửa, và tôi chạy lại toàn bộ sau mỗi lần sửa.
7. **Lệnh `clang-tidy` trong README không sạch như tôi đã tuyên bố.** Đã chỉnh và kiểm chứng lại.

## Ba nguyên tắc của bạn (đã lưu thành quy tắc bền vững)

- **Bản hoàn chỉnh:** mọi lệnh trong README được chạy đúng nguyên văn trên một bản sao sạch trước khi gửi.
- **README bằng tiếng Việt:** viết theo cấu trúc "làm gì / tại sao / ý nghĩa", kèm checklist và mục sự cố. README tiếng Anh ở lượt trước là sai so với repo và yêu cầu của bạn.
- **Cập nhật mọi file liên quan:** 34 file thay đổi (21 placeholder được điền, 3 file mới, 10 file có sẵn), gồm toàn bộ code và test, `CMakeLists.txt`, 7 README, note, `SETUP.md`, `docs/README.md`, `README.md` gốc và `CLAUDE.md`. Các tài liệu `docs/ai/` cũng được ghi quy tắc mới.

## README bằng tiếng Việt

- **Việt hoá:** `src/learning/` (hướng dẫn 10 bước, checklist DoD và 8 câu tự kiểm tra cuối sprint), `src/common/` (giữ nguyên phần versioning gốc) và `docs/learning/`.
- **Mới:** `tests/1_learning/README.md` (mỗi test chứng minh gì) và `notes/README.md` (kích hoạt từ placeholder).
- **Cập nhật:** `docs/README.md`, `README.md` gốc, `src/app/README.md`, `SETUP.md` Bước 8.

## Kết quả kiểm tra

- **Build và test:** 9 cấu hình (gcc 13 / clang 18; Debug, Release, `-O3 -DNDEBUG`, ASan+UBSan, TSan) đều pass 8/8, zero warning với `-Werror`.
- **AArch64:** binary dynamic PIE (đúng dạng VM của bạn sẽ build) pass 8/8 dưới QEMU.
- **MCU và C++:** Cortex-M0/M4/M7 và C++17 biên dịch sạch.
- **Phân tích tĩnh:** `clang-tidy` và `gcc -fanalyzer` sạch.
- **Mutation:** phá thư viện có chủ đích thì test vẫn fail đúng.

## Kiểm toán thay đổi (không file nào bị mất, không nội dung đúng nào bị sửa)

So từng file theo hash giữa zip gốc bạn upload (240 file) và bản cuối:

- **209 file** giữ nguyên tuyệt đối.
- **21 placeholder rỗng** (0 byte) được đổi tên `.X` → `X` và điền nội dung; không mất nội dung nào.
- **10 file có sẵn** được sửa: 6 file chỉ thêm dòng mới; 10 dòng gốc bị đổi đều là thay đổi bắt buộc (trạng thái version/milestone trong `README.md` và `docs/README.md`, một dòng quy ước ngôn ngữ trong `CLAUDE.md`, và việc đổi số "3 quy tắc" thành "5" cùng đánh số lại trong `docs/ai/`).
- **3 file mới:** `defensive.h`, `test_harness.h`, `tests/1_learning/README.md`.
- **0 file bị mất.**

## Điều bạn cần biết

- **Ngôn ngữ Technical Note:** tôi giữ `notes/*.md` bằng tiếng Anh (bằng chứng portfolio), chỉ README viết tiếng Việt. Muốn đổi thì nói tôi.
- **Link hỏng có sẵn:** có 31 link hỏng sẵn từ trước, tôi để nguyên. Phần lớn là link tới placeholder của sprint tương lai theo quy ước. Riêng `notes/sprint-0.md` không có file lẫn placeholder tương ứng (chỉ có `sprint-0_prompt_docker_engine.md`); bạn quyết định đổi tên file hay sửa link.
- **Câu gốc trong `docs/README.md`:** "đã hoàn thành ở Milestone 0.2" cho `EMBEDDED_C_MASTERY_GUIDE.md` được để nguyên; câu đó chỉ đúng sau khi bạn làm xong milestone.
- **Cần upload lại:** `CLAUDE_PROJECT_INSTRUCTIONS.md` và `ELDMP_AI_MENTOR_PROTOCOL.md` đã đổi, hãy upload lại vào Claude Project knowledge.
- **Chưa làm (cần bạn quyết định):** đổi tên macro `SET_BIT` trước Sprint 3, vì header STM32 định nghĩa tên này theo mask.

## Việc còn lại là của bạn

Làm theo `src/learning/README.md`, Bước 0 đến Bước 10.

- **Quan trọng nhất là Bước 0:** chạy trên VM ARM64. Nếu GCC 15 phát sinh warning mới, hãy gửi nguyên văn để tôi sửa.
- **Sau đó:** điền *Time Spent → Actual* trong note, commit và tag `v0.0.2`.
- **Số đo trong note** đến từ x86-64 và AArch64 qua QEMU, nên cần đối chiếu lại trên VM.

**Còn 1 đến 2 lần trao đổi:** báo kết quả Bước 0 trên VM, rồi buổi kiểm tra cuối sprint (Bước 10). Nếu Bước 0 sạch ngay thì chỉ còn buổi kiểm tra.
