# Sprint Learning — Embedded C Fundamentals

## Problem (Vấn Đề)
Register, interrupt and DMA code (Sprint 3 onward) fails in ways that ordinary C testing hides: the compiler caches a hardware register, an ISR and the main loop corrupt shared state, a shift overflows. This sprint rebuilds that foundation as measured experiments plus reusable, tested code, before any production module depends on it.

## Expected Outcome (Kỳ Vọng)
Five compilable exercises (`src/learning/practice/`), a shared library (`src/common/`: bit macros, status codes, defensive helpers, a ring buffer) and unit tests (`tests/1_learning/`), all warning-free under `-Wall -Wextra`, with `volatile`, undefined behaviour and defensive coding explained by evidence rather than by assertion.

## What Actually Happened (Thực Tế)
Everything passed on the first run of each tool, which proved little. Deliberately breaking the code, then running it under different tools, produced the real lessons:

- **The ring buffer in guide §5.1 is racy.** It keeps a `count` that the ISR increments and `main` decrements; each is a load-add-store. Replaying one unlucky interrupt (exercise 05, A) leaves `count = 4` while 5 bytes are stored, and the producer later overwrites an unread byte.
- **x86-64 hid a memory-ordering bug.** Weakening acquire/release to relaxed in the new buffer left every test green; ThreadSanitizer reported a data race in `circular_buffer_pop`. x86's strong ordering masks what ARM may not.
- **GCC diagnosed the pitfalls being demonstrated:** `-Wsign-compare` (comparing `~x` of a `uint8_t`), `-Wstringop-truncation` (`strncpy`), `-Wsizeof-array-argument` (`sizeof` of an array parameter).
- **POSIX functions are not ISO C:** under strict `-std=c11`, `strnlen` broke `defensive.h` and `sbrk`/`usleep` broke two exercises; found only by a compiler/standard matrix. The library now avoids `strnlen`; the Linux-only exercises declare `_DEFAULT_SOURCE`.
- **ST's CMSIS headers (`stm32f4xx.h`, `stm32h7xx.h`) define `SET_BIT(REG, BIT)` by mask**; the guide's `SET_BIT(reg, n)` takes a bit number. Together, `SET_BIT(reg, 5)` would silently set bits 0 and 2.
- **Static analysis found what no test could.** `clang-tidy` reported a global interrupt-vector table still pointing at stack variables after the function returned (a dangling pointer, nothing dereferenced it yet), and a test that would have crashed instead of failing on a NULL string. Both fixed; the command now runs clean and was confirmed to catch the dangling table when it is re-introduced.
- Three errors in the experiments themselves were caught by their own self-checks: a fragmentation test that counted a block merged into the heap top, a wrong byte count in exercise 05, and a `volatile` experiment that hangs under TSan (it does not deliver signal handlers into a pure busy-wait; the exercise now skips itself there).

## Root Cause / How to Fix (Giải Pháp)
`volatile` stops the compiler from caching an access; it does not make a read-modify-write atomic. The fix is structural: free-running `head` (written only by the producer) and `tail` (only by the consumer), publishing with release/acquire, power-of-two capacity so `& mask` replaces a modulo and the counters wrap consistently. Tests avoid `assert()` (removed by `NDEBUG`, guide §6.4) and were validated by mutation: five deliberate bugs, all caught. The SET_BIT clash is guarded by an `#error` in `macros.h`; renaming is a Sprint 3 decision.

## Lessons Learned (Bài Học)
- Passing tests prove little until they have been made to fail. Mutate, then trust.
- Concurrency correctness needs a race detector and a weakly-ordered target, not only a green run on x86.
- Treat compiler warnings as lessons; each one above named a real pitfall. Re-run the whole matrix (gcc and clang; Debug, Release, ASan+UBSan, TSan) after every refactor: one tidy-up left helpers unused and broke only the TSan build.
- Verify every claim by experiment. Measured (GCC 13, `-O2`; x86-64, AArch64, Cortex-M4): reading a register twice compiles to two loads with `volatile`, one without; writing it twice keeps two stores, or only the last. The ring buffer compiles to about 600 bytes of code for Cortex-M0/M4/M7 at `-Os` and needs no `libatomic`.
- Stack grows downward (48-byte frames for the probe function, x86-64, `-O0`); glibc serves a 4 MiB `malloc` by `mmap`, so "the heap" is not one region.

All figures were measured on x86-64 GCC 13 with an AArch64 run under QEMU user-mode; re-run on the target VM before quoting them.

## References Used (Tài Liệu Tham Khảo)
- `docs/learning/EMBEDDED_C_MASTERY_GUIDE.md`: chapters 1–6.
- Linux `include/linux/bitops.h` and `bits.h`: `GENMASK` with compile-time argument check; `set_bit()` is atomic, `__set_bit()` is not; kernel `Makefile` builds with `-fno-strict-aliasing` and `-fno-strict-overflow`.
- FreeRTOS `list.c`: circular doubly linked list closed by a sentinel `xListEnd` (`xItemValue = portMAX_DELAY`), so insertion has no NULL or empty-list special cases.
- STMicroelectronics `cmsis_device_f4` / `cmsis_device_h7`: mask-based `SET_BIT`/`READ_BIT`.

## Time Spent
- Planned: 2–3 weeks (roadmap)
- Actual: to be filled in by the author at sprint end
- Reason for variance: n/a

## Commits
`git log v0.0.1..v0.0.2 --oneline`
