# notes — Ghi Chú Kỹ Thuật Theo Sprint

Mỗi sprint có **một** ghi chú kỹ thuật ngắn. Đây không phải nhật ký làm việc — nó là **bằng chứng bạn đã học được gì**: vấn đề gặp phải, điều bạn tưởng và điều thực sự xảy ra, nguyên nhân gốc, và bài học. Với portfolio, đây là phần giúp người đọc tin rằng bạn hiểu chứ không chỉ chép code.

## Vì sao phải viết (Ý nghĩa)

- **Định nghĩa Done của roadmap:** một sprint chưa xong nếu chưa có note (xem `Definition of Done` chung).
- **Phỏng vấn:** "Kể một lỗi khó bạn từng debug" — câu trả lời nằm sẵn ở mục *What Actually Happened* và *Root Cause*.
- **Chống học vẹt:** buộc phải viết *vì sao* thay vì chỉ *cái gì*.

## Viết thế nào

1. Sao chép [`_SPRINT_TEMPLATE.md`](_SPRINT_TEMPLATE.md) thành `sprint-N.md` (hoặc đổi tên placeholder `.sprint-N.md` bằng cách bỏ dấu chấm đầu tên — xem quy ước trong `CLAUDE.md`).
2. Điền đủ các mục: **Problem → Expected Outcome → What Actually Happened → Root Cause / How to Fix → Lessons Learned → References Used → Time Spent → Commits**.
3. Độ dài: **300–600 từ** mỗi sprint (riêng Sprint Learning: 500–800 từ theo roadmap).
4. Viết khi các chi tiết còn mới, **dựa trên kết quả đo thật**; không ghi con số bạn chưa tự kiểm chứng.
5. Khi code thay đổi làm một note lạc hậu, **cập nhật lại note đó** — không để note lệch với code.
6. Note viết bằng **tiếng Anh** (là bằng chứng portfolio cho người tuyển dụng); README hướng dẫn trong repo viết bằng tiếng Việt.

## Danh mục

| Note | Sprint / Milestone | Trạng thái |
|---|---|---|
| [`sprint-0_prompt_docker_engine.md`](sprint-0_prompt_docker_engine.md) | Milestone 0.1 — dựng môi trường | Prompt/ghi chú làm việc, không theo template |
| [`sprint-learning.md`](sprint-learning.md) | **Milestone 0.2** — Ôn Embedded C | Đã viết; cần bạn điền *Time Spent → Actual* và đối chiếu số đo trên VM |
| `sprint-1.md` … `sprint-16.md` | Sprint 1–16 | Placeholder rỗng (tên bắt đầu bằng dấu chấm) — viết khi sprint tương ứng bắt đầu |

## Đọc thêm

- Cách làm Milestone 0.2 từng bước: [`src/learning/README.md`](../src/learning/README.md)
- Index tài liệu: [`docs/README.md`](../docs/README.md)
