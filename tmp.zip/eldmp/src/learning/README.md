# src/learning — Thực Hành Embedded C (Milestone 0.2 / Sprint Learning)

Tài liệu này là **hướng dẫn thực hiện** Milestone 0.2: bạn cần làm gì, theo thứ tự nào, vì sao phải làm, và kết quả có ý nghĩa gì với các sprint sau.

- Tài liệu học: [`docs/learning/EMBEDDED_C_MASTERY_GUIDE.md`](../../docs/learning/EMBEDDED_C_MASTERY_GUIDE.md)
- Ghi chú kỹ thuật của sprint: [`notes/sprint-learning.md`](../../notes/sprint-learning.md)
- Thư viện dùng chung mà các bài tập sử dụng: [`src/common/`](../common/README.md)
- Unit test: [`tests/1_learning/`](../../tests/1_learning/README.md)

---

## 1. Milestone 0.2 để làm gì (Ý nghĩa)

Từ Sprint 3 trở đi, bạn viết code ghi thẳng vào thanh ghi, xử lý ngắt và DMA. Ở đó có những lỗi mà việc "chạy thử thấy đúng" **không bao giờ lộ ra**:

| Lỗi | Vì sao khó thấy | Bài học ở sprint này |
|---|---|---|
| Compiler cache giá trị thanh ghi | Chỉ xảy ra khi bật tối ưu (`-O2`) | Bài 02 — `volatile` |
| ISR và main cùng ghi một biến | Hiếm khi xảy ra, không tái hiện được | Bài 05 — ring buffer |
| Shift tràn, đọc không căn lề | Trên PC thường "chạy được", trên MCU thì fault | Bài 03, 04 |
| Macro cùng tên khác nghĩa với header hãng | Compile được, chạy sai | `macros.h` — xem [`src/common/README.md`](../common/README.md) |

Vì vậy sprint này **không** viết thêm tính năng. Nó biến từng khái niệm trong guide thành một **thí nghiệm đo được** và một **đoạn code có test**, trước khi bất kỳ module nào phụ thuộc vào chúng.

**Lab hay Ship (quan trọng):**
- `src/learning/practice/` = **Lab**: thử nghiệm, đọc kết quả, sửa tới đâu cũng được. Không module nào được phụ thuộc vào đây.
- `src/common/` = **Ship**: code dùng lại, có unit test, các sprint sau include vào.

---

## 2. Bản đồ: chương guide → bài tập → code dùng chung → test

| Chương guide | Bài thực hành (Lab) | Code dùng chung (Ship) | Test |
|---|---|---|---|
| 1. Memory layout | `practice/01_memory_layout.c` | — | tự kiểm tra (exit code) |
| 2. `volatile`, `const`, `static` | `practice/02_volatile_example.c` | `types.h` (`REG_RW`, `REG_RO`) | tự kiểm tra + xem mã máy |
| 3. Con trỏ, căn lề, callback | `practice/03_pointer_arithmetic.c` | `defensive.h` (`eldmp_load_*`) | `test_defensive_patterns.c` |
| 4. Phép toán bit | `practice/04_bitwise_operations.c` | `macros.h` | `test_bit_macros.c` |
| 5. Cấu trúc dữ liệu | `practice/05_circular_buffer.c` | `circular_buffer.h/.c` | `test_circular_buffer.c` |
| 6. Lập trình phòng thủ | (xuyên suốt 01–05) | `error_codes.h`, `defensive.h` | `test_defensive_patterns.c` |

Mỗi bài tập in ra những gì nó đo, rồi kết thúc bằng `=== all checks passed ===` (exit code 0) hoặc `CHECKS FAILED` (exit code 1) — nên `ctest` cũng chạy được chúng.

---

## 3. Việc bạn cần làm — từng bước

> **An toàn trước khi thí nghiệm:** các mục **"Tự thử"** bên dưới có sửa file. Sau khi hoàn tất Bước 0, chạy `git add -A` để lưu bản gốc vào staging. Hoàn tác **một** file bằng `git checkout -- <file>`. Tuyệt đối không chạy `git checkout` khi chưa `git add` — nó khôi phục từ index, và với các file vừa đổi tên từ `.X` thì index đang là file **rỗng**, bạn sẽ mất nội dung.

> **Cách học trong mỗi bước (Socratic):** *trước khi chạy*, hãy viết ra giấy dự đoán của bạn; *sau khi chạy*, so sánh. Dự đoán sai là phần có giá trị nhất — nó chỉ ra mental model của bạn lệch ở đâu.

### Bước 0 — Dựng và xác nhận môi trường

```bash
cd ~/eldmp
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug -DELDMP_WERROR=ON
cmake --build .
ctest --output-on-failure
```

- **Tại sao:** toàn bộ kết quả trong repo được kiểm chứng trên x86-64 (GCC 13, clang 18) và AArch64 qua QEMU — **chưa** trên VM Ubuntu 26.04 ARM64 của bạn với compiler mới hơn. Bước này xác nhận bạn tái hiện được kết quả.
- **Kết quả mong đợi:** `100% tests passed, 0 tests failed out of 8` (khoảng 2 giây), không có warning.
- **Ý nghĩa:** `-DELDMP_WERROR=ON` biến mọi warning thành lỗi — đây là cổng chất lượng của roadmap ("zero warning dưới `-Wall -Wextra`").
- **Nếu có lỗi/warning:** copy nguyên văn thông báo gửi lại để sửa. Compiler mới (GCC 15) có thể thêm cảnh báo mới; đây chính là thứ cần biết.

### Bước 1 — Memory layout (bài 01)

1. Đọc guide chương 1.
2. **Dự đoán:** stack tăng lên hay giảm xuống theo địa chỉ? Một lần gọi hàm tốn bao nhiêu byte? `malloc(4 MiB)` nằm gần hay xa `malloc(16)`?
3. Chạy: `./build/src/learning/learning_01_memory_layout`
4. Xem kết quả: bảng địa chỉ đã sắp xếp (`.text` → `.rodata` → `.data` → `.bss` → heap → stack), kích thước frame, thí nghiệm fragmentation.
5. Chạy tiếp: `size build/src/learning/learning_01_memory_layout` và `nm -n build/src/learning/learning_01_memory_layout | grep -E ' (g_data|g_bss|g_rodata|code_marker)$'` — đối chiếu từng symbol với section.
6. **Tự thử:** thêm một mảng toàn cục `int big[100000];` rồi chạy `size` — con số nào thay đổi (`.bss`)? File thực thi có to lên không? Thêm `= {1}` thì sao?

- **Tại sao:** trên MCU, `.data` tốn **cả Flash lẫn RAM** (giá trị khởi tạo nằm ở Flash, được copy sang RAM lúc boot) còn `.bss` chỉ tốn RAM; `const` có thể nằm hẳn ở Flash.
- **Ý nghĩa:** ở Sprint 3 bạn sẽ đọc linker script và file `startup`; hiểu năm vùng này là điều kiện để hiểu vì sao boot code phải copy `.data` và xoá `.bss`.
- **Lưu ý:** địa chỉ và kích thước frame khác nhau theo máy; chiều tăng của stack và thứ tự các vùng thì không.

### Bước 2 — `volatile` (bài 02)

1. Đọc guide chương 2.1–2.2.
2. **Dự đoán:** vòng lặp `while (!flag) {}` mà flag được signal handler đặt — nếu `flag` là `int` thường và bật `-O2`, chuyện gì xảy ra?
3. Chạy: `./build/src/learning/learning_02_volatile_example`
4. Quan sát dòng `plain int flag : HUNG …` và `volatile sig_atomic_t : loop ended`. (Chương trình chạy mỗi biến trong một process con và tự kill sau 1,5 giây nên an toàn.)
5. **Xem mã máy** (bằng chứng, không phải lời nói):
   ```bash
   gcc -O2 -S -Isrc/common/include src/learning/practice/02_volatile_example.c -o - \
     | awk '/^read_twice_(plain|volatile):/,/\.size/'
   gcc -O2 -S -Isrc/common/include src/learning/practice/02_volatile_example.c -o - \
     | awk '/^write_twice_(plain|volatile):/,/\.size/'
   ```
   Đếm lệnh load/store. Làm lại với `-O0`: kết quả thay đổi thế nào? Làm lại với `arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -O2 -S`.
6. **Tự thử:** xoá dòng `set_source_files_properties(...)` ở cuối `src/learning/CMakeLists.txt`, build lại, chạy — vì sao bây giờ biến `int` thường "chạy được"? Hoàn tác bằng `git checkout -- src/learning/CMakeLists.txt`.

- **Tại sao:** compiler được phép giả định không ai khác ghi vào biến của bạn. Với thanh ghi phần cứng hoặc biến do ISR đổi, giả định đó sai.
- **Ý nghĩa:** `volatile` chỉ nói "mỗi lần truy cập phải thật sự xảy ra, đúng thứ tự". Nó **không** làm `x++` nguyên tử. Hai câu này là nền của cả bài 05.
- **Phần B của bài** dựng một "UART" bằng RAM với `REG_RW`/`REG_RO` và các `_Static_assert` kiểm tra offset — đây chính là mẫu bạn sẽ gặp trong header của STM32. `REG_RO` làm cho việc ghi vào thanh ghi trạng thái thành **lỗi biên dịch**, không phải lỗi runtime.

### Bước 3 — Con trỏ, căn lề, callback (bài 03)

1. Đọc guide chương 3.
2. **Dự đoán:** `sizeof(struct {uint8_t; uint32_t; uint8_t;})` là bao nhiêu? Sắp xếp lại field thì còn bao nhiêu?
3. Chạy: `./build/src/learning/learning_03_pointer_arithmetic` — đọc từng dòng `[ ok ]`, mỗi dòng là một quy tắc.
4. **Tự thử:** trong bài, thêm field `uint16_t` vào `padded_t` và dự đoán `sizeof` trước khi biên dịch (`_Static_assert` sẽ cho bạn biết ngay nếu sai).

- **Tại sao:** đọc `uint32_t` qua con trỏ ép kiểu ở địa chỉ lẻ là **undefined behavior** (và là bus fault trên một số lõi ARM). `eldmp_load_u32_le()` ghép từng byte nên đúng ở mọi căn lề và nói rõ thứ tự byte.
- **Ý nghĩa:** Sprint 13 (protocol Linux↔MCU) cần chính xác điều này — mọi trường trong gói tin phải có endian tường minh.
- **Bảng vector ngắt** trong bài mô phỏng đúng cách NVIC dispatch: có handler mặc định, kiểm tra chỉ số, và con trỏ `context` để không phải dùng biến toàn cục. Cuối bài bảng được xoá sạch (`irq_unregister_all`) vì nó trỏ vào biến cục bộ — để lại sẽ thành **dangling pointer**, một lỗi do `clang-tidy` phát hiện trong chính bài này.

### Bước 4 — Phép toán bit (bài 04)

1. Đọc guide chương 4.
2. **Dự đoán:** với `uint8_t a = 0xAC`, `~a` bằng bao nhiêu? Có phải `0x53` không?
3. Chạy: `./build/src/learning/learning_04_bitwise_operations`
4. Chú ý ba mẫu: (1) trường 2 bit `MODER` đặt cho từng chân mà không đụng chân khác; (2) `BSRR` set và reset **trong một lần ghi**; (3) các mẹo bit được kiểm tra vét cạn.
5. **Tự thử:** sửa `GENMASK(h, l)` trong `src/common/include/macros.h` sai đi một đơn vị (đổi `31U` thành `30U`) rồi build và chạy `ctest` — công cụ nào phát hiện lỗi **đầu tiên**: compiler, `test_bit_macros`, hay bài 04? Hoàn tác bằng `git checkout -- src/common/include/macros.h` (đã `git add -A` ở Bước 0).

- **Tại sao:** `~a` của một `uint8_t` là `int` (`0xFFFFFF53`), vì phép toán số học luôn nâng lên `int` trước. So sánh nó với `0x53` cho kết quả sai mà không cảnh báo (GCC chỉ cảnh báo khi so sánh trực tiếp với hằng).
- **Ý nghĩa:** `WRITE_MASK`/`FIELD_PREP` là cách ghi một trường nhiều bit mà **không** làm hỏng các bit lân cận — thao tác phổ biến nhất khi cấu hình peripheral. `BSRR` cho thấy phần cứng tự thiết kế để tránh đọc-sửa-ghi.

### Bước 5 — Ring buffer (bài 05)

1. Đọc guide chương 5.1 **và để ý biến `count`**.
2. **Dự đoán:** nếu ISR làm `count++` còn main làm `count--`, và một ngắt xen vào giữa lệnh `count--` của main, kết quả là gì?
3. Chạy: `./build/src/learning/learning_05_circular_buffer`
4. Thí nghiệm A tái hiện đúng tình huống đó **một cách tất định** (không cần thread): dòng `count says 4, indices say 5 bytes are stored` và sau đó byte số 2 chưa được đọc nhưng đã bị ghi đè.
5. Thí nghiệm B vẽ bộ đệm 16 ô với `head`/`tail` — theo dõi vì sao chúng chỉ tăng mà không quay về 0.
6. Thí nghiệm C chạy hai thread thật, 200.000 byte qua 16 ô.
7. **Chạy dưới TSan** (xem Bước 7).

- **Tại sao:** ví dụ trong guide có `count` bị hai bên cùng ghi. Giải pháp không phải thêm `volatile` mà là **bỏ bên ghi thứ hai**: `head` chỉ producer ghi, `tail` chỉ consumer ghi.
- **Ý nghĩa:** UART RX ở Sprint 3, bộ đệm log ở Sprint 1, hàng đợi trong protocol ở Sprint 13 đều dùng khuôn này. ISR **không bao giờ được block** khi đầy: nó trả về `ELDMP_ERR_NO_SPACE` và để người gọi quyết định bỏ byte và đếm.

### Bước 6 — Đọc code sản xuất thật (bắt buộc theo DoD)

Roadmap yêu cầu đọc ít nhất một đoạn source thật. Gợi ý và việc cần tìm — mỗi mục 15–20 phút:

| Source | Tìm gì | Liên hệ |
|---|---|---|
| Linux [`include/linux/bits.h`](https://github.com/torvalds/linux/blob/master/include/linux/bits.h) và `include/vdso/bits.h` | `BIT(nr)`, `GENMASK` — chú ý nó kiểm tra tham số lúc compile | `macros.h` mô phỏng hai macro này |
| Linux [`include/linux/bitops.h`](https://github.com/torvalds/linux/blob/master/include/linux/bitops.h) và `asm-generic/bitops/generic-non-atomic.h` | `set_bit()` (nguyên tử) so với `__set_bit()` (không) | Lý do `SET_BIT` của bạn không nguyên tử và phải ghi rõ |
| [`Makefile`](https://github.com/torvalds/linux/blob/master/Makefile) gốc của kernel | Tìm `-fno-strict-aliasing` | Kernel phải tắt tối ưu theo strict aliasing; code mới của bạn thì không nên dựa vào đó (dùng `memcpy`) |
| FreeRTOS [`list.c`](https://github.com/FreeRTOS/FreeRTOS-Kernel/blob/main/list.c) | Danh sách vòng nối đôi khép kín bằng nút canh `xListEnd` (giá trị `portMAX_DELAY`), `vListInsertEnd`, `uxListRemove` | Nút canh loại bỏ trường hợp NULL/danh sách rỗng — cùng tinh thần "bỏ trường hợp đặc biệt" như ring buffer |
| ST [`stm32h7xx.h`](https://github.com/STMicroelectronics/cmsis_device_h7/blob/master/Include/stm32h7xx.h) | Tìm `define SET_BIT` | Đây là nguồn của **bẫy xung đột tên** ở Sprint 3 |

Ghi lại 2–3 câu bạn học được vào `notes/sprint-learning.md` (mục *References Used*).

### Bước 7 — Kiểm tra như CI sẽ làm

```bash
# Sanitizer bộ nhớ + hành vi không xác định
cmake -S . -B build/asan -DELDMP_WERROR=ON -DCMAKE_BUILD_TYPE=Debug \
      -DCMAKE_C_FLAGS="-fsanitize=address,undefined -fno-sanitize-recover=undefined"
cmake --build build/asan && (cd build/asan && ctest --output-on-failure)

# Sanitizer cho thread — quan trọng nhất với ring buffer
cmake -S . -B build/tsan -DELDMP_WERROR=ON -DCMAKE_BUILD_TYPE=Debug \
      -DCMAKE_C_FLAGS="-fsanitize=thread"
cmake --build build/tsan && (cd build/tsan && ctest --output-on-failure)
```

- **Vì sao đặt trong `build/`:** `.gitignore` chỉ chặn thư mục `build/`. Nếu tạo `build-asan/` ở gốc repo, `git add -A` ở Bước 9 sẽ commit nhầm file biên dịch.

- **Tại sao TSan:** test chạy xanh trên x86 **không chứng minh** đúng trên ARM. x86 có thứ tự bộ nhớ mạnh nên che mất lỗi ordering. Khi hạ acquire/release xuống relaxed, mọi test vẫn pass nhưng TSan báo `data race` ngay — đó là bằng chứng duy nhất.
- **Bài 02 tự bỏ qua thí nghiệm A dưới TSan:** TSan không đưa signal handler vào vòng busy-wait thuần, nên biến `volatile` cũng "treo" — đây là giới hạn của công cụ, đã đo thực tế, không phải lỗi của `volatile`.
- Có `valgrind` trong dev container: `valgrind -q --leak-check=full ./build/tests/1_learning/test_defensive_patterns`.

### Bước 8 — Phân tích tĩnh (tuỳ chọn, nhưng nên làm)

Test động chỉ thấy lỗi **xảy ra** trong lần chạy; phân tích tĩnh đọc code và tìm lỗi **có thể xảy ra**. Lỗi dangling pointer ở bài 03 là do công cụ này phát hiện — không test nào bắt được nó.

```bash
clang-tidy -quiet \
  -checks='-*,bugprone-*,clang-analyzer-*,-bugprone-easily-swappable-parameters,-clang-analyzer-security.insecureAPI.DeprecatedOrUnsafeBufferHandling' \
  src/common/src/circular_buffer.c src/common/src/common.c src/learning/practice/*.c tests/1_learning/*.c \
  -- -std=gnu11 -Isrc/common/include -Itests/1_learning

cppcheck --enable=warning,style,performance,portability --inconclusive --std=c11 \
  -Isrc/common/include -Itests/1_learning --quiet \
  src/common/src/circular_buffer.c src/common/src/common.c src/learning/practice/*.c tests/1_learning/*.c
```

**`clang-tidy` phải sạch** (không in gì). Hai check bị loại có chủ đích: `easily-swappable-parameters` là ý kiến về phong cách; `DeprecatedOrUnsafeBufferHandling` đòi dùng `memcpy_s` của C11 Annex K, thứ glibc không có. (Lệnh không chạy `cli.c`/`version.c` vì chúng cần `version.h` do CMake sinh ra trong `build/`.)

**`cppcheck` sẽ in một số cảnh báo — đây là kết quả đã biết, không phải lỗi:**

| Cảnh báo | Ở đâu | Vì sao không phải lỗi |
|---|---|---|
| `redundantAssignment`, `duplicateAssignExpression` | `02_volatile_example.c` | Chính là thứ bài đang minh hoạ: ghi hai lần, đọc hai lần |
| `knownConditionTrueFalse` | `03`, `04` | Các câu kiểm tra dùng hằng số nên công cụ tự tính ra "luôn đúng". Với `rotl32`/`bswap32` nó còn tính **sai** vì không cắt kết quả về 32 bit; chương trình thật đã chạy đúng trên 3 kiến trúc và dưới UBSan |
| `duplicateExpression` | `04` (dòng `WRITE_MASK` + `FIELD_PREP`) | Mask được áp dụng hai lần (một trong `FIELD_PREP`, một trong `WRITE_MASK`); vô hại, optimizer loại bỏ |
| `variableScope`, `unusedStructMember` | `tests/1_learning` | Gợi ý phong cách; struct không dùng thành viên là cố ý (kiểm tra `ARRAY_SIZE`) |

### Bước 9 — Hoàn tất ghi chú, commit, tag

1. Mở `notes/sprint-learning.md`, điền **Time Spent → Actual** (chỉ bạn biết) và lý do chênh lệch nếu có.
2. Với mỗi con số trong note (kích thước frame, số lệnh load/store…), đối chiếu với kết quả **trên VM của bạn**; sửa nếu khác. Con số trong note do tôi đo trên x86-64 GCC 13 và AArch64 qua QEMU.
3. Commit và tag theo quy ước repo:
   ```bash
   git add -A
   git commit -m "sprint 0, milestone 0.2 >> embedded C review: shared utils, practice, unit tests"
   git tag -a v0.0.2 -m "sprint 0, milestone 0.2 >> release v0.0.2"
   git push origin v0.0.2        # khi bạn đã sẵn sàng đẩy lên remote
   ```

### Bước 10 — Tự kiểm tra trước khi sang Sprint 1 (Sprint End Gate)

Trả lời **không nhìn tài liệu**, bằng lời của bạn. Nếu vướng ở câu nào, quay lại bước tương ứng:

1. Vì sao `volatile` không làm `count++` an toàn giữa ISR và main? *(Bước 2, 5)*
2. Vì sao capacity của ring buffer phải là lũy thừa của 2, và `head`/`tail` có tràn không? *(Bước 5)*
3. Vì sao test pass trên x86 chưa chứng minh đúng trên ARM? Công cụ nào bắt được? *(Bước 7)*
4. `SET_BIT(reg, 5)` biến thành gì nếu header STM32 định nghĩa nó theo mask? *(Bước 4, 6)*
5. Vì sao `b[3] << 24` là undefined behavior khi `b[3] >= 0x80`? Sửa thế nào? *(Bước 3)*
6. `.data` và `.bss` khác nhau thế nào về Flash? Vì sao boot code phải copy `.data`? *(Bước 1)*
7. Vì sao ISR không được block khi buffer đầy? Nó nên làm gì? *(Bước 5)*
8. Con trỏ truyền vào bảng vector toàn cục mà trỏ vào biến cục bộ sẽ gây chuyện gì? *(Bước 3)*

---

## 4. Checklist Definition of Done (đánh dấu khi xong)

- [ ] Build với `-DELDMP_WERROR=ON` sạch **trên VM của bạn**, không warning
- [ ] `ctest` pass 8/8 trên VM của bạn
- [ ] Đã chạy ASan+UBSan và TSan, đều pass
- [ ] Đã xem mã máy của bài 02 và đếm được load/store (khớp với note)
- [ ] Đã đọc ít nhất một đoạn source thật ở Bước 6 và ghi vào note
- [ ] Đã điền **Time Spent → Actual** trong `notes/sprint-learning.md`
- [ ] Đã tự trả lời được 8 câu ở Bước 10
- [ ] Đã commit và tạo tag `v0.0.2`
- [ ] Đã cập nhật dòng "Sprint hiện tại" trong `CLAUDE.md` khi chuyển sang Sprint 1

---

## 5. Sự cố thường gặp

| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Bài 02 báo `plain int flag : loop ended` | Build ở `-O0` hoặc compiler không hoist lệnh load | Đây là kết quả hợp lệ, **không phải lỗi**; xem Bước 2 mục "Tự thử" |
| Bài 02 hiện `[SKIP] ThreadSanitizer build` | Đang build bằng `-fsanitize=thread` | Bình thường — chạy bản build thường để thấy thí nghiệm A |
| `#error ... already defined (vendor header?)` | Một header khác đã định nghĩa `SET_BIT`… | Xem mục 4 trong [`src/common/README.md`](../common/README.md) |
| Warning mới khi dùng GCC 15 / clang mới | Compiler mới có thêm check | Sửa trong code, **không** tắt bằng pragma; gửi lại thông báo để cập nhật repo |
| `ctest` báo `Not Run` | Chưa build, hoặc build lỗi | `cmake --build .` rồi chạy lại, đọc lỗi đầu tiên |
| Bài 01 in địa chỉ khác lần trước | ASLR | Bình thường; thứ tự các vùng mới là điều cần quan sát |

## 6. Lưu ý nền tảng

- Các bài tập chạy trên **Linux hosted** (dùng `fork`, signal, `pthread`, `sbrk`). Riêng **thư viện** mà chúng dùng còn biên dịch được cho Cortex-M0/M4/M7 ở chế độ freestanding.
- Kích thước con trỏ là 8 byte trên VM của bạn nhưng **4 byte** trên Cortex-M; `long` cũng vậy. Dùng kiểu có kích thước cố định (`uint32_t`) cho mọi thứ chạm tới phần cứng hoặc định dạng dữ liệu.
- Bài 02 được biên dịch với `-O2` có chủ đích (xem `CMakeLists.txt` trong thư mục này).
- Các bài dùng hàm POSIX/BSD (`sbrk`, `usleep`, `pthread`…) khai báo `#define _DEFAULT_SOURCE` ở đầu file. Nhờ đó chúng biên dịch được cả với `-std=c11` nghiêm ngặt, không phụ thuộc dialect mặc định của compiler (GCC 15 mặc định `gnu23`, GCC 13 là `gnu17`; CMake của dự án ghim `gnu11`).
