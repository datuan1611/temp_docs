/*
 * 03_pointer_arithmetic.c - Pointers, alignment and callbacks as used in firmware.
 *
 * Guide: chapter 3 (3.1 pointers, 3.2 void pointers and casts, 3.3 function
 *        pointers and callbacks, 3.4 alignment and padding) and 6.1 #5
 *        (unaligned access).
 * Type : Lab.
 *
 * Sections
 *   1. Pointer arithmetic scales by the element size; array-to-pointer decay
 *      loses the length; the three places `const` can go.
 *   2. Struct padding and alignment: the same fields in two orders, and a
 *      packed layout (what a wire format needs).
 *   3. Type punning and unaligned reads WITHOUT undefined behaviour (memcpy and
 *      byte-wise loads), plus an endianness probe.
 *   4. Function pointers: an interrupt vector table with a default handler and
 *      a context pointer - the shape of NVIC dispatch and of every callback API.
 *
 * Self-checks: exit code != 0 if any fails.
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "defensive.h"
#include "macros.h"
#include "types.h"

static int g_failures;

static void check(bool ok, const char *what)
{
    printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
    if (!ok) {
        g_failures++;
    }
}

/* ---- 1. Pointer arithmetic --------------------------------------------------- */
/* A parameter written `const uint32_t table[8]` is, by the language rules, exactly
 * `const uint32_t *table`: the 8 is ignored and sizeof gives the pointer size
 * (8 here, 4 on an MCU). GCC even warns (-Wsizeof-array-argument) if you write
 * sizeof(table) with the array spelling, so the pointer spelling is used here.
 * This is why every buffer API in this project takes a length. */
static size_t size_seen_by_callee(const uint32_t *table)
{
    return sizeof(table);
}

static void section_pointers(void)
{
    uint32_t words[4] = { 10, 20, 30, 40 };
    uint16_t halves[4] = { 1, 2, 3, 4 };
    const uint32_t *p = words;
    const uint16_t *q = halves;
    const uint32_t *last = &words[3];
    uint32_t value = 1;
    const uint32_t *ptr_to_const = &value;          /* data read-only, pointer movable   */
    uint32_t *const const_ptr = &value;             /* pointer fixed, data writable      */
    const uint32_t *const both = &value;            /* neither can change (flash tables) */

    printf("1. Pointer arithmetic\n");
    p++;
    q++;
    check((const uint8_t *)p - (const uint8_t *)words == 4, "uint32_t* ++ moves 4 bytes");
    check((const uint8_t *)q - (const uint8_t *)halves == 2, "uint16_t* ++ moves 2 bytes");
    check(*p == 20 && *(p + 2) == 40, "*(p + n) is the n-th element after p");
    check(last - words == 3, "pointer difference counts ELEMENTS (type ptrdiff_t), not bytes");
    check(sizeof(words) == 16U && ARRAY_SIZE(words) == 4U, "sizeof/ARRAY_SIZE see the real array");
    check(size_seen_by_callee(words) == sizeof(void *),
          "...but inside a callee the same array is only a pointer: the length is lost");

    *const_ptr = 5;
    check(value == 5 && *ptr_to_const == 5 && *both == 5, "const placement: three different promises");
    /* ptr_to_const[0] = 1;   error: assignment of read-only location
     * const_ptr = NULL;      error: assignment of read-only variable
     * both = NULL;           error                                            */
}

/* ---- 2. Padding and alignment ------------------------------------------------- */
typedef struct {            /* fields in "natural" order: padding appears */
    uint8_t  tag;           /* offset 0                                  */
    uint32_t value;         /* offset 4 (3 bytes of padding before it)   */
    uint8_t  flag;          /* offset 8, then 3 bytes of tail padding    */
} padded_t;

typedef struct {            /* same fields, largest first: no wasted bytes inside */
    uint32_t value;
    uint8_t  tag;
    uint8_t  flag;
} reordered_t;

typedef struct __attribute__((packed)) {   /* no padding: layout of a wire message */
    uint8_t  tag;
    uint32_t value;
    uint8_t  flag;
} packed_t;

_Static_assert(offsetof(padded_t, value) == 4U, "uint32_t must be 4-byte aligned");
_Static_assert(sizeof(padded_t) == 12U, "3 + 3 bytes of padding");
_Static_assert(sizeof(reordered_t) == 8U, "reordering removed the inner padding");
_Static_assert(sizeof(packed_t) == 6U, "packed = sum of the fields");

static void section_padding(void)
{
    printf("2. Struct padding (the same 3 fields)\n");
    printf("     natural order: sizeof=%zu  offsets: tag=%zu value=%zu flag=%zu\n",
           sizeof(padded_t), offsetof(padded_t, tag), offsetof(padded_t, value), offsetof(padded_t, flag));
    printf("     largest first: sizeof=%zu\n", sizeof(reordered_t));
    printf("     packed       : sizeof=%zu  (reading .value directly is an UNALIGNED access)\n", sizeof(packed_t));
    check(_Alignof(uint32_t) == 4U, "uint32_t needs 4-byte alignment (also on Cortex-M)");
    check(sizeof(reordered_t) < sizeof(padded_t), "field order alone saves RAM (matters in arrays of structs)");
    /* A (packed_t *) into a buffer then reading ->value would compile, and fault or be slow
     * on strict cores. For wire formats use explicit loads (section 3). */
}

/* ---- 3. Type punning and unaligned access ------------------------------------- */
static void section_punning(void)
{
    uint8_t wire[8] = { 0xAA, 0x78, 0x56, 0x34, 0x12, 0xBB, 0xCC, 0xDD };
    const float one = 1.0f;
    uint32_t bits = 0;
    uint32_t probe = 0x01020304U;
    uint8_t first_byte;
    uint32_t copied;

    printf("3. Punning and unaligned reads without undefined behaviour\n");
    /* ILLEGAL (strict aliasing, UB):  uint32_t bits = *(uint32_t *)&one;
     * The Linux kernel builds with -fno-strict-aliasing to survive this pattern;
     * new code should not rely on that. memcpy is the portable reinterpretation
     * and compiles to a single move. */
    memcpy(&bits, &one, sizeof(bits));
    check(bits == 0x3F800000U, "memcpy reinterprets float 1.0f as IEEE-754 bits 0x3F800000");

    /* ILLEGAL (alignment, UB):  *(uint32_t *)&wire[1]   - address is odd. */
    memcpy(&copied, &wire[1], sizeof(copied));
    check(eldmp_load_u32_le(&wire[1]) == 0x12345678U, "byte-wise load builds a little-endian value at an odd address");
    check(eldmp_load_u32_be(&wire[1]) == 0x78563412U, "same bytes read big-endian: the byte order is explicit");
    check(copied == eldmp_load_u32_le(&wire[1]) || copied == eldmp_load_u32_be(&wire[1]),
          "memcpy copy equals one of the two byte-wise interpretations (host byte order)");

    memcpy(&first_byte, &probe, 1);
    printf("     this CPU is %s-endian (first byte of 0x01020304 is 0x%02X)\n",
           first_byte == 0x04 ? "little" : "big", first_byte);
    check(first_byte == 0x04 || first_byte == 0x01, "endianness probe gave a sane answer");
}

/* ---- 4. Function pointers: an interrupt vector table ---------------------------- */
typedef void (*isr_fn_t)(void *context);

typedef struct {
    isr_fn_t handler;       /* NULL = nothing registered */
    void *context;          /* passed back to the handler: no globals needed */
} vector_entry_t;

enum { IRQ_COUNT = 8, IRQ_TIMER = 2, IRQ_UART = 5 };

static vector_entry_t g_vectors[IRQ_COUNT];
static unsigned g_spurious;

static void default_handler(void *context)
{
    UNUSED(context);
    g_spurious++;           /* a real default handler would log and/or reset */
}

static eldmp_status_t irq_register(unsigned irq, isr_fn_t handler, void *context)
{
    if (irq >= IRQ_COUNT || handler == NULL) {
        return ELDMP_ERR_INVALID_ARG;        /* never index the table out of range */
    }
    if (g_vectors[irq].handler != NULL) {
        return ELDMP_ERR_BUSY;               /* refuse silent replacement */
    }
    g_vectors[irq].handler = handler;
    g_vectors[irq].context = context;
    return ELDMP_OK;
}

/* The table is global, the contexts it points to are not: it must not outlive them.
 * Leaving entries pointing at dead stack variables is a dangling-pointer bug
 * even if nothing dereferences them yet (static analysers flag it, rightly). */
static void irq_unregister_all(void)
{
    memset(g_vectors, 0, sizeof(g_vectors));
}

static void irq_dispatch(unsigned irq)       /* what the CPU does on an interrupt */
{
    if (irq < IRQ_COUNT && g_vectors[irq].handler != NULL) {
        g_vectors[irq].handler(g_vectors[irq].context);
    } else {
        default_handler(NULL);
    }
}

static void timer_isr(void *context)         { ++*(unsigned *)context; }   /* context = counter */
static void uart_isr(void *context)          { *(unsigned *)context += 100U; }

static void section_function_pointers(void)
{
    unsigned ticks = 0;
    unsigned rx_events = 0;

    printf("4. Function pointers: interrupt vector table\n");
    check(irq_register(IRQ_TIMER, timer_isr, &ticks) == ELDMP_OK, "register timer ISR with its own counter");
    check(irq_register(IRQ_UART, uart_isr, &rx_events) == ELDMP_OK, "register UART ISR with a different context");
    check(irq_register(IRQ_TIMER, uart_isr, NULL) == ELDMP_ERR_BUSY, "double registration is rejected");
    check(irq_register(IRQ_COUNT, timer_isr, NULL) == ELDMP_ERR_INVALID_ARG, "out-of-range IRQ number is rejected");
    check(irq_register(0, NULL, NULL) == ELDMP_ERR_INVALID_ARG, "NULL handler is rejected");

    irq_dispatch(IRQ_TIMER);
    irq_dispatch(IRQ_TIMER);
    irq_dispatch(IRQ_UART);
    check(ticks == 2U && rx_events == 100U, "each ISR updated ITS OWN context");

    irq_dispatch(3);                         /* nothing registered */
    irq_dispatch(IRQ_COUNT + 40U);           /* garbage IRQ number */
    check(g_spurious == 2U, "unregistered / invalid IRQs go to the default handler, not to address 0");

    irq_unregister_all();                    /* ticks / rx_events are about to go out of scope */
    check(g_vectors[IRQ_TIMER].handler == NULL && g_vectors[IRQ_UART].context == NULL,
          "table cleared before the contexts die: no dangling pointers left behind");
}

int main(void)
{
    printf("=== 03 pointers, alignment, callbacks ===\n");
    section_pointers();
    section_padding();
    section_punning();
    section_function_pointers();
    printf("=== %s ===\n", g_failures == 0 ? "all checks passed" : "CHECKS FAILED");
    return g_failures == 0 ? 0 : 1;
}
