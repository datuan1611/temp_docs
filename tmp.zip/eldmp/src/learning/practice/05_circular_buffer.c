/*
 * 05_circular_buffer.c - A UART-RX style ring buffer, and why the obvious
 *                        design is broken.
 *
 * Guide: chapter 5.1 (circular buffer), 2.1 (volatile and ISR variables).
 * Type : Lab. The buffer under study is the Ship code in
 *        src/common/{include,src}/circular_buffer.*
 *
 * Experiments
 *   A. The "head + tail + shared count" design (the usual textbook version).
 *      One unlucky interrupt between the load and the store of `count--` loses
 *      an update. The interleaving is replayed step by step, deterministically,
 *      no threads needed: count drifts from the truth and the producer then
 *      overwrites a byte nobody has read.
 *   B. The ELDMP design: no shared count; head is written only by the producer,
 *      tail only by the consumer. A 16-byte buffer is filled, drained and
 *      wrapped while its free-running counters are printed.
 *   C. The same buffer between two real threads (producer = "ISR", consumer =
 *      main loop): 200 000 bytes through 16 slots, every byte checked.
 *
 * Self-checks: exit code != 0 if any fails.
 * Also run it under ThreadSanitizer (see src/learning/README.md): experiment C
 * is race-free by construction, and TSan proves it.
 */
/* POSIX/BSD functions (pthread, sched_yield) are not part of ISO C. This feature-test macro must come
 * before every #include so the file builds under strict -std=c11 as well as -std=gnu11. */
#define _DEFAULT_SOURCE

#include <pthread.h>
#include <sched.h>
#include <stdio.h>

#include "circular_buffer.h"

static int g_failures;

static void check(bool ok, const char *what)
{
    printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
    if (!ok) {
        g_failures++;
    }
}

/* ---- A. The shared-count design, and the interleaving that breaks it --------- */
#define NAIVE_CAP 8U

typedef struct {
    uint8_t data[NAIVE_CAP];
    volatile size_t head;     /* volatile fixes "the compiler caches it" ...       */
    volatile size_t tail;
    volatile size_t count;    /* ... but NOT "two writers": count++ / count-- are
                                 load, add, store - three separate steps          */
} naive_ring_t;

static bool naive_push(naive_ring_t *r, uint8_t v)   /* runs in the ISR */
{
    if (r->count >= NAIVE_CAP) {
        return false;
    }
    r->data[r->head] = v;
    r->head = (r->head + 1U) % NAIVE_CAP;
    r->count++;               /* ISR writes count */
    return true;
}

static void experiment_a(void)
{
    naive_ring_t r = { { 0 }, 0, 0, 0 };
    uint8_t v;
    uint8_t next = 7;
    size_t reg;               /* the CPU register main() uses for count-- */
    size_t really_stored;
    bool unread_byte_survived = false;
    size_t i;

    printf("A. Shared `count` written by both sides (replayed interleaving)\n");
    for (v = 1; v <= 5; v++) {
        naive_push(&r, v);                         /* bytes 1..5 stored, count = 5 */
    }

    /* main(): pop byte 1 ... */
    r.tail = (r.tail + 1U) % NAIVE_CAP;
    reg = r.count;                                 /* step 1: load count (5)        */
    naive_push(&r, 6);                             /* >>> interrupt fires HERE: count becomes 6 */
    reg = reg - 1U;                                /* step 2: 5 - 1 = 4             */
    r.count = reg;                                 /* step 3: store 4 -> the ISR's increment is gone */

    really_stored = (r.head + NAIVE_CAP - r.tail) % NAIVE_CAP;   /* bytes 2..6 = 5 */
    printf("     count says %zu, indices say %zu bytes are stored\n", r.count, really_stored);
    check(r.count == 4U && really_stored == 5U, "lost update: count is 1 lower than reality");

    while (naive_push(&r, next)) {                 /* producer believes it has room */
        next++;
    }
    for (i = 0; i < NAIVE_CAP; i++) {
        unread_byte_survived = unread_byte_survived || (r.data[i] == 2U);
    }
    printf("     producer kept pushing until count said full (last value %u)\n", (unsigned)(next - 1U));
    check(!unread_byte_survived, "byte 2 was never read yet is gone: overwritten - silent data loss");
    printf("     => the fix is not more `volatile`; it is removing the second writer.\n");
}

/* ---- B. The ELDMP ring buffer: counters, wrap-around ------------------------------ */
static void print_ring(const circular_buffer_t *cb, const char *label)
{
    size_t cap = circular_buffer_capacity(cb);
    size_t t_idx = cb->tail & cb->mask;
    size_t used = circular_buffer_count(cb);
    size_t i;

    printf("     %-26s head=%-3zu tail=%-3zu count=%-2zu |", label, cb->head, cb->tail, used);
    for (i = 0; i < cap; i++) {
        bool occupied = ((i - t_idx) & cb->mask) < used;

        putchar(occupied ? (char)cb->storage[i] : '.');
    }
    printf("|\n");
}

static void experiment_b(void)
{
    uint8_t mem[16];
    uint8_t out[16];
    circular_buffer_t cb;
    uint8_t sink = 0;

    printf("B. ELDMP ring buffer: free-running counters, index = counter & mask\n");
    check(circular_buffer_init(&cb, mem, sizeof(mem)) == ELDMP_OK, "16-byte buffer initialised");
    check(circular_buffer_init(&cb, mem, 12) == ELDMP_ERR_INVALID_ARG, "capacity 12 refused: not a power of two");
    (void)circular_buffer_init(&cb, mem, sizeof(mem));

    print_ring(&cb, "empty");
    check(circular_buffer_write(&cb, (const uint8_t *)"ABCDEFGHIJ", 10) == 10U, "wrote 10 bytes");
    print_ring(&cb, "after write 10");
    check(circular_buffer_read(&cb, out, 6) == 6U && out[0] == 'A' && out[5] == 'F', "read 6 bytes: A..F");
    print_ring(&cb, "after read 6");
    check(circular_buffer_write(&cb, (const uint8_t *)"KLMNOPQRSTUV", 12) == 12U,
          "wrote 12 more (4 + 12 = 16): the write wraps past the end of the array");
    print_ring(&cb, "after wrapping write");
    check(circular_buffer_is_full(&cb) && circular_buffer_push(&cb, 'Z') == ELDMP_ERR_NO_SPACE,
          "buffer is full (all 16 slots used) and push reports NO_SPACE");
    check(circular_buffer_read(&cb, out, 16) == 16U && out[0] == 'G' && out[3] == 'J' &&
          out[4] == 'K' && out[15] == 'V',
          "drained in order across the wrap: G..V");
    check(circular_buffer_is_empty(&cb) && circular_buffer_pop(&cb, &sink) == ELDMP_ERR_EMPTY,
          "empty again; pop reports EMPTY");
    printf("     (head and tail only ever grow; count = head - tail also survives\n"
           "      unsigned wrap-around of the counters themselves - see the unit tests.)\n");
}

/* ---- C. Two threads ---------------------------------------------------------------- */
#define STREAM_BYTES 200000UL

typedef struct {
    circular_buffer_t *cb;
    unsigned long full_events;     /* times the producer found the buffer full */
} producer_ctx_t;

static void *producer_main(void *arg)          /* plays the UART RX interrupt */
{
    producer_ctx_t *ctx = (producer_ctx_t *)arg;
    unsigned long sent = 0;

    while (sent < STREAM_BYTES) {
        if (circular_buffer_push(ctx->cb, (uint8_t)sent) == ELDMP_OK) {
            sent++;
        } else {
            ctx->full_events++;    /* a real ISR would drop the byte and count it;
                                      here we retry so the stream can be verified */
            sched_yield();
        }
    }
    return NULL;
}

static void experiment_c(void)
{
    uint8_t mem[16];
    circular_buffer_t cb;
    producer_ctx_t ctx = { &cb, 0 };
    pthread_t producer;
    unsigned long received = 0;
    unsigned long errors = 0;

    printf("C. Producer thread ('ISR') and consumer ('main loop') on a 16-slot buffer\n");
    check(circular_buffer_init(&cb, mem, sizeof(mem)) == ELDMP_OK, "buffer ready");
    if (pthread_create(&producer, NULL, producer_main, &ctx) != 0) {
        check(false, "pthread_create");
        return;
    }
    while (received < STREAM_BYTES) {
        uint8_t byte;

        if (circular_buffer_pop(&cb, &byte) == ELDMP_OK) {
            errors += (byte != (uint8_t)received);
            received++;
        } else {
            sched_yield();
        }
    }
    pthread_join(producer, NULL);
    printf("     %lu bytes transferred, producer met a full buffer %lu times\n", received, ctx.full_events);
    check(errors == 0U, "every byte arrived exactly once, in order, with no lock");
    check(circular_buffer_is_empty(&cb), "buffer drained at the end");
}

int main(void)
{
    printf("=== 05 circular buffer ===\n");
    experiment_a();
    experiment_b();
    experiment_c();
    printf("=== %s ===\n", g_failures == 0 ? "all checks passed" : "CHECKS FAILED");
    return g_failures == 0 ? 0 : 1;
}
