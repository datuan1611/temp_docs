/*
 * 04_bitwise_operations.c - Bit manipulation the way register code needs it.
 *
 * Guide: chapter 4 (4.1 operators and macros, 4.2 registers, 4.3 bit tricks).
 * Type : Lab. The macros under test are the Ship code in src/common/macros.h.
 *
 * Sections
 *   1. Operators on 8-bit values, and the integer-promotion trap that makes
 *      ~x, x << n and x + y behave like 32-bit int arithmetic.
 *   2. A GPIO block in RAM: configure a pin with a 2-bit MODER field, then set
 *      and reset pins through BSRR (write-1-to-set / write-1-to-reset) and see
 *      why a read-modify-write on ODR is the weaker pattern.
 *   3. Bit tricks you meet in drivers and data structures: power-of-two test,
 *      lowest set bit, population count, round-up-to-power-of-two (the ring
 *      buffer's capacity rule), rotate, byte swap - each verified exhaustively
 *      or against a reference.
 *   4. Shift rules: why 1U and a bounds check on the shift count.
 *
 * Self-checks: exit code != 0 if any fails.
 */
#include <stdio.h>

#include "macros.h"
#include "types.h"

static int g_failures;

static void check(bool ok, const char *what)
{
    printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
    if (!ok) {
        g_failures++;
    }
}

/* ---- 1. Operators and integer promotion ------------------------------------- */
static void section_operators(void)
{
    uint8_t a = 0xAC;                    /* 1010 1100 */
    uint8_t b = 0xF0;                    /* 1111 0000 */
    uint8_t shifted = (uint8_t)(a << 2); /* a is promoted to int: 0x2B0, narrowed back to 0xB0 */
    int not_a_promoted = ~a;             /* NOT uint8_t: the complement of a 32-bit int */

    printf("1. Operators on uint8_t a=0xAC, b=0xF0\n");
    check((uint8_t)(a & b) == 0xA0U, "a & b  = 0xA0 (keep common bits: masking)");
    check((uint8_t)(a | b) == 0xFCU, "a | b  = 0xFC (force bits on: setting)");
    check((uint8_t)(a ^ b) == 0x5CU, "a ^ b  = 0x5C (differing bits: toggling)");
    check((uint8_t)~a == 0x53U, "(uint8_t)~a = 0x53");
    check(not_a_promoted == (int)0xFFFFFF53, "...but ~a itself is 0xFFFFFF53: promoted to int first");
    check(shifted == 0xB0U, "(uint8_t)(a << 2) = 0xB0: the top bits fall off only when narrowed");
    check((a >> 4) == 0x0AU, "a >> 4 = 0x0A (unsigned: zero fill)");
}

/* ---- 2. GPIO block in RAM ------------------------------------------------------ */
typedef struct {
    REG_RW uint32_t MODER;   /* 2 bits per pin: 00 input, 01 output, 10 alternate, 11 analog */
    REG_RW uint32_t ODR;     /* output data, one bit per pin                                 */
    REG_WO uint32_t BSRR;    /* [15:0] set pin, [31:16] reset pin; writing 0 does nothing    */
} gpio_regs_t;

/* Software model of what the BSRR hardware does on a write. */
static void hw_write_bsrr(gpio_regs_t *g, uint32_t v)
{
    g->BSRR = v;
    g->ODR |= (v & 0xFFFFU);
    g->ODR &= ~(v >> 16);
}

static void gpio_set_pin_mode(gpio_regs_t *g, unsigned pin, uint32_t mode)
{
    const uint32_t mask = GENMASK(2U * pin + 1U, 2U * pin);

    WRITE_MASK(g->MODER, mask, FIELD_PREP(mask, mode));
}

static void section_gpio(void)
{
    gpio_regs_t g = { 0xFFFFFFFFU, 0, 0 };   /* reset value: every pin 'analog' (11b) */

    printf("2. GPIO register patterns\n");
    gpio_set_pin_mode(&g, 5, 1U);            /* pin 5 -> output */
    check(g.MODER == 0xFFFFF7FFU, "pin 5 field set to 01b, the other 15 pins untouched");
    gpio_set_pin_mode(&g, 0, 0U);            /* pin 0 -> input  */
    check(FIELD_GET(GENMASK(1, 0), g.MODER) == 0U && FIELD_GET(GENMASK(11, 10), g.MODER) == 1U,
          "two fields hold different values side by side");

    hw_write_bsrr(&g, BIT(5));
    hw_write_bsrr(&g, BIT(3));
    hw_write_bsrr(&g, BIT(5) | BIT(16U + 3U));   /* set 5 and reset 3 in ONE bus write */
    check(g.ODR == BIT(5), "one BSRR write set pin 5 and cleared pin 3 atomically");
    TOGGLE_BIT(g.ODR, 5);
    check(g.ODR == 0U, "TOGGLE_BIT on ODR works but is read-modify-write: not interrupt-safe");
}

/* ---- 3. Bit tricks -------------------------------------------------------------- */
static bool is_pow2(uint32_t x)             { return x != 0U && (x & (x - 1U)) == 0U; }
static uint32_t lowest_set_bit(uint32_t x)  { return x & (~x + 1U); }   /* x & -x for unsigned */

static unsigned popcount_loop(uint32_t x)   /* Kernighan: each step clears the lowest set bit */
{
    unsigned n = 0;

    while (x != 0U) {
        x &= x - 1U;
        n++;
    }
    return n;
}

/* Smallest power of two >= x; 0 if it does not fit in 32 bits. */
static uint32_t round_up_pow2(uint32_t x)
{
    if (x <= 1U) {
        return 1U;
    }
    x--;
    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    x |= x >> 8;
    x |= x >> 16;
    return x + 1U;                           /* wraps to 0 when x > 2^31 */
}

static uint32_t rotl32(uint32_t x, unsigned n)
{
    n &= 31U;                                /* keep the shift count in 0..31: no UB */
    return n == 0U ? x : (x << n) | (x >> (32U - n));
}

static uint32_t bswap32(uint32_t x)
{
    return (x << 24) | ((x & 0x0000FF00U) << 8) | ((x >> 8) & 0x0000FF00U) | (x >> 24);
}

static void section_tricks(void)
{
    uint32_t v;
    unsigned n;
    unsigned bad = 0;

    printf("3. Bit tricks (exhaustive where it is cheap)\n");

    for (n = 0; n < 32U; n++) {                          /* power-of-two test */
        bad += !is_pow2(BIT(n));
        bad += is_pow2(BIT(n) + 1U) && n != 0U;          /* 2^n + 1 is not a power of two (n >= 1) */
    }
    bad += is_pow2(0U) || is_pow2(6U) || is_pow2(0x80000001U);
    check(bad == 0U, "is_pow2: true for every 2^n, false for 0 and neighbours");

    bad = 0;
    for (v = 0; v <= 0xFFFFU; v++) {                     /* popcount vs compiler builtin */
        bad += (popcount_loop(v) != (unsigned)__builtin_popcount(v));
        if (v != 0U) {
            bad += (lowest_set_bit(v) != BIT((unsigned)__builtin_ctz(v)));
        }
    }
    bad += (popcount_loop(0xFFFFFFFFU) != 32U);
    check(bad == 0U, "popcount_loop == __builtin_popcount, lowest_set_bit == 2^ctz, for all 16-bit values");

    bad = 0;
    for (v = 1; v <= 4096U; v++) {                       /* round up vs naive loop */
        uint32_t expect = 1U;

        while (expect < v) {
            expect <<= 1;
        }
        bad += (round_up_pow2(v) != expect);
    }
    check(bad == 0U && round_up_pow2(0x80000000U) == 0x80000000U && round_up_pow2(0x80000001U) == 0U,
          "round_up_pow2 matches a naive loop; reports 0 on 32-bit overflow");
    check(round_up_pow2(100) == 128U, "e.g. a 100-byte request -> 128-byte ring buffer");

    bad = 0;
    for (n = 0; n < 64U; n++) {                          /* rotate: n and 32-n undo each other */
        v = 0x80000001U + n * 0x01010101U;
        bad += (rotl32(rotl32(v, n), 32U - (n & 31U)) != v);
    }
    check(bad == 0U && rotl32(0x80000001U, 1) == 0x00000003U && rotl32(0x12345678U, 0) == 0x12345678U,
          "rotl32 is reversible and safe for n = 0 and n >= 32");

    check(bswap32(0x12345678U) == 0x78563412U && bswap32(bswap32(0xDEADBEEFU)) == 0xDEADBEEFU,
          "bswap32 reverses the byte order and is its own inverse");
}

/* ---- 4. Shift rules ------------------------------------------------------------- */
static uint32_t shl32_checked(uint32_t x, unsigned n)
{
    return n < 32U ? x << n : 0U;            /* x << 32 is undefined: decide the result yourself */
}

static void section_shift_rules(void)
{
    printf("4. Shift rules\n");
    /* int one = 1; one << 31   -> undefined: the result does not fit in signed int.
     * 1U << 31                 -> 0x80000000, well defined.  That is why BIT() uses UINT32_C(1). */
    check(BIT(31) == 0x80000000U, "BIT(31) is well defined because the 1 is unsigned");
    check(shl32_checked(1U, 31) == 0x80000000U && shl32_checked(1U, 32) == 0U && shl32_checked(1U, 200) == 0U,
          "a checked shift gives a defined answer for any count");
    check((0x80000000U >> 31) == 1U, "right shift of an UNSIGNED value fills with zeros");
    /* Right-shifting a NEGATIVE signed value is implementation-defined: keep register
     * images unsigned (uint32_t), never int. */
}

int main(void)
{
    printf("=== 04 bitwise operations ===\n");
    section_operators();
    section_gpio();
    section_tricks();
    section_shift_rules();
    printf("=== %s ===\n", g_failures == 0 ? "all checks passed" : "CHECKS FAILED");
    return g_failures == 0 ? 0 : 1;
}
