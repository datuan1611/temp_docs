/*
 * 01_memory_layout.c - Where does each kind of variable actually live?
 *
 * Guide: chapter 1 (1.1 Flash + RAM, 1.2 storage classes, 1.3 stack vs heap).
 * Type : Lab (throw-away experiment). Run it, read the output, change things.
 *
 * What it measures
 *   1. Addresses of code, constants, initialised data, zero-initialised data,
 *      heap and stack, sorted - the real memory map of this process.
 *   2. Stack growth direction and frame size, by recursing and recording the
 *      frame address at every depth.
 *   3. Type sizes on THIS machine vs a 32-bit MCU, and how a heap fragments.
 *
 * Self-checks (exit code != 0 if one fails): the facts that hold on every
 * Linux target regardless of ASLR or sanitizers. Heap-related output is
 * informational only: the allocator decides, not the C standard.
 *
 * Try next: `size build/src/learning/learning_01_memory_layout`, then
 *           `nm -n build/src/learning/learning_01_memory_layout | grep -i g_`
 *           and match each symbol to the sections printed here.
 */
/* POSIX/BSD functions (sbrk) are not part of ISO C. This feature-test macro must come
 * before every #include so the file builds under strict -std=c11 as well as -std=gnu11. */
#define _DEFAULT_SOURCE

#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "types.h"

/* Section boundaries provided by the GNU linker. */
extern char etext; /* first address after .text */
extern char edata; /* first address after .data */
extern char end;   /* first address after .bss  */

/* ---- One variable per storage class ------------------------------------- */
int g_data = 42;                         /* .data   initialised -> RAM, image stored in Flash */
int g_bss;                               /* .bss    zero-initialised -> RAM, NO Flash cost    */
const int g_rodata = 7;                  /* .rodata read-only -> can live in Flash only        */
const char g_text[] = "hello, flash";    /* .rodata                                            */

static int g_failures;

static void check(bool ok, const char *what)
{
    printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
    if (!ok) {
        g_failures++;
    }
}

/* A function: its address is in .text. */
static int code_marker(void)
{
    return 1;
}

/* ---- 1. The memory map ---------------------------------------------------- */
typedef struct {
    const char *name;
    const char *region;
    uintptr_t addr;
} symbol_t;

static void print_memory_map(void)
{
    static int static_zero;              /* function-local static, zero  -> .bss  */
    static int static_init = 5;          /* function-local static, value -> .data */
    int stack_var = 0;                   /* automatic -> stack */
    void *heap_block = malloc(64);       /* dynamic   -> heap  */
    symbol_t map[] = {
        { "code_marker()",  ".text",   (uintptr_t)&code_marker },
        { "g_rodata",       ".rodata", (uintptr_t)&g_rodata },
        { "g_text",         ".rodata", (uintptr_t)g_text },
        { "g_data",         ".data",   (uintptr_t)&g_data },
        { "static_init",    ".data",   (uintptr_t)&static_init },
        { "g_bss",          ".bss",    (uintptr_t)&g_bss },
        { "static_zero",    ".bss",    (uintptr_t)&static_zero },
        { "malloc(64)",     "heap",    (uintptr_t)heap_block },
        { "stack_var",      "stack",   (uintptr_t)&stack_var },
    };
    const size_t n = sizeof(map) / sizeof(map[0]);
    size_t i;
    size_t j;

    for (i = 1; i < n; i++) {            /* insertion sort by address */
        symbol_t cur = map[i];

        for (j = i; j > 0 && map[j - 1].addr > cur.addr; j--) {
            map[j] = map[j - 1];
        }
        map[j] = cur;
    }

    printf("1. Memory map of this process (ascending addresses)\n");
    for (i = 0; i < n; i++) {
        printf("     0x%016" PRIxPTR "  %-8s %s\n", map[i].addr, map[i].region, map[i].name);
    }
    printf("     linker symbols: etext=%p edata=%p end=%p\n",
           (void *)&etext, (void *)&edata, (void *)&end);

    check((uintptr_t)&code_marker < (uintptr_t)&etext, "code lies below etext (.text)");
    check((uintptr_t)&g_data < (uintptr_t)&edata, ".data variable lies below edata");
    check((uintptr_t)&g_bss >= (uintptr_t)&edata && (uintptr_t)&g_bss < (uintptr_t)&end,
          ".bss variable lies between edata and end");
    check(g_bss == 0 && static_zero == 0, ".bss really is zero before main() runs");
    check(g_data == 42 && static_init == 5, ".data holds its initial value before main() runs");
    free(heap_block);
}

/* ---- 2. Stack growth --------------------------------------------------------
 * __builtin_frame_address(0) is the frame base of the current call. noinline +
 * a compiler barrier after the recursive call stop the optimiser from turning
 * the recursion into a loop, which would defeat the measurement. */
#define PROBE_DEPTH 6
static uintptr_t g_frame[PROBE_DEPTH];

__attribute__((noinline)) static int probe_stack(int depth)
{
    int below = 0;

    g_frame[depth] = (uintptr_t)__builtin_frame_address(0);
    if (depth + 1 < PROBE_DEPTH) {
        below = probe_stack(depth + 1);
    }
    __asm__ volatile("" ::: "memory");
    return below + 1;
}

static void measure_stack(void)
{
    int depth;
    bool grows_down = true;
    bool constant = true;
    uintptr_t frame_size;

    probe_stack(0);
    printf("2. Stack: frame address at each recursion depth\n");
    for (depth = 0; depth < PROBE_DEPTH; depth++) {
        printf("     depth %d: 0x%016" PRIxPTR "\n", depth, g_frame[depth]);
    }
    frame_size = g_frame[0] - g_frame[1];
    for (depth = 1; depth < PROBE_DEPTH; depth++) {
        grows_down = grows_down && (g_frame[depth] < g_frame[depth - 1]);
        constant = constant && ((g_frame[depth - 1] - g_frame[depth]) == frame_size);
    }
    printf("     frame size = %" PRIuPTR " bytes per call\n", frame_size);
    check(grows_down, "stack grows DOWNWARD: each deeper call has a lower address");
    check(constant, "every frame of this function has the same size");
    printf("     => a 2 KB task stack holds roughly %" PRIuPTR " nested calls of this function\n",
           frame_size > 0U ? (uintptr_t)2048U / frame_size : 0U);
}

/* ---- 3. Sizes and heap behaviour ------------------------------------------- */
static void show_sizes(void)
{
    printf("3. Type sizes on this machine (bytes)  [Cortex-M, 32-bit: long=4, pointer=4]\n");
    printf("     char=%zu short=%zu int=%zu long=%zu long long=%zu void*=%zu size_t=%zu\n",
           sizeof(char), sizeof(short), sizeof(int), sizeof(long), sizeof(long long),
           sizeof(void *), sizeof(size_t));
    check(sizeof(uint32_t) == 4U && sizeof(uint8_t) == 1U,
          "fixed-width types are the portable choice: uint32_t is 4 bytes everywhere");
}

static void explore_heap(void)
{
    enum { BLOCKS = 32, BLOCK_SIZE = 64 };
    void *blocks[BLOCKS];
    uintptr_t lo = UINTPTR_MAX;
    uintptr_t hi = 0;
    void *small = malloc(16);
    void *huge = malloc((size_t)4 * 1024 * 1024);
    void *large;
    bool inside;
    int i;
    int allocated = 0;

    printf("   Heap (informational - this is glibc's policy, not the C standard's)\n");
    printf("     small malloc(16)     -> %p (brk heap: above .bss at %p, with a randomised gap)\n",
           small, (void *)&end);
    printf("     malloc(4 MiB)        -> %p (served by mmap: a different region)\n", huge);
    printf("     program break        -> %p\n", sbrk(0));
    free(small);
    free(huge);

    for (i = 0; i < BLOCKS; i++) {
        blocks[i] = malloc(BLOCK_SIZE);
        if (blocks[i] != NULL) {
            allocated++;
        }
    }
    for (i = 1; i < BLOCKS; i += 2) {    /* free every other block -> swiss cheese */
        free(blocks[i]);
        blocks[i] = NULL;
    }
    /* The region that still contains live blocks, with 64-byte holes between them.
     * (Measured over the SURVIVING blocks only: the last block is freed too and
     * merges into the top of the heap, which is not a hole.) */
    for (i = 0; i < BLOCKS; i += 2) {
        if (blocks[i] != NULL) {
            lo = (uintptr_t)blocks[i] < lo ? (uintptr_t)blocks[i] : lo;
            hi = (uintptr_t)blocks[i] > hi ? (uintptr_t)blocks[i] : hi;
        }
    }
    large = malloc(1024);
    inside = large != NULL && (uintptr_t)large >= lo && (uintptr_t)large < hi;
    printf("     fragmentation: %d x %d B allocated, every other one freed:\n", allocated, BLOCK_SIZE);
    printf("       free total = %d B, but the largest hole = %d B\n",
           (BLOCKS / 2) * BLOCK_SIZE, BLOCK_SIZE);
    printf("       malloc(1024) was placed %s the interleaved region\n", inside ? "INSIDE" : "OUTSIDE");
    if (inside) {
        printf("       (this allocator found room anyway; the 64 B holes alone could not hold it)\n");
    } else {
        printf("       => 1024 free bytes in total, yet no single hole fits the request, so the\n"
               "          heap had to grow: that is fragmentation, and why bare-metal code uses\n"
               "          static pools instead of malloc.\n");
    }
    free(large);
    for (i = 0; i < BLOCKS; i += 2) {
        free(blocks[i]);
    }
}

int main(void)
{
    printf("=== 01 memory layout ===\n");
    print_memory_map();
    measure_stack();
    show_sizes();
    explore_heap();
    printf("=== %s ===\n", g_failures == 0 ? "all checks passed" : "CHECKS FAILED");
    return g_failures == 0 ? 0 : 1;
}
