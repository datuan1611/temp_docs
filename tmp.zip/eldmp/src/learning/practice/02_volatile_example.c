/*
 * 02_volatile_example.c - What `volatile` is for, proven at run time.
 *
 * Guide: chapter 2.1 (volatile), 2.2 (const), 3.4 (struct layout).
 * Type : Lab.
 *
 * Three experiments
 *   A. A busy-wait on a flag changed by a signal handler (the stand-in for an
 *      ISR). Compiled with -O2, the loop on a NON-volatile flag never ends: the
 *      compiler loads the flag once and spins on the register. The program runs
 *      each variant in a child process and kills it if it hangs, so this is
 *      safe to run. The volatile variant finishes.
 *   B. The idioms real peripheral headers use: a register block as a struct of
 *      REG_RW / REG_RO fields, layout checked at compile time, driven with the
 *      bit macros. Here the "peripheral" is just RAM; on a Cortex-M the only
 *      change is the pointer: ((uart_regs_t *)0x40011000UL).
 *   C. Four tiny functions to look at in the compiler output:
 *        gcc -O2 -S  (or objdump -d) and count the loads/stores.
 *
 * Self-checks: the volatile variant must terminate; layout assertions must
 * hold. If the plain variant does NOT hang (compiler did not optimise, e.g.
 * -O0) the program says so; that is not a failure.
 */
/* POSIX/BSD functions (fork, setitimer, usleep) are not part of ISO C. This feature-test macro must come
 * before every #include so the file builds under strict -std=c11 as well as -std=gnu11. */
#define _DEFAULT_SOURCE

#include <signal.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "macros.h"
#include "types.h"

/* Detect ThreadSanitizer builds (GCC defines __SANITIZE_THREAD__, Clang uses __has_feature). */
#if defined(__SANITIZE_THREAD__)
#define UNDER_TSAN 1
#elif defined(__has_feature)
#if __has_feature(thread_sanitizer)
#define UNDER_TSAN 1
#endif
#endif

static int g_failures;

static void check(bool ok, const char *what)
{
    printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
    if (!ok) {
        g_failures++;
    }
}

/* ---- A. busy-wait on a flag set asynchronously ------------------------------ */
#ifndef UNDER_TSAN                             /* helpers are unused (and rejected by -Werror) when A is skipped */
static int plain_flag;                         /* plain int: the compiler may assume nobody else writes it */
static volatile sig_atomic_t volatile_flag;    /* the type C guarantees for signal-handler flags           */

static void on_signal_plain(int sig)    { (void)sig; plain_flag = 1; }
static void on_signal_volatile(int sig) { (void)sig; volatile_flag = 1; }

static void wait_plain(void)    { while (!plain_flag) { } }
static void wait_volatile(void) { while (!volatile_flag) { } }

/* Runs `wait_fn` in a child that receives SIGALRM after 100 ms. Returns true if
 * the child finished by itself, false if it had to be killed after 1.5 s. */
static bool child_finishes(void (*handler)(int), void (*wait_fn)(void))
{
    pid_t pid = fork();
    int status = 0;
    int waited_ms;

    if (pid < 0) {
        perror("fork");
        return false;
    }
    if (pid == 0) {
        struct itimerval timer = { { 0, 0 }, { 0, 100000 } };

        signal(SIGALRM, handler);
        setitimer(ITIMER_REAL, &timer, NULL);
        wait_fn();
        _exit(0);                              /* reached only if the loop ended */
    }
    for (waited_ms = 0; waited_ms < 1500; waited_ms += 10) {
        if (waitpid(pid, &status, WNOHANG) == pid) {
            return WIFEXITED(status) && WEXITSTATUS(status) == 0;
        }
        usleep(10000);
    }
    kill(pid, SIGKILL);
    waitpid(pid, &status, 0);
    return false;
}

#endif /* UNDER_TSAN */

static void experiment_a(void)
{
    printf("A. Busy-wait on a flag set by a signal handler (the 'ISR')\n");
#ifdef UNDER_TSAN
    /* Measured: under ThreadSanitizer a loop that makes no intercepted call (not even
     * a pure volatile busy-wait) never has the signal handler delivered into it, so
     * the volatile variant would hang too. That is a limit of the tool, not of
     * volatile; run this experiment in a normal or ASan/UBSan build. */
    printf("     [SKIP] ThreadSanitizer build: signal handlers are not delivered into a\n"
           "            busy-wait loop here. Run a normal build to see this experiment.\n");
#else
    bool plain_ok = child_finishes(on_signal_plain, wait_plain);
    bool volatile_ok = child_finishes(on_signal_volatile, wait_volatile);

    printf("     plain int flag        : %s\n",
           plain_ok ? "loop ended (compiler did not hoist the load at this -O level)"
                    : "HUNG - killed after 1.5 s: the load was hoisted out of the loop");
    printf("     volatile sig_atomic_t : %s\n", volatile_ok ? "loop ended" : "HUNG");
    check(volatile_ok, "volatile flag: the loop sees the change and terminates");
#endif
}

/* ---- B. register-block idioms ------------------------------------------------ */
typedef struct {
    REG_RW uint32_t CR;    /* 0x00 control: bit0 EN, bit1 TXEIE, bit2 RXNEIE */
    REG_RO uint32_t SR;    /* 0x04 status : bit0 TXE, bit1 RXNE (read-only)  */
    REG_RW uint32_t DR;    /* 0x08 data                                      */
    REG_RW uint32_t BRR;   /* 0x0C baud-rate divisor, 16-bit field [15:0]    */
} uart_regs_t;

_Static_assert(offsetof(uart_regs_t, CR) == 0x00U, "CR must be at offset 0x00");
_Static_assert(offsetof(uart_regs_t, SR) == 0x04U, "SR must be at offset 0x04");
_Static_assert(offsetof(uart_regs_t, DR) == 0x08U, "DR must be at offset 0x08");
_Static_assert(offsetof(uart_regs_t, BRR) == 0x0CU, "BRR must be at offset 0x0C");
_Static_assert(sizeof(uart_regs_t) == 0x10U, "no padding allowed in a register block");

enum { CR_EN = 0, CR_TXEIE = 1, CR_RXNEIE = 2, SR_TXE = 0, SR_RXNE = 1 };

/* The "hardware": four plain words. The driver sees them through uart_regs_t,
 * exactly as it would see real registers. On a Cortex-M only this changes:
 *     static uart_regs_t *const UART1 = (uart_regs_t *)0x40011000UL;        */
enum { HW_CR, HW_SR, HW_DR, HW_BRR };
static uint32_t g_hw_words[4];
static uart_regs_t *const UART1 = (uart_regs_t *)g_hw_words;

static void uart_enable(uart_regs_t *u)               { SET_BIT(u->CR, CR_EN); }
static void uart_set_divisor(uart_regs_t *u, uint32_t d)
{
    WRITE_MASK(u->BRR, GENMASK(15, 0), FIELD_PREP(GENMASK(15, 0), d));
}
static bool uart_tx_ready(const uart_regs_t *u)       { return READ_BIT(u->SR, SR_TXE) != 0U; }

static void experiment_b(void)
{
    printf("B. Register block idioms (layout checked at compile time)\n");
    g_hw_words[HW_BRR] = 0xABCD0000U;                 /* upper half must survive */
    uart_enable(UART1);
    uart_set_divisor(UART1, 0x1A0U);
    check(READ_BIT(UART1->CR, CR_EN) == 1U, "SET_BIT enabled the peripheral");
    check(UART1->BRR == 0xABCD01A0U, "WRITE_MASK changed only the 16-bit divisor field");
    check(!uart_tx_ready(UART1), "status register reads back 0 until 'hardware' sets TXE");
    g_hw_words[HW_SR] = BIT(SR_TXE);                  /* the 'hardware' sets TXE; the CPU side cannot */
    check(uart_tx_ready(UART1), "READ_BIT sees the status bit the hardware set");
    /* Uncomment to see REG_RO doing its job - a compile error, not a runtime bug:
     *     UART1->SR = 0;      // error: assignment of member 'SR' in read-only object
     */
}

/* ---- C. look at the generated code -------------------------------------------- */
__attribute__((noinline)) uint32_t read_twice_plain(const uint32_t *r)
{
    uint32_t a = *r;
    uint32_t b = *r;               /* compiler may reuse a: ONE load */
    return a + b;
}

__attribute__((noinline)) uint32_t read_twice_volatile(const volatile uint32_t *r)
{
    uint32_t a = *r;
    uint32_t b = *r;               /* must really read twice: TWO loads */
    return a + b;
}

__attribute__((noinline)) void write_twice_plain(uint32_t *r)
{
    *r = 1U;                       /* dead store: compiler may drop it */
    *r = 0U;
}

__attribute__((noinline)) void write_twice_volatile(volatile uint32_t *r)
{
    *r = 1U;                       /* both stores must reach the bus (e.g. pulse a line) */
    *r = 0U;
}

static void experiment_c(void)
{
    uint32_t value = 21U;

    printf("C. Generated code (same C, different machine code)\n");
    check(read_twice_plain(&value) == 42U && read_twice_volatile(&value) == 42U,
          "both read variants compute 21 + 21");
    write_twice_plain(&value);
    check(value == 0U, "plain double write ends at 0");
    write_twice_volatile(&value);
    check(value == 0U, "volatile double write ends at 0");
    printf("     Inspect: gcc -O2 -S -o - src/learning/practice/02_volatile_example.c | less\n"
           "     Count loads in read_twice_* and stores in write_twice_*: the volatile\n"
           "     versions keep every access; the plain versions drop one.\n");
}

int main(void)
{
    printf("=== 02 volatile ===\n");
    fflush(stdout);                    /* flush before fork() so the child does not repeat the buffer */
    experiment_a();
    experiment_b();
    experiment_c();
    printf("=== %s ===\n", g_failures == 0 ? "all checks passed" : "CHECKS FAILED");
    return g_failures == 0 ? 0 : 1;
}
