/*
 * circular_buffer.h - Lock-free byte FIFO for ONE producer and ONE consumer.
 *
 * Purpose
 *   The classic UART-RX pattern: an interrupt handler (producer) pushes bytes,
 *   the main loop or a task (consumer) pops them. No malloc, no locks, no
 *   interrupt masking. Also usable between two threads on Linux.
 *
 * Contract (single producer / single consumer)
 *   Producer side : circular_buffer_push, circular_buffer_write
 *   Consumer side : circular_buffer_pop, circular_buffer_peek,
 *                   circular_buffer_read, circular_buffer_flush
 *   Either side   : init (before sharing), capacity, count, free_space,
 *                   is_empty, is_full
 *   Two producers (or two consumers) need external locking.
 *
 * Design (why it looks like this)
 *   - head and tail are FREE-RUNNING counters: they only ever increase and are
 *     reduced to an array index with "& mask". count = head - tail stays correct
 *     across unsigned wrap-around, and the whole capacity is usable (no
 *     "always leave one slot empty" trick to tell full from empty).
 *   - head is written ONLY by the producer, tail ONLY by the consumer. There is
 *     deliberately no shared "count" variable: a count modified by both sides
 *     (count++ in the ISR, count-- in main) is a read-modify-write race that
 *     loses updates. See src/learning/practice/05_circular_buffer.c.
 *   - Publishing uses release stores / acquire loads: the data byte is written
 *     before head moves, and read before tail moves.
 *   - Capacity must be a power of two so "& mask" replaces a modulo (no divide
 *     on Cortex-M0) and the counters wrap consistently.
 *
 * Portability
 *   Uses the GCC/Clang __atomic builtins (also supported by arm-none-eabi-gcc)
 *   instead of C11 <stdatomic.h>, so this header can also be included from
 *   C++17 code (tests/2_unit, Sprint 6+). On a single-core MCU 32-bit loads and
 *   stores are naturally atomic; the builtins add the compiler/CPU ordering.
 */
#ifndef ELDMP_CIRCULAR_BUFFER_H
#define ELDMP_CIRCULAR_BUFFER_H

#include "types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct circular_buffer {
    uint8_t *storage; /* caller-provided backing array (static or stack)      */
    size_t   mask;    /* capacity - 1                                         */
    size_t   head;    /* total bytes ever written - producer writes only      */
    size_t   tail;    /* total bytes ever read    - consumer writes only      */
} circular_buffer_t;  /* Fields are private; tests poke head/tail on purpose. */

/* Bind the buffer to `storage` (capacity bytes). capacity must be a non-zero
 * power of two. On failure the struct is zeroed so later calls fail safely
 * with ELDMP_ERR_INVALID_ARG instead of touching memory. Call before the
 * producer/consumer start running. */
eldmp_status_t circular_buffer_init(circular_buffer_t *cb, uint8_t *storage,
                                    size_t capacity);

size_t circular_buffer_capacity(const circular_buffer_t *cb);
size_t circular_buffer_count(const circular_buffer_t *cb);      /* bytes stored    */
size_t circular_buffer_free_space(const circular_buffer_t *cb); /* bytes writable  */
bool   circular_buffer_is_empty(const circular_buffer_t *cb);
bool   circular_buffer_is_full(const circular_buffer_t *cb);

/* Producer: append one byte. ELDMP_ERR_NO_SPACE if full - the caller (an ISR)
 * decides whether to drop and count the loss; this function never blocks. */
eldmp_status_t circular_buffer_push(circular_buffer_t *cb, uint8_t byte);

/* Consumer: remove the oldest byte. ELDMP_ERR_EMPTY if there is none. */
eldmp_status_t circular_buffer_pop(circular_buffer_t *cb, uint8_t *byte);

/* Consumer: look at the oldest byte without removing it. */
eldmp_status_t circular_buffer_peek(const circular_buffer_t *cb, uint8_t *byte);

/* Producer: copy up to len bytes in; returns how many were stored (partial
 * write when space runs out, 0 on invalid arguments). Handles wrap-around. */
size_t circular_buffer_write(circular_buffer_t *cb, const uint8_t *data, size_t len);

/* Consumer: copy up to len bytes out; returns how many were read. */
size_t circular_buffer_read(circular_buffer_t *cb, uint8_t *out, size_t len);

/* Consumer: discard everything currently stored. Producer-side callers must
 * not use this - only the consumer may move tail. */
void circular_buffer_flush(circular_buffer_t *cb);

#ifdef __cplusplus
}
#endif

#endif /* ELDMP_CIRCULAR_BUFFER_H */
