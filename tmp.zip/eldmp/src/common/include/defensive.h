/*
 * defensive.h - Small helpers that turn classic C undefined behaviour into
 *               explicit, checkable results.
 *
 * Purpose
 *   Chapter 6 of the guide lists the UB that bites embedded code: buffer
 *   overflow, integer overflow, unaligned access, use-after-free. Each helper
 *   below is the safe alternative for one of them. Header-only (static inline)
 *   so there is no link dependency and the compiler can fold them away.
 *
 *   Overflow      eldmp_add_size / eldmp_mul_size
 *   Overflow      eldmp_copy_bounded / eldmp_str_copy   (replace memcpy/strcpy/strncpy)
 *   Unaligned     eldmp_load_* / eldmp_store_*          (explicit endianness, any alignment)
 *   Dangling ptr  ELDMP_FREE
 *
 * Verified by tests/1_learning/test_defensive_patterns.c.
 */
#ifndef ELDMP_DEFENSIVE_H
#define ELDMP_DEFENSIVE_H

#include <stdlib.h>
#include <string.h>

#include "types.h"

/* ---- Checked size arithmetic ---------------------------------------------
 * Wrap-around on size_t is well defined but still a bug when it feeds an
 * allocation or a bounds check (a + b "wraps" to a small number, the check
 * passes, the copy overflows). On overflow *out is left untouched. */
static inline eldmp_status_t eldmp_add_size(size_t a, size_t b, size_t *out)
{
    size_t result;

    if (out == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    if (__builtin_add_overflow(a, b, &result)) {
        return ELDMP_ERR_OVERFLOW;
    }
    *out = result;
    return ELDMP_OK;
}

static inline eldmp_status_t eldmp_mul_size(size_t a, size_t b, size_t *out)
{
    size_t result;

    if (out == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    if (__builtin_mul_overflow(a, b, &result)) {
        return ELDMP_ERR_OVERFLOW;
    }
    *out = result;
    return ELDMP_OK;
}

/* ---- Bounded copies ------------------------------------------------------
 * Copy src_len bytes into a destination of dst_size bytes, or copy nothing.
 * Regions must not overlap. src_len == 0 is a valid no-op. */
static inline eldmp_status_t eldmp_copy_bounded(void *dst, size_t dst_size,
                                                const void *src, size_t src_len)
{
    if (src_len == 0U) {
        return ELDMP_OK;
    }
    if (dst == NULL || src == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    if (src_len > dst_size) {
        return ELDMP_ERR_NO_SPACE;
    }
    memcpy(dst, src, src_len);
    return ELDMP_OK;
}

/* Copy a C string into dst (capacity dst_size, terminator included) and ALWAYS
 * terminate it. Returns ELDMP_ERR_TRUNCATED if src did not fit; dst then holds
 * the first dst_size-1 characters. Unlike strncpy() it never leaves dst
 * unterminated and never pads with zeros. */
static inline eldmp_status_t eldmp_str_copy(char *dst, size_t dst_size, const char *src)
{
    size_t len;

    if (dst == NULL || src == NULL || dst_size == 0U) {
        return ELDMP_ERR_INVALID_ARG;
    }
    /* Bounded length scan. strnlen() is POSIX, not ISO C, so it is not
     * available under strict -std=c11 or on every embedded libc. */
    for (len = 0U; len < dst_size && src[len] != '\0'; len++) {
    }
    if (len == dst_size) {           /* no terminator within dst_size bytes */
        memcpy(dst, src, dst_size - 1U);
        dst[dst_size - 1U] = '\0';
        return ELDMP_ERR_TRUNCATED;
    }
    memcpy(dst, src, len + 1U);      /* includes the terminator */
    return ELDMP_OK;
}

/* ---- Unaligned, endian-explicit loads and stores ---------------------------
 * Reading a uint32_t through a cast pointer at an odd address is undefined
 * behaviour (and a bus fault on some ARM cores). Building the value byte by
 * byte is valid at any alignment and states the wire byte order explicitly -
 * exactly what the Sprint 13 protocol needs. Note the (uint32_t) cast BEFORE
 * the shift: b[3] << 24 on a plain int overflows into the sign bit when
 * b[3] >= 0x80, which is undefined behaviour. */
static inline uint16_t eldmp_load_u16_le(const void *p)
{
    const uint8_t *b = (const uint8_t *)p;
    return (uint16_t)((uint16_t)b[0] | (uint16_t)((uint16_t)b[1] << 8));
}

static inline uint16_t eldmp_load_u16_be(const void *p)
{
    const uint8_t *b = (const uint8_t *)p;
    return (uint16_t)((uint16_t)((uint16_t)b[0] << 8) | (uint16_t)b[1]);
}

static inline uint32_t eldmp_load_u32_le(const void *p)
{
    const uint8_t *b = (const uint8_t *)p;
    return (uint32_t)b[0] | ((uint32_t)b[1] << 8) |
           ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
}

static inline uint32_t eldmp_load_u32_be(const void *p)
{
    const uint8_t *b = (const uint8_t *)p;
    return ((uint32_t)b[0] << 24) | ((uint32_t)b[1] << 16) |
           ((uint32_t)b[2] << 8) | (uint32_t)b[3];
}

static inline void eldmp_store_u16_le(void *p, uint16_t v)
{
    uint8_t *b = (uint8_t *)p;
    b[0] = (uint8_t)(v & 0xFFU);
    b[1] = (uint8_t)(v >> 8);
}

static inline void eldmp_store_u16_be(void *p, uint16_t v)
{
    uint8_t *b = (uint8_t *)p;
    b[0] = (uint8_t)(v >> 8);
    b[1] = (uint8_t)(v & 0xFFU);
}

static inline void eldmp_store_u32_le(void *p, uint32_t v)
{
    uint8_t *b = (uint8_t *)p;
    b[0] = (uint8_t)(v & 0xFFU);
    b[1] = (uint8_t)((v >> 8) & 0xFFU);
    b[2] = (uint8_t)((v >> 16) & 0xFFU);
    b[3] = (uint8_t)(v >> 24);
}

static inline void eldmp_store_u32_be(void *p, uint32_t v)
{
    uint8_t *b = (uint8_t *)p;
    b[0] = (uint8_t)(v >> 24);
    b[1] = (uint8_t)((v >> 16) & 0xFFU);
    b[2] = (uint8_t)((v >> 8) & 0xFFU);
    b[3] = (uint8_t)(v & 0xFFU);
}

/* ---- Freeing ---------------------------------------------------------------
 * free() then NULL the pointer, so a second ELDMP_FREE (free(NULL) is a no-op)
 * is harmless and a stale use crashes at a NULL dereference instead of
 * silently corrupting the heap. p must be a side-effect-free lvalue.
 * Hosted (Linux) code only: bare-metal firmware does not use the heap. */
#define ELDMP_FREE(p)         \
    do {                      \
        free(p);              \
        (p) = NULL;           \
    } while (0)

#endif /* ELDMP_DEFENSIVE_H */
