/*
 * types.h - Common types used by every ELDMP module.
 *
 * Purpose
 *   A single include that gives fixed-width integers, bool, size_t and the
 *   shared status type, plus the qualifiers used to describe hardware
 *   registers. Include this instead of repeating <stdint.h>/<stdbool.h>.
 *
 * Register qualifiers (Guide 2.1)
 *   REG_RW  read/write register              -> volatile
 *   REG_RO  read-only status register        -> const volatile
 *   REG_WO  write-only register              -> volatile (C has no "write-only";
 *                                               the name documents intent)
 *   "volatile" forces every access to really happen, in program order.
 *   "const volatile" additionally makes writing to a status register a
 *   compile error. These play the role of CMSIS's __IO / __I / __O.
 */
#ifndef ELDMP_TYPES_H
#define ELDMP_TYPES_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "error_codes.h"

#define REG_RW volatile
#define REG_RO const volatile
#define REG_WO volatile

#endif /* ELDMP_TYPES_H */
