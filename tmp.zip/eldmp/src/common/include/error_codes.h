/*
 * error_codes.h - Status codes shared by every ELDMP module.
 *
 * Purpose
 *   One status vocabulary for all sprints, so an error raised in a low layer
 *   (ring buffer, protocol, driver) reaches the caller unchanged.
 *
 * Conventions
 *   - ELDMP_OK is 0; every failure is a distinct non-zero enumerator.
 *   - A function that can fail returns eldmp_status_t; results are returned
 *     through out-parameters, never through "magic" return values.
 *   - ELDMP_ERR_TRUNCATED means "output is valid and terminated, but data was
 *     cut". It is non-zero on purpose: callers must decide, not ignore it.
 *
 * Extending
 *   Add new codes BEFORE ELDMP_STATUS_COUNT and add the matching text in
 *   eldmp_strerror() (src/common/src/common.c). tests/1_learning/
 *   test_defensive_patterns.c fails if a code has no description.
 *
 * Reference: docs/learning/EMBEDDED_C_MASTERY_GUIDE.md, section 6.4.
 */
#ifndef ELDMP_ERROR_CODES_H
#define ELDMP_ERROR_CODES_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    ELDMP_OK = 0,           /* success */
    ELDMP_ERR_INVALID_ARG,  /* NULL pointer, zero size, value out of range */
    ELDMP_ERR_NO_SPACE,     /* destination too small / buffer full */
    ELDMP_ERR_EMPTY,        /* nothing to read */
    ELDMP_ERR_OVERFLOW,     /* arithmetic overflow detected (and prevented) */
    ELDMP_ERR_TRUNCATED,    /* result valid but data was cut to fit */
    ELDMP_ERR_TIMEOUT,      /* operation did not complete in time */
    ELDMP_ERR_BUSY,         /* resource already in use */
    ELDMP_ERR_STATE,        /* operation illegal in the current state */
    ELDMP_ERR_CRC,          /* integrity check failed */
    ELDMP_STATUS_COUNT      /* sentinel - keep last, not a real status */
} eldmp_status_t;

/* Human-readable text for a status; never returns NULL, even for garbage. */
const char *eldmp_strerror(eldmp_status_t status);

#ifdef __cplusplus
}
#endif

#endif /* ELDMP_ERROR_CODES_H */
