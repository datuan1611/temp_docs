/*
 * macros.h - Bit manipulation and small compile-time helpers.
 *
 * Purpose
 *   Readable, side-effect-aware helpers for register work (Sprint 3+) and for
 *   any code that packs bits. Definitions follow docs/learning/
 *   EMBEDDED_C_MASTERY_GUIDE.md section 4.1: they take a BIT NUMBER, not a mask.
 *
 *   SET_BIT(reg, 5)      sets bit 5          (reg |= 1 << 5)
 *   CLEAR_BIT(reg, 5)    clears bit 5
 *   TOGGLE_BIT(reg, 5)   flips bit 5
 *   READ_BIT(reg, 5)     evaluates to 0 or 1
 *   WRITE_MASK(reg, mask, pattern)   replace only the bits selected by mask
 *
 * Narrow registers (uint8_t / uint16_t): the macros work, but the compound
 * assignment narrows an int back to the register type, so -Wconversion (not
 * part of the project's -Wall -Wextra gate) will warn. Cast at the call site
 * if you enable it.
 *
 * Rules that apply to every macro here
 *   1. The first argument must be a side-effect-free lvalue (a variable or a
 *      register field). It may be evaluated more than once.
 *   2. Bit numbers must be smaller than the width of the operand. Shifting by
 *      >= the width is undefined behaviour in C.
 *   3. SET/CLEAR/TOGGLE/WRITE_MASK are read-modify-write: NOT atomic. If an
 *      interrupt or another thread touches the same register, either mask
 *      interrupts or use a write-1-to-set/clear register (e.g. STM32 BSRR).
 *      The Linux kernel encodes this in names: set_bit() is atomic, __set_bit()
 *      is not.
 *
 * !! Name clash with vendor headers (Sprint 3 hazard) !!
 *   STM32 CMSIS device headers (stm32f4xx.h, stm32h7xx.h) define SET_BIT,
 *   CLEAR_BIT and READ_BIT with MASK semantics: SET_BIT(REG, BIT) is
 *   ((REG) |= (BIT)). Same name, different meaning: SET_BIT(reg, 5) would
 *   silently set bits 0 and 2 (mask 0b101). This header refuses to compile if
 *   the names are already taken. Including it BEFORE a vendor header is only
 *   caught by a "redefined" compiler warning, so treat that warning as an
 *   error. Decision needed at the start of Sprint 3: rename these macros.
 */
#ifndef ELDMP_MACROS_H
#define ELDMP_MACROS_H

#include <stdint.h>

#if defined(SET_BIT) || defined(CLEAR_BIT) || defined(READ_BIT) || \
    defined(TOGGLE_BIT) || defined(WRITE_MASK)
#error "SET_BIT/CLEAR_BIT/READ_BIT/TOGGLE_BIT/WRITE_MASK already defined (vendor header?). Their semantics differ - see the note at the top of macros.h."
#endif

/* ---- Single-bit operations (32-bit register oriented) -------------------- */

/* Mask with only bit n set. UINT32_C keeps the shift well-defined for n <= 31. */
#define BIT(n)                (UINT32_C(1) << (n))

#define SET_BIT(value, n)     ((value) |= BIT(n))
#define CLEAR_BIT(value, n)   ((value) &= ~BIT(n))
#define TOGGLE_BIT(value, n)  ((value) ^= BIT(n))
#define READ_BIT(value, n)    (((value) >> (n)) & 1U)

/* ---- Multi-bit operations ------------------------------------------------ */

/* Replace the bits selected by mask with the same bits of pattern.
 * pattern must already be shifted into position. */
#define WRITE_MASK(value, mask, pattern) \
    ((value) = ((value) & ~(mask)) | ((pattern) & (mask)))

/* Contiguous mask from bit l (low) to bit h (high), both inclusive, 0 <= l <= h <= 31.
 * Same idea as GENMASK() in the Linux kernel. */
#define GENMASK(h, l)         ((~0U << (l)) & (~0U >> (31U - (h))))

/* Position-independent field access: the shift is derived from the mask.
 * mask must be non-zero and contiguous. Same idea as FIELD_PREP()/FIELD_GET()
 * in the Linux kernel. */
#define FIELD_PREP(mask, val) ((((uint32_t)(val)) << __builtin_ctz(mask)) & (mask))
#define FIELD_GET(mask, reg)  ((((uint32_t)(reg)) & (mask)) >> __builtin_ctz(mask))

/* ---- Small compile-time helpers ------------------------------------------ */

/* Evaluates to 0 if e is false; refuses to compile if e is true (a negative
 * array size is a constraint violation). Unlike the "unnamed bit-field in a
 * struct" idiom this stays clean under -Wpedantic. */
#define ELDMP_BUILD_BUG_ON_ZERO(e) (sizeof(char[1 - 2 * !!(e)]) - 1U)

/* Number of elements of an ARRAY. Passing a pointer is a compile error
 * (sizeof(ptr)/sizeof(*ptr) would silently give a wrong answer). */
#define ARRAY_SIZE(a) \
    (sizeof(a) / sizeof((a)[0]) + \
     ELDMP_BUILD_BUG_ON_ZERO(__builtin_types_compatible_p(__typeof__(a), __typeof__(&(a)[0]))))

/* Silence "unused parameter" without hiding real problems. */
#define UNUSED(x)             ((void)(x))

#endif /* ELDMP_MACROS_H */
