# src/common — Thư Viện Dùng Chung (C)

Thư viện tĩnh (`libcommon.a`) chứa code dùng chung giữa `src/app` và các module tương lai — hiện gồm CLI parser và cơ chế versioning từ git tag.

**Bổ sung từ Milestone 0.2** (Sprint Learning): bộ khối nền tảng Embedded C — mã trạng thái, macro thao tác bit, helper phòng thủ và ring buffer lock-free.

**Ngôn ngữ:** C (xem ghi chú chiến lược ngôn ngữ ở [`../app/README.md`](../app/README.md) — sẽ chuyển sang C++ khi dự án bước vào phần Linux, Sprint 6+).

*Bổ sung từ Milestone 0.2:* Riêng `circular_buffer.h`, `error_codes.h`, `types.h` và `defensive.h` đã được kiểm chứng là include được từ C++17, vì sau này `tests/2_unit/` viết bằng C++.

> **Lab hay Ship?** Thư mục này là **Ship** — code đạt chuẩn, được các sprint sau tái sử dụng, có unit test và không được sửa tuỳ tiện. Phần **Lab** (thử nghiệm, bài tập) nằm ở [`../learning/`](../learning/README.md).

## Nội Dung

| File | Vai trò |
|---|---|
| `include/cli.h` / `src/cli.c` | Parse tham số dòng lệnh (`--help`, `--version`, lệnh không hợp lệ) |
| `include/version.h.in` / `src/version.c` | Sinh version string từ `git describe --tags --always` lúc cấu hình CMake |
| `include/error_codes.h` / `src/common.c` | *(Milestone 0.2)* `eldmp_status_t` + `eldmp_strerror()` — **một** bộ mã trạng thái dùng cho mọi module |
| `include/types.h` | *(Milestone 0.2)* `<stdint.h>`, `<stdbool.h>`, `<stddef.h>` và các qualifier thanh ghi `REG_RW` / `REG_RO` / `REG_WO` |
| `include/macros.h` | *(Milestone 0.2)* `BIT`, `SET_BIT`, `CLEAR_BIT`, `TOGGLE_BIT`, `READ_BIT`, `WRITE_MASK`, `GENMASK`, `FIELD_PREP/GET`, `ARRAY_SIZE`, `UNUSED` |
| `include/defensive.h` | *(Milestone 0.2)* Cộng/nhân `size_t` có kiểm tra tràn, copy có giới hạn, load/store không cần căn lề với endian tường minh, `ELDMP_FREE` (header-only) |
| `include/circular_buffer.h` / `src/circular_buffer.c` | *(Milestone 0.2)* FIFO byte lock-free, **một producer – một consumer** (ISR ↔ main, hoặc hai thread) |

## Dùng Thế Nào

```c
#include "circular_buffer.h"
#include "macros.h"

static uint8_t rx_storage[64];               /* dung lượng: phải là lũy thừa của 2 */
static circular_buffer_t rx;

void uart_init(void)           { circular_buffer_init(&rx, rx_storage, sizeof rx_storage); }
void uart_rx_isr(uint8_t byte) { (void)circular_buffer_push(&rx, byte); }   /* producer: không bao giờ block */

void main_loop_step(void)                    /* consumer */
{
    uint8_t b;
    while (circular_buffer_pop(&rx, &b) == ELDMP_OK) {
        /* xử lý b */
    }
}

/* Thanh ghi: SET_BIT(reg, 5);
 *            WRITE_MASK(reg, GENMASK(7, 4), FIELD_PREP(GENMASK(7, 4), 0x5)); */
```

**Ai được gọi hàm nào của ring buffer** (quy ước SPSC — vi phạm là mất tính an toàn):

| Bên | Hàm được phép |
|---|---|
| Producer (ISR) | `push`, `write` |
| Consumer (main loop / task) | `pop`, `peek`, `read`, `flush` |
| Cả hai | `capacity`, `count`, `free_space`, `is_empty`, `is_full` |
| Trước khi chạy | `init` |

Nhiều producer hoặc nhiều consumer thì **phải tự khoá** ở ngoài.

## Vì Sao Thiết Kế Như Vậy (Ý Nghĩa)

**1. Ring buffer không có biến `count` dùng chung.**
- *Làm gì:* `head` chỉ producer ghi, `tail` chỉ consumer ghi; cả hai là bộ đếm chạy tự do (`chỉ số = bộ đếm & mask`), đọc/ghi bằng release/acquire.
- *Tại sao:* ví dụ ở guide §5.1 giữ một `count` mà ISR tăng (`count++`) còn main giảm (`count--`). Mỗi phép đó là 3 bước *load – cộng – store*; nếu ngắt xen vào giữa thì một bản cập nhật bị mất. `volatile` **không** sửa được lỗi này vì `volatile` chỉ cấm compiler cache, không biến phép đọc-sửa-ghi thành nguyên tử.
- *Ý nghĩa:* bài học tổng quát — muốn an toàn thì **chỉ để một bên ghi mỗi biến**, đừng thêm `volatile` hay `disable_irq` cho đến khi hiểu lỗi nằm ở đâu. Xem bài 05 thí nghiệm A ở [`../learning/`](../learning/README.md).

**2. Dung lượng phải là lũy thừa của 2.**
- *Tại sao:* `& mask` thay cho phép chia lấy dư (Cortex-M0 không có lệnh chia), và bộ đếm 32-bit tràn về 0 vẫn khớp vì 2³² chia hết cho dung lượng. Dùng được **toàn bộ** dung lượng, không phải "chừa một ô trống" để phân biệt đầy/rỗng.
- *Đánh đổi:* muốn 100 byte thì phải xin 128.

**3. Dùng builtin `__atomic_*` thay vì `<stdatomic.h>`.**
- *Tại sao:* header phải include được từ C++17 (C++ chưa có `_Atomic` trước C++23). GCC, Clang và `arm-none-eabi-gcc` đều hỗ trợ; trên Cortex-M0/M4/M7 không cần `libatomic` (đã kiểm chứng bằng `nm -u`: chỉ cần `memcpy`, `memset`).

**4. Macro bit nhận *số bit*, không nhận mask** (đúng guide §4.1) — và đây là **bẫy của Sprint 3**.
- Header STM32 CMSIS (`stm32f4xx.h`, `stm32h7xx.h`) định nghĩa `SET_BIT(REG, BIT)` theo **mask**. Cùng tên, khác nghĩa: `SET_BIT(reg, 5)` sẽ lặng lẽ set bit 0 và bit 2 (mask `0b101`).
- `macros.h` dừng build bằng `#error` nếu tên đã bị định nghĩa trước. Nếu `macros.h` được include *trước* header của hãng thì chỉ có cảnh báo `redefined` → hãy coi cảnh báo đó là lỗi.
- **Việc cần quyết định trước Sprint 3:** đổi tên macro của dự án (ví dụ tiền tố `ELDMP_`) hay không. Đây là đề xuất, chưa thực hiện.

**5. Macro đọc-sửa-ghi không nguyên tử.** `SET_BIT`/`CLEAR_BIT`/`TOGGLE_BIT`/`WRITE_MASK` là đọc → sửa → ghi. Nếu ISR cũng chạm cùng thanh ghi, hãy dùng thanh ghi "ghi 1 để set/clear" (như `BSRR` của STM32) hoặc tắt ngắt quanh đoạn đó. Linux kernel phân biệt bằng tên: `set_bit()` nguyên tử, `__set_bit()` không.

**6. Mã trạng thái.** Thêm mã mới *trước* `ELDMP_STATUS_COUNT` và thêm dòng mô tả tương ứng trong `common.c`. `test_defensive_patterns` sẽ fail nếu có mã không có mô tả — đây là cách để bảng và enum không lệch nhau.

## Kiểm Thử

Unit test nằm ở [`tests/1_learning/`](../../tests/1_learning/README.md) — xem file đó để biết chạy thế nào và mỗi test chứng minh điều gì.

```bash
mkdir -p build && cd build
cmake .. -DELDMP_WERROR=ON && cmake --build .
ctest --output-on-failure
```

## Cơ Chế Versioning — Cách Hoạt Động

`CMakeLists.txt` chạy `execute_process(COMMAND git describe --tags --always)` lúc **configure** (không phải lúc build) để lấy tag/commit hash hiện tại, rồi `configure_file()` sinh ra `version.h` thật (điền `@GIT_TAG@`) vào thư mục build — `version.h.in` chỉ là **template**, không tự include được, không commit `version.h` sinh ra vào git (đã nằm trong `build/`, đã gitignore).

**Xử lý khi không có `.git`:** nếu build từ cây do [`scripts/helper/generate_project.sh`](../../scripts/helper/generate_project.sh) sinh ra (cây đó **không** copy `.git` theo thiết kế), `git describe` sẽ thất bại — `CMakeLists.txt` đã bắt lỗi này qua `RESULT_VARIABLE` và fallback về chuỗi `"unknown"` thay vì để trống hoặc in lỗi ra màn hình. Đã kiểm chứng cả hai trường hợp (có `.git` → in đúng commit hash; không `.git` → in "unknown") đều build sạch, không cảnh báo với `-Wall -Wextra`.

## Build

Thư viện này build cùng lúc với `src/app` từ CMake gốc — không có bước build riêng:

```bash
mkdir -p build && cd build
cmake .. && cmake --build .
./src/app/eldmp --version
```
