/*
 * common.c - Shared helpers that need a real (non-inline) definition.
 * Currently: eldmp_strerror(), the text for every eldmp_status_t.
 */
#include "error_codes.h"

#include <stddef.h>

static const char *const k_status_text[ELDMP_STATUS_COUNT] = {
    [ELDMP_OK]              = "success",
    [ELDMP_ERR_INVALID_ARG] = "invalid argument",
    [ELDMP_ERR_NO_SPACE]    = "no space left in buffer",
    [ELDMP_ERR_EMPTY]       = "nothing to read",
    [ELDMP_ERR_OVERFLOW]    = "arithmetic overflow",
    [ELDMP_ERR_TRUNCATED]   = "data truncated to fit",
    [ELDMP_ERR_TIMEOUT]     = "operation timed out",
    [ELDMP_ERR_BUSY]        = "resource busy",
    [ELDMP_ERR_STATE]       = "illegal state for this operation",
    [ELDMP_ERR_CRC]         = "integrity check (CRC) failed",
};

const char *eldmp_strerror(eldmp_status_t status)
{
    const char *text;

    /* Compare as unsigned: a negative or oversized value must not index the table. */
    if ((unsigned int)status >= (unsigned int)ELDMP_STATUS_COUNT) {
        return "unknown status";
    }
    text = k_status_text[status];
    return text != NULL ? text : "unknown status";
}
