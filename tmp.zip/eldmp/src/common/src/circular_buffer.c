/*
 * circular_buffer.c - Implementation of the SPSC byte FIFO.
 * See include/circular_buffer.h for the contract and the design rationale.
 *
 * Memory-ordering summary (per operation)
 *   producer: load own head (relaxed), load tail (acquire)  -> write data
 *             -> store head (release)
 *   consumer: load own tail (relaxed), load head (acquire)  -> read data
 *             -> store tail (release)
 * The release store publishes the data; the matching acquire load on the
 * other side guarantees it sees the data before it sees the new counter.
 */
#include "circular_buffer.h"

#include <string.h>

static inline size_t load_relaxed(const size_t *p)
{
    return __atomic_load_n(p, __ATOMIC_RELAXED);
}

static inline size_t load_acquire(const size_t *p)
{
    return __atomic_load_n(p, __ATOMIC_ACQUIRE);
}

static inline void store_release(size_t *p, size_t v)
{
    __atomic_store_n(p, v, __ATOMIC_RELEASE);
}

static inline bool usable(const circular_buffer_t *cb)
{
    return cb != NULL && cb->storage != NULL;
}

eldmp_status_t circular_buffer_init(circular_buffer_t *cb, uint8_t *storage,
                                    size_t capacity)
{
    if (cb == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    /* Zero first: a failed init must leave a buffer that rejects every call. */
    memset(cb, 0, sizeof(*cb));
    if (storage == NULL || capacity == 0U || (capacity & (capacity - 1U)) != 0U) {
        return ELDMP_ERR_INVALID_ARG;
    }
    cb->storage = storage;
    cb->mask = capacity - 1U;
    return ELDMP_OK;
}

size_t circular_buffer_capacity(const circular_buffer_t *cb)
{
    return usable(cb) ? cb->mask + 1U : 0U;
}

size_t circular_buffer_count(const circular_buffer_t *cb)
{
    size_t tail;
    size_t head;
    size_t used;
    size_t capacity;

    if (!usable(cb)) {
        return 0U;
    }
    /* Read tail FIRST: head only grows, so head >= tail is guaranteed and the
     * subtraction cannot wrap. The clamp covers a third observer that reads
     * a stale tail; for the producer or consumer themselves it is exact. */
    tail = load_acquire(&cb->tail);
    head = load_acquire(&cb->head);
    used = head - tail;
    capacity = cb->mask + 1U;
    return used > capacity ? capacity : used;
}

size_t circular_buffer_free_space(const circular_buffer_t *cb)
{
    return circular_buffer_capacity(cb) - circular_buffer_count(cb);
}

bool circular_buffer_is_empty(const circular_buffer_t *cb)
{
    /* An unusable (NULL / uninitialised) buffer is both empty and full:
     * nothing can be read from it and nothing can be written to it. */
    return !usable(cb) || circular_buffer_count(cb) == 0U;
}

bool circular_buffer_is_full(const circular_buffer_t *cb)
{
    return !usable(cb) || circular_buffer_count(cb) == cb->mask + 1U;
}

eldmp_status_t circular_buffer_push(circular_buffer_t *cb, uint8_t byte)
{
    size_t head;
    size_t tail;

    if (!usable(cb)) {
        return ELDMP_ERR_INVALID_ARG;
    }
    head = load_relaxed(&cb->head);
    tail = load_acquire(&cb->tail);
    if (head - tail > cb->mask) {          /* head - tail == capacity: full */
        return ELDMP_ERR_NO_SPACE;
    }
    cb->storage[head & cb->mask] = byte;
    store_release(&cb->head, head + 1U);
    return ELDMP_OK;
}

eldmp_status_t circular_buffer_pop(circular_buffer_t *cb, uint8_t *byte)
{
    size_t tail;
    size_t head;

    if (!usable(cb) || byte == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    tail = load_relaxed(&cb->tail);
    head = load_acquire(&cb->head);
    if (head == tail) {
        return ELDMP_ERR_EMPTY;
    }
    *byte = cb->storage[tail & cb->mask];
    store_release(&cb->tail, tail + 1U);
    return ELDMP_OK;
}

eldmp_status_t circular_buffer_peek(const circular_buffer_t *cb, uint8_t *byte)
{
    size_t tail;
    size_t head;

    if (!usable(cb) || byte == NULL) {
        return ELDMP_ERR_INVALID_ARG;
    }
    tail = load_relaxed(&cb->tail);
    head = load_acquire(&cb->head);
    if (head == tail) {
        return ELDMP_ERR_EMPTY;
    }
    *byte = cb->storage[tail & cb->mask];
    return ELDMP_OK;
}

size_t circular_buffer_write(circular_buffer_t *cb, const uint8_t *data, size_t len)
{
    size_t head;
    size_t tail;
    size_t capacity;
    size_t n;
    size_t index;
    size_t first;

    if (!usable(cb) || data == NULL || len == 0U) {
        return 0U;
    }
    capacity = cb->mask + 1U;
    head = load_relaxed(&cb->head);
    tail = load_acquire(&cb->tail);
    n = capacity - (head - tail);          /* free space */
    if (len < n) {
        n = len;
    }
    if (n == 0U) {
        return 0U;
    }
    index = head & cb->mask;
    first = capacity - index;              /* bytes until the end of the array */
    if (first > n) {
        first = n;
    }
    memcpy(&cb->storage[index], data, first);
    memcpy(cb->storage, data + first, n - first);   /* wrapped part (may be 0) */
    store_release(&cb->head, head + n);
    return n;
}

size_t circular_buffer_read(circular_buffer_t *cb, uint8_t *out, size_t len)
{
    size_t tail;
    size_t head;
    size_t capacity;
    size_t n;
    size_t index;
    size_t first;

    if (!usable(cb) || out == NULL || len == 0U) {
        return 0U;
    }
    capacity = cb->mask + 1U;
    tail = load_relaxed(&cb->tail);
    head = load_acquire(&cb->head);
    n = head - tail;                       /* bytes available */
    if (len < n) {
        n = len;
    }
    if (n == 0U) {
        return 0U;
    }
    index = tail & cb->mask;
    first = capacity - index;
    if (first > n) {
        first = n;
    }
    memcpy(out, &cb->storage[index], first);
    memcpy(out + first, cb->storage, n - first);
    store_release(&cb->tail, tail + n);
    return n;
}

void circular_buffer_flush(circular_buffer_t *cb)
{
    if (!usable(cb)) {
        return;
    }
    /* Consumer-side: catch tail up to the head we can currently see. */
    store_release(&cb->tail, load_acquire(&cb->head));
}
