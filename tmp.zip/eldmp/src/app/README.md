# eldmp Application

`Đây là entry point cho ứng dụng dòng lệnh eldmp.`

**Ghi chú ngôn ngữ (quan trọng):**<br>
Hiện tại module này viết bằng **C**, đúng với giai đoạn hiện tại của roadmap (ôn C nền tảng + lập trình MCU bare-metal, Sprint Learning → Sprint 5).
Theo roadmap, phía Linux (Sprint 6 trở đi) sẽ chuyển sang **Modern C++ (C++17/20)** — `main.c`/`src/common` ở đây là nền tảng C tạm thời cho giai đoạn hiện tại, sẽ được viết lại bằng C++ khi dự án bước vào phần Linux thật.
Đây là quyết định có chủ đích, không phải chưa quyết định xong ngôn ngữ.

## Kiến trúc

- `main.c`: Hàm main là điểm bắt đầu, có thể mở rộng để khởi tạo môi trường trước khi gọi `cli_run()`.
- `CMakeLists.txt`: Cấu hình build cho thư mục này.
- Thư viện dùng chung nằm ở `../common`.
- Từ Milestone 0.2, thư viện dùng chung còn có mã trạng thái, macro bit, helper phòng thủ và ring buffer ngoài CLI và versioning — xem [`../common/README.md`](../common/README.md).

## Build & chạy

1. Từ thư mục gốc dự án, tạo thư mục build và build:
    ```sh
    mkdir -p build
    cd build
    cmake ..
    make
    ```

2. Chạy chương trình:
    ```sh
    ./src/app/eldmp
    ```

3. Chạy toàn bộ test (từ Milestone 0.2 có 8 test: 3 unit test + 5 bài thực hành):
    ```sh
    ctest --output-on-failure
    ```

## Clean build

Để xóa toàn bộ file build cũ và build lại từ đầu, hãy thực hiện:

```sh
rm -rf build/
cmake -B build
cmake --build build
```

## Mở rộng

- Hàm `main()` đã được thiết kế để dễ dàng mở rộng, ví dụ thêm các bước khởi tạo môi trường trước khi gọi CLI.
- Có thể thêm các module mới vào thư viện `common` mà không ảnh hưởng tới entry point.

## Thư mục này gồm

- `main.c`: Mã nguồn chính.
- `CMakeLists.txt`: Cấu hình build.
- `README.md`: Tài liệu này.
