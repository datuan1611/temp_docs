/*
 * test_harness.h - Minimal unit-test helpers for tests/1_learning.
 *
 * Why not <assert.h>? assert() is compiled out when NDEBUG is defined (Release
 * builds), which would turn every test into a silent pass (Guide 6.4). These
 * macros always run, count every check, print file:line on failure, and the
 * suite's exit code tells ctest whether anything failed.
 *
 * Each test file is its own executable, so the counters are plain statics.
 */
#ifndef ELDMP_TEST_HARNESS_H
#define ELDMP_TEST_HARNESS_H

#include <stdio.h>

#include "error_codes.h"

static unsigned g_checks;
static unsigned g_failures;

#define CHECK(cond)                                                           \
    do {                                                                      \
        g_checks++;                                                           \
        if (!(cond)) {                                                        \
            g_failures++;                                                     \
            fprintf(stderr, "  FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        }                                                                     \
    } while (0)

/* Compare two integers (any width); prints both values on mismatch. */
#define CHECK_EQ(actual, expected)                                            \
    do {                                                                      \
        unsigned long long a_ = (unsigned long long)(actual);                 \
        unsigned long long e_ = (unsigned long long)(expected);               \
        g_checks++;                                                           \
        if (a_ != e_) {                                                       \
            g_failures++;                                                     \
            fprintf(stderr, "  FAIL %s:%d: %s == %s (got 0x%llX, want 0x%llX)\n", \
                    __FILE__, __LINE__, #actual, #expected, a_, e_);          \
        }                                                                     \
    } while (0)

/* Compare an eldmp_status_t, printing the status names on mismatch. */
#define CHECK_STATUS(actual, expected)                                        \
    do {                                                                      \
        eldmp_status_t sa_ = (actual);                                        \
        eldmp_status_t se_ = (expected);                                      \
        g_checks++;                                                           \
        if (sa_ != se_) {                                                     \
            g_failures++;                                                     \
            fprintf(stderr, "  FAIL %s:%d: %s -> \"%s\", want \"%s\"\n",      \
                    __FILE__, __LINE__, #actual, eldmp_strerror(sa_),         \
                    eldmp_strerror(se_));                                     \
        }                                                                     \
    } while (0)

/* Run one test function and print a one-line verdict. */
#define RUN_TEST(fn)                                                          \
    do {                                                                      \
        unsigned before_ = g_failures;                                        \
        fn();                                                                 \
        printf("[%s] %s\n", g_failures == before_ ? " ok " : "FAIL", #fn);    \
    } while (0)

/* Print the summary; returns the process exit code (0 = all passed). */
static inline int test_finish(const char *suite)
{
    printf("%s: %u checks, %u failed\n", suite, g_checks, g_failures);
    return g_failures == 0U ? 0 : 1;
}

#endif /* ELDMP_TEST_HARNESS_H */
