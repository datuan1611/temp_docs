/*
 * test_defensive_patterns.c - Unit tests for error_codes.h/common.c and
 *                             defensive.h (Guide chapter 6).
 *
 * Each section proves that a classic piece of C undefined behaviour is turned
 * into an explicit status code, and that the failure path leaves the
 * destination untouched. Run under AddressSanitizer / UBSan / Valgrind for the
 * full effect: an out-of-bounds write or a double free would be reported.
 */
#include <stdint.h>
#include <string.h>

#include "defensive.h"
#include "test_harness.h"

static void test_strerror_covers_every_status(void)
{
    int s;
    int t;

    for (s = 0; s < (int)ELDMP_STATUS_COUNT; s++) {
        const char *text = eldmp_strerror((eldmp_status_t)s);

        CHECK(text != NULL);
        if (text == NULL) {
            continue;                                     /* report FAIL, never crash the suite */
        }
        CHECK(strcmp(text, "unknown status") != 0);       /* table is in sync with the enum */
        for (t = s + 1; t < (int)ELDMP_STATUS_COUNT; t++) {
            const char *other = eldmp_strerror((eldmp_status_t)t);

            CHECK(other != NULL && strcmp(text, other) != 0);   /* texts are distinct */
        }
    }
    /* Garbage values must never index past the table or return NULL. */
    {
        const char *garbage[3];
        int i;

        garbage[0] = eldmp_strerror(ELDMP_STATUS_COUNT);
        garbage[1] = eldmp_strerror((eldmp_status_t)9999);
        garbage[2] = eldmp_strerror((eldmp_status_t)-1);
        for (i = 0; i < 3; i++) {
            CHECK(garbage[i] != NULL && strcmp(garbage[i], "unknown status") == 0);
        }
    }
    CHECK_EQ(ELDMP_OK, 0);                                /* callers may write if (status) */
}

static void test_checked_size_arithmetic(void)
{
    size_t out = 123;

    CHECK_STATUS(eldmp_add_size(2, 3, &out), ELDMP_OK);
    CHECK_EQ(out, 5);
    CHECK_STATUS(eldmp_add_size(SIZE_MAX, 0, &out), ELDMP_OK);
    CHECK_EQ(out, SIZE_MAX);

    out = 123;
    CHECK_STATUS(eldmp_add_size(SIZE_MAX, 1, &out), ELDMP_ERR_OVERFLOW);
    CHECK_EQ(out, 123);                                   /* untouched on failure */
    CHECK_STATUS(eldmp_add_size(1, 2, NULL), ELDMP_ERR_INVALID_ARG);

    CHECK_STATUS(eldmp_mul_size(1000, 1000, &out), ELDMP_OK);
    CHECK_EQ(out, 1000000);
    CHECK_STATUS(eldmp_mul_size(0, SIZE_MAX, &out), ELDMP_OK);
    CHECK_EQ(out, 0);
    out = 123;
    CHECK_STATUS(eldmp_mul_size(SIZE_MAX / 2 + 1, 2, &out), ELDMP_ERR_OVERFLOW);
    CHECK_EQ(out, 123);
    CHECK_STATUS(eldmp_mul_size(2, 2, NULL), ELDMP_ERR_INVALID_ARG);
}

static void test_copy_bounded(void)
{
    uint8_t dst[8];
    static const uint8_t src[8] = { 1, 2, 3, 4, 5, 6, 7, 8 };

    memset(dst, 0xEE, sizeof(dst));
    CHECK_STATUS(eldmp_copy_bounded(dst, sizeof(dst), src, 4), ELDMP_OK);
    CHECK(memcmp(dst, src, 4) == 0);
    CHECK_EQ(dst[4], 0xEE);                               /* nothing written past the copy */

    memset(dst, 0xEE, sizeof(dst));
    CHECK_STATUS(eldmp_copy_bounded(dst, sizeof(dst), src, 8), ELDMP_OK);   /* exact fit */
    CHECK(memcmp(dst, src, 8) == 0);

    memset(dst, 0xEE, sizeof(dst));
    CHECK_STATUS(eldmp_copy_bounded(dst, 4, src, 8), ELDMP_ERR_NO_SPACE);   /* would overflow */
    CHECK_EQ(dst[0], 0xEE);                               /* all-or-nothing: dst untouched */

    CHECK_STATUS(eldmp_copy_bounded(NULL, 0, NULL, 0), ELDMP_OK);           /* empty copy is a no-op */
    CHECK_STATUS(eldmp_copy_bounded(NULL, 8, src, 4), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(eldmp_copy_bounded(dst, 8, NULL, 4), ELDMP_ERR_INVALID_ARG);
}

/* Calls strncpy through an opaque pointer so the intentional bug is not
 * diagnosed at build time (see test_str_copy). */
static void legacy_strncpy(const char *src, size_t n, char *dst)
{
    char *(*volatile copy)(char *, const char *, size_t) = strncpy;

    copy(dst, src, n);
}

static void test_str_copy(void)
{
    char dst[8];
    char legacy[4];

    memset(dst, 'x', sizeof(dst));
    CHECK_STATUS(eldmp_str_copy(dst, sizeof(dst), "abc"), ELDMP_OK);
    CHECK(strcmp(dst, "abc") == 0);

    CHECK_STATUS(eldmp_str_copy(dst, sizeof(dst), ""), ELDMP_OK);
    CHECK_EQ(dst[0], 0);

    CHECK_STATUS(eldmp_str_copy(dst, sizeof(dst), "1234567"), ELDMP_OK);     /* len == size-1: fits */
    CHECK(strcmp(dst, "1234567") == 0);

    memset(dst, 'x', sizeof(dst));
    CHECK_STATUS(eldmp_str_copy(dst, sizeof(dst), "12345678"), ELDMP_ERR_TRUNCATED);
    CHECK(strcmp(dst, "1234567") == 0);                   /* cut AND terminated */
    CHECK_STATUS(eldmp_str_copy(dst, sizeof(dst), "a very long string"), ELDMP_ERR_TRUNCATED);
    CHECK(strcmp(dst, "a very ") == 0);

    CHECK_STATUS(eldmp_str_copy(dst, 1, "a"), ELDMP_ERR_TRUNCATED);   /* room for the NUL only */
    CHECK_EQ(dst[0], 0);
    CHECK_STATUS(eldmp_str_copy(dst, 0, "a"), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(eldmp_str_copy(NULL, 8, "a"), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(eldmp_str_copy(dst, 8, NULL), ELDMP_ERR_INVALID_ARG);

    /* Why not strncpy: when the source is too long it does NOT terminate.
     * GCC (-Wstringop-truncation) flags this exact bug at compile time, so the
     * call goes through a volatile function pointer: the compiler cannot see
     * it and the demonstration still runs, without silencing the warning
     * anywhere else in the project. */
    memset(legacy, 'x', sizeof(legacy));
    legacy_strncpy("ABCDEFGH", sizeof(legacy), legacy);
    CHECK(legacy[sizeof(legacy) - 1U] != '\0');
}

static void test_unaligned_endian_loads(void)
{
    /* Odd offsets: a (uint32_t *) cast here would be UB / a bus fault on strict cores. */
    const uint8_t buf[12] = { 0xAA, 0x78, 0x56, 0x34, 0x12, 0xBB, 0, 0, 0, 0x80, 0, 0 };
    const uint8_t high[4] = { 0xFF, 0xFF, 0xFF, 0xFF };
    const uint8_t sign[4] = { 0x00, 0x00, 0x00, 0x80 };

    CHECK_EQ(eldmp_load_u32_le(&buf[1]), 0x12345678U);
    CHECK_EQ(eldmp_load_u32_be(&buf[1]), 0x78563412U);
    CHECK_EQ(eldmp_load_u16_le(&buf[1]), 0x5678U);
    CHECK_EQ(eldmp_load_u16_be(&buf[1]), 0x7856U);

    CHECK_EQ(eldmp_load_u32_le(high), 0xFFFFFFFFU);
    /* The classic trap: (b[3] << 24) on a plain int overflows when b[3] >= 0x80. */
    CHECK_EQ(eldmp_load_u32_le(sign), 0x80000000U);
    CHECK_EQ(eldmp_load_u32_be(&buf[6]), 0x00000080U);
    CHECK_EQ(eldmp_load_u16_be(&buf[9]), 0x8000U);
}

static void test_store_load_roundtrip(void)
{
    static const uint32_t values[] = { 0, 1, 0x7F, 0x80, 0xFF, 0x100, 0x12345678U,
                                       0x80000000U, 0xDEADBEEFU, 0xFFFFFFFFU };
    uint8_t buf[16];
    unsigned offset;
    size_t i;

    for (offset = 0; offset < 4U; offset++) {             /* every alignment */
        for (i = 0; i < sizeof(values) / sizeof(values[0]); i++) {
            uint32_t v = values[i];

            memset(buf, 0xCC, sizeof(buf));
            eldmp_store_u32_le(&buf[offset], v);
            CHECK_EQ(eldmp_load_u32_le(&buf[offset]), v);
            CHECK_EQ(buf[offset + 4U], 0xCC);             /* exactly 4 bytes written */
            CHECK_EQ(offset == 0U ? 0xCC : buf[offset - 1U], 0xCC);

            eldmp_store_u32_be(&buf[offset], v);
            CHECK_EQ(eldmp_load_u32_be(&buf[offset]), v);

            eldmp_store_u16_le(&buf[offset], (uint16_t)v);
            CHECK_EQ(eldmp_load_u16_le(&buf[offset]), (uint16_t)v);
            eldmp_store_u16_be(&buf[offset], (uint16_t)v);
            CHECK_EQ(eldmp_load_u16_be(&buf[offset]), (uint16_t)v);
        }
    }

    eldmp_store_u32_le(buf, 0x01020304U);                 /* byte order really is explicit */
    CHECK(buf[0] == 0x04 && buf[1] == 0x03 && buf[2] == 0x02 && buf[3] == 0x01);
    eldmp_store_u32_be(buf, 0x01020304U);
    CHECK(buf[0] == 0x01 && buf[1] == 0x02 && buf[2] == 0x03 && buf[3] == 0x04);
}

static void test_free_and_null(void)
{
    char *p = (char *)malloc(32);
    char *never_allocated = NULL;

    CHECK(p != NULL);
    ELDMP_FREE(p);
    CHECK(p == NULL);              /* a stale use now fails loudly, not silently */
    ELDMP_FREE(p);                 /* second call is harmless (a double free would trip ASan) */
    ELDMP_FREE(never_allocated);
    CHECK(never_allocated == NULL);
}

int main(void)
{
    RUN_TEST(test_strerror_covers_every_status);
    RUN_TEST(test_checked_size_arithmetic);
    RUN_TEST(test_copy_bounded);
    RUN_TEST(test_str_copy);
    RUN_TEST(test_unaligned_endian_loads);
    RUN_TEST(test_store_load_roundtrip);
    RUN_TEST(test_free_and_null);
    return test_finish("test_defensive_patterns");
}
