/*
 * test_bit_macros.c - Unit tests for src/common/include/macros.h.
 *
 * Goal (roadmap DoD): bit macros verified against REAL register access
 * patterns - not just toy values. Besides exhaustive single-bit checks, a RAM
 * mock of an STM32-style GPIO block exercises the 2-bit MODER field pattern
 * from the guide (4.1) and the write-1-to-set/reset BSRR pattern.
 */
#include <stdint.h>

#include "macros.h"
#include "types.h"
#include "test_harness.h"

/* ---- Single-bit macros: exhaustive over every 8-bit value x every bit ---- */
static void test_single_bit_exhaustive_u8(void)
{
    unsigned v;
    unsigned n;
    unsigned bad = 0;

    for (v = 0; v <= 0xFFU; v++) {
        for (n = 0; n < 8U; n++) {
            uint8_t r;
            uint8_t expect_set = (uint8_t)(v | (1U << n));
            uint8_t expect_clr = (uint8_t)(v & ~(1U << n));
            uint8_t expect_tgl = (uint8_t)(v ^ (1U << n));

            r = (uint8_t)v; SET_BIT(r, n);    bad += (r != expect_set);
            r = (uint8_t)v; CLEAR_BIT(r, n);  bad += (r != expect_clr);
            r = (uint8_t)v; TOGGLE_BIT(r, n); bad += (r != expect_tgl);
            r = (uint8_t)v; TOGGLE_BIT(r, n); TOGGLE_BIT(r, n); bad += (r != (uint8_t)v);
            bad += (READ_BIT(v, n) != ((v >> n) & 1U));
        }
    }
    CHECK_EQ(bad, 0);   /* 256 * 8 * 5 comparisons, one verdict */
}

static void test_edges_u32(void)
{
    uint32_t r = 0;

    CHECK_EQ(BIT(0), 0x00000001U);
    CHECK_EQ(BIT(31), 0x80000000U);   /* 1U, not int: no signed-shift UB */

    SET_BIT(r, 31);
    CHECK_EQ(r, 0x80000000U);
    CHECK_EQ(READ_BIT(r, 31), 1);
    CHECK_EQ(READ_BIT(r, 30), 0);
    CLEAR_BIT(r, 31);
    CHECK_EQ(r, 0);

    r = 0xFFFFFFFFU;
    CLEAR_BIT(r, 0);
    CHECK_EQ(r, 0xFFFFFFFEU);
}

/* ---- Guide 4.1 worked examples ------------------------------------------- */
static void test_guide_examples(void)
{
    uint32_t reg = 0;

    SET_BIT(reg, 5);
    CHECK_EQ(reg, 0x00000020U);

    reg = 0xFFFFFFFFU;
    CLEAR_BIT(reg, 5);
    CHECK_EQ(reg, 0xFFFFFFDFU);

    reg = 0xFFFFFFFFU;
    WRITE_MASK(reg, 0xF0U, 0x50U);               /* guide: -> 0xFFFFFF5F */
    CHECK_EQ(reg, 0xFFFFFF5FU);

    reg = 0xFFFFFFFFU;
    WRITE_MASK(reg, 0xF0U, 0xFFU);               /* pattern bits outside mask ignored */
    CHECK_EQ(reg, 0xFFFFFFFFU);
    reg = 0x00000000U;
    WRITE_MASK(reg, 0xF0U, 0xFFU);
    CHECK_EQ(reg, 0x000000F0U);
}

static void test_genmask_and_fields(void)
{
    unsigned v;
    uint32_t reg;

    CHECK_EQ(GENMASK(7, 4), 0x000000F0U);
    CHECK_EQ(GENMASK(15, 8), 0x0000FF00U);
    CHECK_EQ(GENMASK(0, 0), 0x00000001U);
    CHECK_EQ(GENMASK(31, 31), 0x80000000U);
    CHECK_EQ(GENMASK(31, 0), 0xFFFFFFFFU);       /* shifts by 0 are well defined */
    CHECK_EQ(GENMASK(2, 1), 0x00000006U);

    CHECK_EQ(FIELD_PREP(GENMASK(7, 4), 0x5U), 0x50U);
    CHECK_EQ(FIELD_PREP(GENMASK(7, 4), 0x1FU), 0xF0U);   /* oversized value is truncated */
    CHECK_EQ(FIELD_GET(GENMASK(7, 4), 0xABU), 0xAU);
    CHECK_EQ(FIELD_GET(GENMASK(31, 28), 0xC0000000U), 0xCU);

    for (v = 0; v < 16U; v++) {                  /* prep/get round trip */
        reg = 0xFFFFFFFFU;
        WRITE_MASK(reg, GENMASK(11, 8), FIELD_PREP(GENMASK(11, 8), v));
        CHECK_EQ(FIELD_GET(GENMASK(11, 8), reg), v);
        CHECK_EQ(reg | GENMASK(11, 8), 0xFFFFFFFFU);      /* other bits untouched */
    }
}

/* ---- Real register pattern #1: STM32-style MODER (2 bits per pin) --------- */
typedef struct {
    REG_RW uint32_t MODER;
    REG_RW uint32_t ODR;
    REG_RW uint32_t BSRR;
} mock_gpio_t;

/* Same shape as the guide's gpio_set_pin_mode(), built on the macros. */
static void mock_set_pin_mode(mock_gpio_t *port, unsigned pin, uint32_t mode)
{
    uint32_t mask = GENMASK(2U * pin + 1U, 2U * pin);
    uint32_t value = FIELD_PREP(mask, mode);

    WRITE_MASK(port->MODER, mask, value);
}

static void test_moder_two_bit_fields(void)
{
    mock_gpio_t port = { 0xA5A5A5A5U, 0, 0 };
    unsigned pin;
    unsigned mode;
    unsigned bad = 0;

    for (pin = 0; pin < 16U; pin++) {
        for (mode = 0; mode < 4U; mode++) {
            uint32_t before = 0xA5A5A5A5U;
            uint32_t other_mask = ~GENMASK(2U * pin + 1U, 2U * pin);

            port.MODER = before;
            mock_set_pin_mode(&port, pin, mode);
            bad += (FIELD_GET(GENMASK(2U * pin + 1U, 2U * pin), port.MODER) != mode);
            bad += ((port.MODER & other_mask) != (before & other_mask));  /* neighbours intact */
        }
    }
    CHECK_EQ(bad, 0);

    /* Guide example: pin 5 -> output (01b), pin 7 -> alternate function (10b). */
    port.MODER = 0;
    mock_set_pin_mode(&port, 5, 1);
    mock_set_pin_mode(&port, 7, 2);
    CHECK_EQ(port.MODER, (1U << 10) | (2U << 14));
}

/* ---- Real register pattern #2: BSRR (write-1-to-set / write-1-to-reset) --- */
/* Hardware model: low half sets ODR bits, high half resets them, one bus write,
 * no read-modify-write - that is why real MCUs provide it. */
static void mock_bsrr_write(mock_gpio_t *port, uint32_t value)
{
    port->BSRR = value;
    port->ODR |= (value & 0xFFFFU);
    port->ODR &= ~(value >> 16);
}

static void test_bsrr_pattern(void)
{
    mock_gpio_t port = { 0, 0, 0 };

    mock_bsrr_write(&port, BIT(5));                    /* set pin 5 */
    CHECK_EQ(port.ODR, BIT(5));
    mock_bsrr_write(&port, BIT(3));                    /* set pin 3 */
    CHECK_EQ(port.ODR, BIT(5) | BIT(3));
    mock_bsrr_write(&port, BIT(5) | BIT(16U + 3U));    /* set 5 and reset 3 in ONE write */
    CHECK_EQ(port.ODR, BIT(5));

    /* The RMW version needs three steps; an interrupt between its read and
     * write can be lost. BSRR avoids that by construction. */
    port.ODR = 0;
    SET_BIT(port.ODR, 5);
    TOGGLE_BIT(port.ODR, 5);
    CHECK_EQ(port.ODR, 0);
}

/* ---- Integer promotion pitfalls ------------------------------------------- */
static void test_promotion_pitfalls(void)
{
    uint8_t x = 0x80;
    uint8_t reg = 0xFF;
    int promoted = ~x;                           /* GCC warns (-Wsign-compare) if you
                                                    compare ~x with a constant directly */

    /* ~x promotes x to int first: the result is 0xFFFFFF7F, not 0x7F. */
    CHECK(promoted != 0x7F);
    CHECK_EQ((uint32_t)promoted, 0xFFFFFF7FU);
    CHECK((uint8_t)~x == 0x7F);                  /* the fix: narrow explicitly */

    WRITE_MASK(reg, 0xF0U, 0x50U);               /* works on 8-bit registers too */
    CHECK_EQ(reg, 0x5F);

    reg = 0x00;
    SET_BIT(reg, 7);
    CHECK_EQ(reg, 0x80);
}

static void test_array_size(void)
{
    int ints[7];
    static const uint16_t table[] = { 1, 2, 3 };
    char text[16];
    struct { uint8_t a; uint32_t b; } records[5];

    CHECK_EQ(ARRAY_SIZE(ints), 7);
    CHECK_EQ(ARRAY_SIZE(table), 3);
    CHECK_EQ(ARRAY_SIZE(text), 16);
    CHECK_EQ(ARRAY_SIZE(records), 5);
    (void)ints; (void)text; (void)records;
}

int main(void)
{
    RUN_TEST(test_single_bit_exhaustive_u8);
    RUN_TEST(test_edges_u32);
    RUN_TEST(test_guide_examples);
    RUN_TEST(test_genmask_and_fields);
    RUN_TEST(test_moder_two_bit_fields);
    RUN_TEST(test_bsrr_pattern);
    RUN_TEST(test_promotion_pitfalls);
    RUN_TEST(test_array_size);
    return test_finish("test_bit_macros");
}
