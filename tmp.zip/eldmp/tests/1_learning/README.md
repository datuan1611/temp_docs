# tests/1_learning — Unit Test Cho Thư Viện Dùng Chung (Milestone 0.2)

Ba bộ test kiểm chứng code **Ship** trong [`src/common/`](../../src/common/README.md). Hướng dẫn thực hiện cả milestone nằm ở [`src/learning/README.md`](../../src/learning/README.md); file này giải thích **mỗi test chứng minh điều gì**, và vì sao viết như vậy.

## Chạy test

```bash
cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug -DELDMP_WERROR=ON
cmake --build .
ctest --output-on-failure -R learning        # 3 test ở đây + 5 bài tập
./tests/1_learning/test_circular_buffer      # chạy riêng một bộ để xem từng dòng [ ok ]
```

Mỗi test là một chương trình độc lập, **thoát với mã khác 0 khi có check fail** — đó là cách `ctest` biết kết quả. Kỳ vọng: `100% tests passed` (khoảng 2 giây cả bài tập lẫn test).

## Ba bộ test

| File | Kiểm chứng | Chiến lược |
|---|---|---|
| `test_bit_macros.c` | `macros.h` | **Vét cạn** mọi giá trị 8-bit × mọi vị trí bit × 5 phép toán; cạnh bit 0/31; ví dụ guide; `GENMASK`/`FIELD_*`; mô phỏng thanh ghi GPIO (`MODER` 2 bit/chân, `BSRR`); bẫy integer promotion; `ARRAY_SIZE` |
| `test_defensive_patterns.c` | `error_codes.h`, `common.c`, `defensive.h` | Mỗi helper biến một loại UB thành mã trạng thái, và **đường thất bại không làm hỏng đích** (đích giữ nguyên) |
| `test_circular_buffer.c` | `circular_buffer.h/.c` | Ca có mục tiêu + tràn bộ đếm ở `SIZE_MAX` + test **ngẫu nhiên đối chiếu mô hình tham chiếu** + hai thread thật |

### Vì sao `test_circular_buffer.c` có bốn lớp

1. **Ca có mục tiêu** — rỗng, đầy, dung lượng 1, wrap-around, `peek` không tiêu thụ, `flush`, mọi đường `NULL`/tham số sai. *Ý nghĩa:* mỗi hành vi đã ghi trong header đều có một check.
2. **Tràn bộ đếm** — ép `head`/`tail` về sát `SIZE_MAX` rồi đẩy dữ liệu qua điểm tràn. *Ý nghĩa:* kỹ thuật bộ đếm chạy tự do chỉ đúng khi dung lượng là lũy thừa của 2; test này chứng minh điều đó. (Chỉ ca này mới đọc trực tiếp `head`/`tail`.)
3. **Đối chiếu mô hình** — 200.000 thao tác ngẫu nhiên (hạt giống cố định → tái hiện được) cho 5 dung lượng, so từng kết quả với một hàng đợi ngu ngốc nhưng hiển nhiên đúng. *Ý nghĩa:* bắt các lỗi mà bạn không nghĩ ra để viết ca riêng.
4. **Hai thread thật** — producer đẩy 2.000.000 byte qua bộ đệm 64 byte, consumer kiểm từng byte; có cả bản dùng `write`/`read` theo khối kích thước ngẫu nhiên. Có hạn chót 20 giây để lỗi treo không làm treo cả CI. *Ý nghĩa:* chạy dưới **ThreadSanitizer** mới là bằng chứng về memory ordering.

## Vì sao test dùng macro `CHECK` riêng, không dùng `assert()`

`assert()` bị **biên dịch mất** khi định nghĩa `NDEBUG` (build Release) — test sẽ "pass" mà thực ra không kiểm tra gì (guide §6.4). `test_harness.h` luôn chạy, đếm mọi check, in `file:line` khi fail, và nếu một con trỏ là `NULL` thì báo FAIL thay vì làm sập cả bộ test. Đây là khung tối giản (~70 dòng) cho giai đoạn C thuần; dev container có sẵn Unity/CMock cho các sprint MCU sau nếu bạn muốn chuyển.

## Bằng chứng test thật sự có tác dụng (chạy được trên máy bạn)

Test pass ngay lần đầu thì chưa chứng minh gì. Hãy **cố ý phá thư viện** và xem test có bắt không:

```bash
git add -A                                  # lưu bản gốc vào staging trước khi phá
# 1) Cho ring buffer "đầy" sớm một ô:  trong circular_buffer.c đổi  head - tail > cb->mask  thành  >=
cmake --build build && (cd build && ctest)   # phải có test FAIL
git checkout -- src/common/src/circular_buffer.c
```

Các lỗi đã được thử và test bắt được hết: ngưỡng đầy lệch một, `pop` đọc sai ô, `write` quên đoạn wrap, `GENMASK` lệch một, `str_copy` quên ký tự kết thúc.

Thử thêm cái thú vị nhất: trong `circular_buffer.c` đổi mọi `__ATOMIC_ACQUIRE` và `__ATOMIC_RELEASE` thành `__ATOMIC_RELAXED`. Trên x86 `ctest` thường **vẫn pass 100%**, nhưng bản build TSan (`-DCMAKE_C_FLAGS=-fsanitize=thread`) báo `data race` trong `circular_buffer_pop`. *Ý nghĩa:* x86 che giấu lỗi thứ tự bộ nhớ mà ARM thì không — nên đừng tin một lần chạy xanh trên PC.

## Thêm test cho sprint sau

1. Tạo `test_<tên>.c` (hoặc `.cpp` ở `tests/2_unit/`), `#include "test_harness.h"`.
2. Thêm tên vào danh sách `foreach(name ...)` trong `CMakeLists.txt` của thư mục.
3. Cập nhật bảng ở trên và README của module tương ứng.
