/*
 * test_circular_buffer.c - Unit tests for src/common/src/circular_buffer.c.
 *
 * Covers the roadmap DoD for the ring buffer: empty, full, wrap-around and
 * thread-safety edge cases. Strategy:
 *   1. Targeted cases for every documented behaviour and every error path.
 *   2. Counter wrap-around at SIZE_MAX (white-box: head/tail are set directly).
 *   3. A randomised differential test against a trivial reference model.
 *   4. Two real threads (producer/consumer) moving millions of bytes.
 * Build with -fsanitize=thread to have ThreadSanitizer check (4) for races.
 */
/* POSIX/BSD functions (pthread, sched_yield, clock_gettime) are not part of ISO C. This feature-test macro must come
 * before every #include so the file builds under strict -std=c11 as well as -std=gnu11. */
#define _DEFAULT_SOURCE

#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "circular_buffer.h"
#include "test_harness.h"

/* Initialise a buffer over a local array; fails the test if init fails. */
#define INIT_CB(cb, storage, cap) \
    CHECK_STATUS(circular_buffer_init(&(cb), (storage), (cap)), ELDMP_OK)

static void test_init_validation(void)
{
    uint8_t mem[16];
    circular_buffer_t cb;
    static const size_t bad_caps[] = { 0, 3, 5, 6, 7, 9, 12, 100 };
    size_t i;

    CHECK_STATUS(circular_buffer_init(NULL, mem, 8), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(circular_buffer_init(&cb, NULL, 8), ELDMP_ERR_INVALID_ARG);

    for (i = 0; i < sizeof(bad_caps) / sizeof(bad_caps[0]); i++) {
        CHECK_STATUS(circular_buffer_init(&cb, mem, bad_caps[i]), ELDMP_ERR_INVALID_ARG);
        /* A failed init leaves a buffer that rejects everything - no stray state. */
        CHECK_STATUS(circular_buffer_push(&cb, 1), ELDMP_ERR_INVALID_ARG);
        CHECK_EQ(circular_buffer_capacity(&cb), 0);
    }

    CHECK_STATUS(circular_buffer_init(&cb, mem, 1), ELDMP_OK);
    CHECK_EQ(circular_buffer_capacity(&cb), 1);
    CHECK_STATUS(circular_buffer_init(&cb, mem, 16), ELDMP_OK);
    CHECK_EQ(circular_buffer_capacity(&cb), 16);
}

static void test_null_safety(void)
{
    uint8_t mem[8];
    uint8_t byte = 0;
    circular_buffer_t cb;

    INIT_CB(cb, mem, 8);
    CHECK_STATUS(circular_buffer_push(NULL, 1), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(circular_buffer_pop(NULL, &byte), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(circular_buffer_pop(&cb, NULL), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(circular_buffer_peek(NULL, &byte), ELDMP_ERR_INVALID_ARG);
    CHECK_STATUS(circular_buffer_peek(&cb, NULL), ELDMP_ERR_INVALID_ARG);
    CHECK_EQ(circular_buffer_count(NULL), 0);
    CHECK_EQ(circular_buffer_capacity(NULL), 0);
    CHECK_EQ(circular_buffer_free_space(NULL), 0);
    CHECK(circular_buffer_is_empty(NULL));   /* unusable == nothing to read ... */
    CHECK(circular_buffer_is_full(NULL));    /* ... and nothing can be written  */
    CHECK_EQ(circular_buffer_write(NULL, mem, 4), 0);
    CHECK_EQ(circular_buffer_write(&cb, NULL, 4), 0);
    CHECK_EQ(circular_buffer_read(NULL, mem, 4), 0);
    CHECK_EQ(circular_buffer_read(&cb, NULL, 4), 0);
    circular_buffer_flush(NULL);             /* must simply not crash */
    CHECK_EQ(circular_buffer_count(&cb), 0); /* none of the above changed state */
}

static void test_empty_state(void)
{
    uint8_t mem[8];
    uint8_t byte = 0xEE;
    circular_buffer_t cb;

    INIT_CB(cb, mem, 8);
    CHECK(circular_buffer_is_empty(&cb));
    CHECK(!circular_buffer_is_full(&cb));
    CHECK_EQ(circular_buffer_count(&cb), 0);
    CHECK_EQ(circular_buffer_free_space(&cb), 8);
    CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_ERR_EMPTY);
    CHECK_STATUS(circular_buffer_peek(&cb, &byte), ELDMP_ERR_EMPTY);
    CHECK_EQ(byte, 0xEE);                    /* output untouched on failure */
    CHECK_EQ(circular_buffer_read(&cb, mem, 4), 0);
}

static void test_full_state(void)
{
    uint8_t mem[8];
    uint8_t byte = 0;
    circular_buffer_t cb;
    unsigned i;

    INIT_CB(cb, mem, 8);
    for (i = 0; i < 8U; i++) {
        CHECK_STATUS(circular_buffer_push(&cb, (uint8_t)(0x10U + i)), ELDMP_OK);
    }
    CHECK(circular_buffer_is_full(&cb));      /* full capacity usable: no wasted slot */
    CHECK(!circular_buffer_is_empty(&cb));
    CHECK_EQ(circular_buffer_count(&cb), 8);
    CHECK_EQ(circular_buffer_free_space(&cb), 0);

    CHECK_STATUS(circular_buffer_push(&cb, 0xFF), ELDMP_ERR_NO_SPACE);   /* rejected ... */
    CHECK_EQ(circular_buffer_count(&cb), 8);                             /* ... without damage */

    for (i = 0; i < 8U; i++) {
        CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
        CHECK_EQ(byte, 0x10U + i);            /* the rejected 0xFF never got in */
    }
    CHECK(circular_buffer_is_empty(&cb));
}

static void test_fifo_order_and_peek(void)
{
    uint8_t mem[4];
    uint8_t byte = 0;
    circular_buffer_t cb;

    INIT_CB(cb, mem, 4);
    CHECK_STATUS(circular_buffer_push(&cb, 'A'), ELDMP_OK);
    CHECK_STATUS(circular_buffer_push(&cb, 'B'), ELDMP_OK);
    CHECK_STATUS(circular_buffer_peek(&cb, &byte), ELDMP_OK);
    CHECK_EQ(byte, 'A');
    CHECK_STATUS(circular_buffer_peek(&cb, &byte), ELDMP_OK);   /* peek does not consume */
    CHECK_EQ(byte, 'A');
    CHECK_EQ(circular_buffer_count(&cb), 2);
    CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
    CHECK_EQ(byte, 'A');
    CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
    CHECK_EQ(byte, 'B');
}

static void test_capacity_one(void)
{
    uint8_t mem[1];
    uint8_t byte = 0;
    circular_buffer_t cb;
    unsigned i;

    INIT_CB(cb, mem, 1);
    for (i = 0; i < 300U; i++) {              /* index is always 0; counters keep moving */
        CHECK_STATUS(circular_buffer_push(&cb, (uint8_t)i), ELDMP_OK);
        CHECK(circular_buffer_is_full(&cb));
        CHECK_STATUS(circular_buffer_push(&cb, 0), ELDMP_ERR_NO_SPACE);
        CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
        CHECK_EQ(byte, (uint8_t)i);
        CHECK(circular_buffer_is_empty(&cb));
    }
}

static void test_wraparound_single_bytes(void)
{
    uint8_t mem[8];
    uint8_t byte = 0;
    circular_buffer_t cb;
    unsigned next_in = 0;
    unsigned next_out = 0;
    unsigned round;
    unsigned i;

    INIT_CB(cb, mem, 8);
    /* 3 in / 3 out, repeatedly: the array index wraps many times. */
    for (round = 0; round < 1000U; round++) {
        for (i = 0; i < 3U; i++) {
            CHECK_STATUS(circular_buffer_push(&cb, (uint8_t)next_in++), ELDMP_OK);
        }
        for (i = 0; i < 3U; i++) {
            CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
            CHECK_EQ(byte, (uint8_t)next_out++);
        }
    }
    CHECK(circular_buffer_is_empty(&cb));
}

/* The counters are free-running size_t values. Force them next to the point
 * where they overflow SIZE_MAX and prove nothing breaks when they wrap. This
 * works only because capacity is a power of two (2^N is a multiple of it). */
static void test_counter_wrap_at_size_max(void)
{
    uint8_t mem[8];
    uint8_t byte = 0;
    circular_buffer_t cb;
    unsigned i;

    INIT_CB(cb, mem, 8);
    cb.head = SIZE_MAX - 2U;                  /* empty buffer, counters about to wrap */
    cb.tail = SIZE_MAX - 2U;
    CHECK(circular_buffer_is_empty(&cb));

    for (i = 0; i < 8U; i++) {                /* head passes SIZE_MAX -> 0 -> ... */
        CHECK_STATUS(circular_buffer_push(&cb, (uint8_t)(0x40U + i)), ELDMP_OK);
    }
    CHECK(cb.head < cb.tail);                 /* head has wrapped past tail numerically */
    CHECK(circular_buffer_is_full(&cb));
    CHECK_EQ(circular_buffer_count(&cb), 8);
    CHECK_STATUS(circular_buffer_push(&cb, 0), ELDMP_ERR_NO_SPACE);

    for (i = 0; i < 8U; i++) {
        CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
        CHECK_EQ(byte, 0x40U + i);
    }
    CHECK(circular_buffer_is_empty(&cb));
    CHECK_EQ(cb.head, cb.tail);
}

static void test_bulk_write_read(void)
{
    uint8_t mem[8];
    uint8_t out[16];
    static const uint8_t src[16] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
    circular_buffer_t cb;
    unsigned i;

    INIT_CB(cb, mem, 8);
    CHECK_EQ(circular_buffer_write(&cb, src, 0), 0);          /* zero length */
    CHECK_EQ(circular_buffer_write(&cb, src, 6), 6);
    CHECK_EQ(circular_buffer_read(&cb, out, 4), 4);           /* leaves 2, tail at 4 */
    CHECK(memcmp(out, src, 4) == 0);
    CHECK_EQ(circular_buffer_write(&cb, &src[6], 6), 6);      /* head wraps inside this write */
    CHECK_EQ(circular_buffer_count(&cb), 8);
    CHECK_EQ(circular_buffer_write(&cb, src, 3), 0);          /* full: nothing stored */

    CHECK_EQ(circular_buffer_read(&cb, out, 16), 8);          /* asks for more than present */
    for (i = 0; i < 8U; i++) {
        CHECK_EQ(out[i], 4U + i);                             /* 4,5 then 6..11 in order */
    }
    CHECK(circular_buffer_is_empty(&cb));

    /* Partial write: only 8 of 12 fit. */
    CHECK_EQ(circular_buffer_write(&cb, src, 12), 8);
    CHECK(circular_buffer_is_full(&cb));
}

static void test_flush(void)
{
    uint8_t mem[8];
    uint8_t byte = 0;
    circular_buffer_t cb;
    unsigned i;

    INIT_CB(cb, mem, 8);
    for (i = 0; i < 5U; i++) {
        CHECK_STATUS(circular_buffer_push(&cb, (uint8_t)i), ELDMP_OK);
    }
    circular_buffer_flush(&cb);
    CHECK(circular_buffer_is_empty(&cb));
    CHECK_EQ(circular_buffer_free_space(&cb), 8);
    CHECK_STATUS(circular_buffer_push(&cb, 0x77), ELDMP_OK);  /* still fully usable */
    CHECK_STATUS(circular_buffer_pop(&cb, &byte), ELDMP_OK);
    CHECK_EQ(byte, 0x77);
}

/* ---- Randomised differential test ----------------------------------------
 * The reference model is deliberately dumb: a flat array that shifts left on
 * every removal. Any disagreement with the ring buffer is a bug in the ring
 * buffer. Fixed seed => reproducible failures. */
#define MODEL_MAX 128

typedef struct {
    uint8_t data[MODEL_MAX];
    size_t  len;
    size_t  cap;
} model_t;

static uint32_t g_rng = 12345U;

static uint32_t rng_next(void)                /* small LCG, plenty for test data */
{
    g_rng = g_rng * 1664525U + 1013904223U;
    return g_rng >> 8;
}

static void model_remove(model_t *m, size_t n)
{
    memmove(m->data, m->data + n, m->len - n);
    m->len -= n;
}

static void run_differential(size_t capacity)
{
    uint8_t mem[MODEL_MAX];
    circular_buffer_t cb;
    model_t m;
    unsigned op;
    unsigned mismatches = 0;

    INIT_CB(cb, mem, capacity);
    m.len = 0;
    m.cap = capacity;

    for (op = 0; op < 200000U; op++) {
        uint8_t tmp[40];
        uint8_t real[40];
        size_t i;

        switch (rng_next() % 6U) {
        case 0: {                                           /* push */
            uint8_t v = (uint8_t)rng_next();
            eldmp_status_t want = (m.len < m.cap) ? ELDMP_OK : ELDMP_ERR_NO_SPACE;
            mismatches += (circular_buffer_push(&cb, v) != want);
            if (want == ELDMP_OK) {
                m.data[m.len++] = v;
            }
            break;
        }
        case 1: {                                           /* pop */
            uint8_t got = 0;
            eldmp_status_t want = (m.len > 0) ? ELDMP_OK : ELDMP_ERR_EMPTY;
            mismatches += (circular_buffer_pop(&cb, &got) != want);
            if (want == ELDMP_OK) {
                mismatches += (got != m.data[0]);
                model_remove(&m, 1);
            }
            break;
        }
        case 2: {                                           /* bulk write */
            size_t len = rng_next() % 40U;
            size_t n = (len < m.cap - m.len) ? len : m.cap - m.len;
            for (i = 0; i < len; i++) {
                tmp[i] = (uint8_t)rng_next();
            }
            mismatches += (circular_buffer_write(&cb, tmp, len) != n);
            memcpy(m.data + m.len, tmp, n);
            m.len += n;
            break;
        }
        case 3: {                                           /* bulk read */
            size_t len = 1U + rng_next() % 39U;
            size_t n = (len < m.len) ? len : m.len;
            mismatches += (circular_buffer_read(&cb, real, len) != n);
            mismatches += (memcmp(real, m.data, n) != 0);
            model_remove(&m, n);
            break;
        }
        case 4: {                                           /* peek */
            uint8_t got = 0;
            eldmp_status_t want = (m.len > 0) ? ELDMP_OK : ELDMP_ERR_EMPTY;
            mismatches += (circular_buffer_peek(&cb, &got) != want);
            if (want == ELDMP_OK) {
                mismatches += (got != m.data[0]);
            }
            break;
        }
        default:                                            /* rare flush */
            if (rng_next() % 16U == 0U) {
                circular_buffer_flush(&cb);
                m.len = 0;
            }
            break;
        }
        mismatches += (circular_buffer_count(&cb) != m.len);
        mismatches += (circular_buffer_is_empty(&cb) != (m.len == 0));
        mismatches += (circular_buffer_is_full(&cb) != (m.len == m.cap));
    }
    CHECK_EQ(mismatches, 0);
}

static void test_differential_vs_model(void)
{
    run_differential(1);
    run_differential(2);
    run_differential(16);
    run_differential(64);
    run_differential(128);
}

/* ---- Two real threads ------------------------------------------------------
 * The producer plays the ISR, the consumer plays the main loop. A tiny buffer
 * (64 bytes) forces constant full/empty contention. Every byte must arrive
 * once, in order. A deadline guards against a hang turning into a stuck CI. */
#define STRESS_BYTES   2000000UL
#define STRESS_SECONDS 20.0

typedef struct {
    circular_buffer_t *cb;
    int use_bulk;
} producer_args_t;

static double now_seconds(void)
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static void *producer_main(void *arg)
{
    producer_args_t *a = (producer_args_t *)arg;
    unsigned long sent = 0;
    uint32_t rng = 777U;
    double deadline = now_seconds() + STRESS_SECONDS;

    while (sent < STRESS_BYTES && now_seconds() < deadline) {
        if (a->use_bulk) {
            uint8_t chunk[37];
            size_t want = 1U + (rng = rng * 1664525U + 1013904223U) % 36U;
            size_t i;
            size_t wrote;

            if (want > STRESS_BYTES - sent) {
                want = STRESS_BYTES - sent;
            }
            for (i = 0; i < want; i++) {
                chunk[i] = (uint8_t)(sent + i);
            }
            wrote = circular_buffer_write(a->cb, chunk, want);
            sent += wrote;
            if (wrote == 0U) {
                sched_yield();
            }
        } else if (circular_buffer_push(a->cb, (uint8_t)sent) == ELDMP_OK) {
            sent++;
        } else {
            sched_yield();                    /* full: wait for the consumer */
        }
    }
    return NULL;
}

static void run_thread_stress(int use_bulk)
{
    uint8_t mem[64];
    circular_buffer_t cb;
    producer_args_t args;
    pthread_t producer;
    unsigned long received = 0;
    unsigned long errors = 0;
    uint32_t rng = 4242U;
    double deadline;

    INIT_CB(cb, mem, sizeof(mem));
    args.cb = &cb;
    args.use_bulk = use_bulk;
    CHECK_EQ(pthread_create(&producer, NULL, producer_main, &args), 0);

    deadline = now_seconds() + STRESS_SECONDS;
    while (received < STRESS_BYTES && now_seconds() < deadline) {
        if (use_bulk) {
            uint8_t chunk[41];
            size_t want = 1U + (rng = rng * 1664525U + 1013904223U) % 40U;
            size_t got = circular_buffer_read(&cb, chunk, want);
            size_t i;

            for (i = 0; i < got; i++) {
                errors += (chunk[i] != (uint8_t)(received + i));
            }
            received += got;
            if (got == 0U) {
                sched_yield();
            }
        } else {
            uint8_t byte;

            if (circular_buffer_pop(&cb, &byte) == ELDMP_OK) {
                errors += (byte != (uint8_t)received);
                received++;
            } else {
                sched_yield();                /* empty: wait for the producer */
            }
        }
    }
    CHECK_EQ(pthread_join(producer, NULL), 0);

    CHECK_EQ(received, STRESS_BYTES);         /* nothing lost, nothing stuck */
    CHECK_EQ(errors, 0);                      /* nothing reordered or corrupted */
    CHECK(circular_buffer_is_empty(&cb));
}

static void test_thread_stress_single_bytes(void)
{
    run_thread_stress(0);
}

static void test_thread_stress_bulk(void)
{
    run_thread_stress(1);
}

int main(void)
{
    RUN_TEST(test_init_validation);
    RUN_TEST(test_null_safety);
    RUN_TEST(test_empty_state);
    RUN_TEST(test_full_state);
    RUN_TEST(test_fifo_order_and_peek);
    RUN_TEST(test_capacity_one);
    RUN_TEST(test_wraparound_single_bytes);
    RUN_TEST(test_counter_wrap_at_size_max);
    RUN_TEST(test_bulk_write_read);
    RUN_TEST(test_flush);
    RUN_TEST(test_differential_vs_model);
    RUN_TEST(test_thread_stress_single_bytes);
    RUN_TEST(test_thread_stress_bulk);
    return test_finish("test_circular_buffer");
}
